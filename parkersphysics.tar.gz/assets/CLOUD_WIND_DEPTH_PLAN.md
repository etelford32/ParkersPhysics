# Cloud + Wind Depth Plan

> Status doc for the EarthView atmosphere stack: the volumetric cloud
> renderer, the vertical exaggeration ramp, and the multi-level wind stack.
>
> Several files already referred to "the wind+cloud depth plan" before this
> document existed. This is it, written after the fact for Phases 1–2 and
> forward from Phase 3.

---

## 1. The problem this exists to solve

Two complaints, one root cause.

**"The clouds look like crap."** They were three alpha-blended FBM *decals*
on concentric shells. A decal can carry a coverage map, but it cannot carry a
cloud, because there is no depth to integrate through. No dark bases, no
bright tops, no shafts, no limb puff — every fragment resolves to roughly the
same mid-grey, and the globe reads as smeared. Three separate mechanisms had
already been added trying to fake the missing dimension (layered per-deck
compositing, a mass-clumping S-curve, a relief bump + self-shadow pass), each
one buying a little and none of them addressing the fact that the medium had
no thickness.

**"Show the wind vectors with more relevance."** Four pressure levels were
rendered on four shells whose radii were *hand-tuned constants*
(1.003 / 1.008 / 1.013 / 1.018) rather than derived from altitude. Those
constants were not even proportional to real height — the low deck sat at
roughly 32× exaggeration while cirrus sat at 11× — so the drawn spacing
misreported which layers are close together. And at globe view all four are
within 0.015 R of each other, i.e. visually coincident: four sheets of
additive streaks stacked into one field of white spaghetti.

The root cause is the same in both: **the vertical dimension was decoration,
not geometry.**

---

## 2. Phase 1 — one owner for vertical exaggeration (`js/atmo-scale.js`)

Earth's weather column is 14 km on a 6371 km ball — 0.0022 R. Drawn true to
scale it is a coat of paint. So the stack is exaggerated. That is a deliberate
lie, and Phase 1's job is to tell it **once**, from real altitudes, with a
factor the UI discloses.

```
r(alt) = SURFACE_CLEARANCE_R + (alt_km / R_EARTH_KM) × E
```

- **One altitude table.** The pressure levels carry the same geopotential
  altitudes the multi-level advection forecaster steers with, so the drawn
  altitude and the modelled altitude cannot drift apart.
- **The clearance floor.** 10 m surface wind is 1.6e-6 R; at any honest
  exaggeration it z-fights the ground. Altitude is measured *up from* a fixed
  shell above the surface overlays, so the ground layer stays welded to the
  deck while everything above fans upward. Same shape as the Moon's
  `DESCENT_MIN_AGL_KM` — an offset above ground, not a scaled altitude, so
  the no-exaggeration path reproduces the historical radius exactly.
- **The ramp.** E rides camera range: ×10 from orbit (calibrated to reproduce
  the historical constants to within ~0.003 R — the ramp is for depth on
  approach, not for a different-looking planet from orbit) easing to ×55 on
  close approach, where the stack spans 1.003 → 1.093.

### The one rule that must not be broken

**The ramp is driven by CAMERA DISTANCE, never by altitude above the stack.**

This is the Mars `regionalReliefScale` lesson inverted into a case where it is
safe. There, the scale moved the drawn *ground*, so an AGL-driven controller
fed back through the surface it displaced and the descent stalled. Here the
exaggeration moves shells the camera does not stand on, and distance-to-centre
is user input, so `E = f(distance)` is a pure function with no loop. Driving
the ramp from height-above-nearest-shell reintroduces exactly the feedback the
Mars page had to unwind.

### Outer shells

Aurora / stratosphere haze / atmosphere rim are **not** on the troposphere
ramp — the auroral oval's real 100 km would put it past the camera's own orbit
at ×55. They are lifted only as far as they must be to stay above the marched
volume. This does move the aurora slightly even at globe view (1.019 → ~1.026),
and that is correct rather than drift: the historical constants were tuned
against decals with no vertical extent, and a volume that honestly occupies
0–14 km reaches higher than the old high-deck shell did.

**Gate:** `node tests/atmo-scale.mjs` — pins the calibration against the
historical constants, monotonicity of the ramp, that the stack never inverts
at any exaggeration, that the surface layer is pinned rather than scaled, and
that the outer shells only ever move up and only a little.

---

## 3. Phase 2 — volumetric clouds (`js/cloud-volume.js`)

A single-pass raymarch through the troposphere shell.

- Beer-Lambert extinction, dual-lobe Henyey-Greenstein phase, a short light
  march, the Wrenninge multiple-scattering octaves, a powder term for dark
  edges, a soft cylindrical planet shadow.
- **The data is unchanged.** Coverage still comes from the Open-Meteo
  low/mid/high channels and the satellite mosaic exactly as `CLOUD_FRAG`
  consumed them, IR deck routing included. The march decides where the mass
  *sits* in the column and how light moves through it. It never invents
  coverage.
- **The IR top is the volume's top.** The mosaic's B channel decoded against
  2 m temperature and a 6.5 K/km lapse is an *observed* cloud-top height. The
  decal shader could only use it to pick which of three flat shells to paint;
  here it sets the column's actual top, so a measured 13 km overshoot renders
  as a 13 km tower. Pixels no IR disc saw fall back to the model's nominal
  deck extents — procedural-fill regions grow no fake towers.

### Things that were bugs, and are now load-bearing comments

Each of these shipped broken once during the build and is called out in the
source, because each failed *silently* — the render was plausible and wrong:

1. **The FBM must be normalised to [0,1].** The coverage remap thresholds
   against `1 − cover`, so it assumes a unit-interval input. An un-normalised
   3-octave sum tops out at 0.875 and averages ~0.44, which made every cell
   under ~55% cover render as clear sky. The globe came back nearly cloudless
   and it read as "the feed isn't arriving".
2. **The output is PREMULTIPLIED.** `scattered` is already transmittance-
   weighted along the ray. With standard `(SRC_ALPHA, ONE_MINUS_SRC_ALPHA)`
   blending the GPU multiplies by alpha a second time and every cloud comes
   out half-lit and grey. The material uses `(ONE, ONE_MINUS_SRC_ALPHA)`.
3. **Single scattering alone is always too dark.** Almost every photon
   reaching your eye from a real cloud has bounced many times. Without the
   multiple-scattering octaves you get exactly the flat grey the decals were
   already stuck at — i.e. you do all the work of a raymarch and land back
   where you started.
4. **The domain warp is not optional.** Value noise on a cubic-interpolated
   lattice leaves axis-aligned straight edges, and the coverage threshold
   turns those into hard rectangular blobs — the globe renders *tiled*.
   `CLOUD_FRAG` hit the same wall and fixed it the same way.
5. **Extinction must scale with shell thickness.** Optical depth is a property
   of the cloud, not of how far the ramp has stretched the shell it is drawn
   in. Without the division, zooming in silently thickens every cloud into a
   white wall.
6. **Clear air must integrate to exactly zero.** Densities of a few
   thousandths contribute nothing individually and accumulate over ~48 steps
   into a uniform grey veil — the same haze the decal shader's base-coverage
   floor produced, arriving by a different route.

### Routing and cost

Four paths, one live at a time: **volumetric / split / composite / off.**

- Volumetric requires the top governor tier, research mode off, and
  **arming**. The path does not start on: the page renders on the decals until
  it has sustained the top tier for ~90 real frames. The governor is reactive,
  and entering the most expensive draw on frame 1 means a weak GPU pays full
  march cost exactly while the page is still booting — and at software-GL
  speeds a single frame can take long enough that the main thread never
  yields, starving the governor's own re-evaluation so it cannot demote itself
  out of the hole.
- **Research / measured-only never reaches the march.** Measured-only means
  alpha = data; a march distributes that data through a column it did not
  measure. Same exclusion the split shells have.
- The decal shells stay live as the fallback for every other state, software
  GL included. Neither path is dead code.

**Hatches:** `?volumetric=0|1`, `?cloud_steps=N`,
`window.setVolumetricClouds()`, `window.setCloudMarchSteps()`.

---

## 4. Phase 3 — the wind stack

- Levels declare `altKm`, not `radius`. Every shell radius is derived from the
  live exaggeration.
- **A wiring bug the ramp exposed:** levels are created lazily on first enable
  and `_applyAtmoScale` early-returns while the exaggeration is unchanged, so
  a level switched on at a resting camera kept its construction radius until
  the user next dollied — 850 hPa silently drawn at the wrong altitude
  relative to the rest of the stack. `_ensureWindLevel` now seats new instances
  at the live exaggeration. (The same class of bug bit the ramp's own first
  call: the deadband matched on frame 1 and left every uniform at its factory
  default, which parked the volumetric carrier mesh *inside the planet*.)
- **The camera floor.** Was 1.025, "just above the whole translucent shell
  stack". Both halves of that rationale are gone: the stack ramps, and the
  clouds are one raymarch that integrates front-to-back internally while the
  wind trails blend additively — additive blending commutes, so neither cares
  what order the camera crosses them in. The floor is now a *ground* clearance,
  and the camera descends into the stack.
- **Trail brightness vs. zoom was backwards.** It ran `1.0 + 0.7·zoom01`,
  dimmest at globe view — which is where the field is densest. Blending is
  additive, so on-screen brightness is the *sum* of every trail crossing a
  pixel; at globe view a few thousand trails pile up until the sum clips,
  which is what turned the layer into a flat white haze and destroyed the
  speed colour ramp along with it. Now `0.62 + 1.08·zoom01`: dimmer per trail
  when they are stacked, brighter when they are sparse, with the close-zoom
  end unchanged.

- **Colour (2026-10-27).** The four per-level hue families (blue→magenta,
  sage→amber, violet→cyan, crimson→gold) are gone. `js/wind-palette.js` is
  the ONE wind ramp — blue, brighter = faster, deeper shade = lower altitude
  from the same altitude table above — read by the trails, arrows, columns
  and legends. See `EARTHVIEW_VISUAL_DIALIN_PLAN.md` §3.1.
- **Compositing (2026-10-27).** The additive clip the dimming above only
  postponed is gone: `js/wind-trail-compositor.js` sums the trails
  offscreen, knees the sum once (hue-preserving) and composites it over the
  scene. Plan §3.1a.

### Vertical profile columns (`js/wind-column.js`)

What four separate streak fields structurally cannot show: how the wind
changes with **height**. A mast rises through every enabled level with a
downwind arrow planted at each, so veering, backing and speed shear read as
one shape.

- It computes nothing. Every vector comes from the same per-level bilinear
  lookup the trails advect against, so a column and the streaks around it
  cannot disagree.
- **A level whose feed is down plants no arrow** — never a zero-length one,
  which would claim a calm the feed never reported.
- Gated on close zoom **and** ≥2 live levels. With one level there is no
  profile, and `windArrows` already does that job.
- Arrow length carries speed as well as colour, deliberately redundant:
  colour alone is unreliable for readers with colour-vision deficiency, and
  length survives the additive-blend saturation that flattens colour in dense
  fields.

**Gates:** `node tests/wind-column.mjs` (orthonormality of the local frame
against a finite difference of the position mapping — three bugs in this
repo's history came from re-deriving a local frame by hand; no-data-is-not-calm;
grid stability and bounds) and `npx playwright test tests/atmo-stack-smoke.spec.js`.

---

## 5. Disclosure

The stack is stretched and the page says so, live, in the wind legend
(`#wind-exag-note`). A silent exaggeration is a lie about altitude on a page
people read altitude off. `?vexag=N` / `window.setVerticalExaggeration(N)`
pins it; `window.getVerticalExaggeration()` reads it. The disclosure test in
`atmo-stack-smoke.spec.js` asserts the *displayed* number matches the *live*
one — a stale disclosure is worse than none.

---

## 6. Phase 4 — the clock (2026-09)

Two reports, one diagnosis: **"the clouds keep regressing"** and **"the
scrubber doesn't move the clouds."**

### 6.1 Why it kept regressing

Four render paths, one live at a time, chosen by a *reactive* governor. The
march ran only at the top tier; the first demotion swapped it for the decal
shells, the decals ran fast enough to promote again, and the page
ping-ponged between two different-looking planets every few seconds on
exactly the mid-range GPU (DPR 2 laptop) most visitors have. Each swap read
as a regression because it *was* a different renderer.

Two changes, both in `earth.html`:

- **The march stays live one tier down.** `_updateCloudShellMode` routes to
  the volume at `q > 0.45`; the tier step changes the step budget
  (48 → 28, via `marchLadder`), not the renderer. The floor tier still
  collapses to the composite decal. Gate: `atmo-stack-smoke.spec.js` asserts
  `setCloudQuality(0.66)` stays `volumetric`.
- **Half resolution.** `VolumeCompositor` (js/cloud-volume.js) renders the
  carrier mesh into an offscreen target at 0.5× the drawing buffer and
  composites it through a screen quad with the same premultiplied blend at
  the same renderOrder. ~4× on fill rate, HalfFloat where the context can
  render to it so HDR cloud tops still reach the bloom. `?cloud_res=1` for
  A/B; `window.setCloudResolution()`.

Plus the light march now runs on alternate primary steps (its result is
reused; it varies slowly along the ray and was the dominant cost).

### 6.2 The mosaic has a time dimension

`js/cloud-time.js` is the ONE copy of how the layer relates to the clock,
pure and node-gated (`tests/cloud-time.mjs`). `SatelliteFeed.setTime()`
follows the bus like `EarthObsFeed` does: a scrubbed instant resolves to
one of five modes —

| mode | frame | weight | when |
|------|-------|--------|------|
| live | newest | 1 | within a cadence of wall clock |
| replay | the 10-min frame ≤ t, fetched by **explicit timestamp** | 1 | the past, inside the archive |
| nowcast | newest, **advected forward by the model wind** | 1 → 0.35 over 3 h | the near future |
| model | none | 0 | further ahead — no observation exists |
| unavailable | none | 0 | beyond retention, or a fetch that failed |

Frames are cached (4-slot LRU keyed on frame time; the on-screen frame and
its cross-fade partner are never evicted), network work waits for the drag
to settle with a 3 s leading-edge cap so 600× playback still advances, and
the live poll stops burning bandwidth while the view is parked in the past.
A replay miss is **reported**, never substituted with a nearer frame or a
date-only reference granule (`gibsTimeCandidates({ dateFallback: false })`)
— an observation of the wrong instant under a labelled time is worse than
none. The Cloud Cover row tooltip says which mode is on screen; the status
pip stays with the weather-grid pipeline (two writers on one title is how a
disclosure goes stale).

**The retention window is an assumption** (`MOSAIC.retentionMs`, 30 d) —
NASA is egress-blocked from the build sandbox. It is set wider than the
bus's −7 d so the only route to 'unavailable' is a real miss.

### 6.2a Plugging in live data

The cloud gates take their pixels from ONE switch,
`tests/helpers/cloud-source.mjs`, in three modes:

| mode | how | what it proves |
|------|-----|----------------|
| **live** | `CLOUD_LIVE=1 npx playwright test tests/cloud-live.spec.js --headed` (or `TEST_BASE_URL=https://parkersphysics.com` for production) | the real archive serves the scrubbed frame by timestamp, the live grid drives a real wind field, a paused instant renders steadily on real data, and **how far back GIBS reaches** — the number that settles `MOSAIC.retentionMs`. Screenshots + `report.json` land in `test-results/cloud-live/`. |
| **fixture** | `node scripts/fetch-cloud-fixtures.mjs --probe` on a networked machine, then the ordinary gates | `tests/fixtures/clouds/` holds real frames at −0/−3/−6 h plus the live grid; `cloud-timeline.spec.js` answers every GIBS request from them, egress-free. `archive-probe.json` records the reach. |
| **synthetic** | nothing present (the build sandbox) | routing, modes, timing, shader compile — with banded stubs. |

`--headed` matters: headless Chromium draws on SwiftShader, so the live
gate on a laptop should run on the machine's GPU to see the march the way
a visitor does. `CLOUD_STEPS=12` caps the march if a run is too slow.

### 6.3 Motion comes from the wind, and the clouds run on sim time

- `u_sim_time` is simulation seconds relative to a page epoch (an absolute
  epoch-ms has 128 s of float32 precision). Pause freezes the clouds, 60×
  runs them 60× faster, a revisited instant renders the same. The morph is
  per sim-*minute* what the old wall-clock drift was per second — real
  cloud morphology evolves over hours; the wind carries the visible motion.
- **Flow-map noise.** The sample point is displaced upstream by
  phase × period × wind (stronger aloft, `windGainAt`) on two layers half a
  period apart, cross-faded so each reset hides under the other (Vlachos).
  The phases are computed once per frame on the JS side (`writeFlowUniforms`)
  so the branch on the blend weight is uniform and a fresh reset costs one
  noise evaluation, not two. The domain warp is evaluated once, un-advected,
  and applied to both layers — its job is to break the lattice, which a
  static large-scale distortion does as well, at a third of the cost.
- **The mosaic is sampled upstream** by (sim time − frame time) × wind in
  both the volume and the decal (`advectSat` in CLOUD_FRAG mirrors
  `advectDir` in VOLUME_FRAG mirrors `advectDirection` in cloud-time.js; the
  gate pins the JS against a hand calculation and the shader against the
  interpolated constants). A 10-min frame *moves* for the minutes it stands
  in for, the next frame lands where the last one drifted to, and the same
  tap with a lead of hours is the nowcast. Leads are clamped at ±4 h so a
  stale feed can never smear the observation off the globe. The wind is the
  scrubbed 10 m field the particles advect on, packed to an RGBA8 texture
  on every weather-update (260 KB; the ~1 MB Float32 copy that used to live
  there was removed as "nothing samples it" — now something does).
- The wind-aloft gain is a **stated approximation** until the pressure-level
  winds ride the same hourly ring.

### 6.4 Two lighting bugs the sunward capture exposed (2026-09-24)

Rendered in the sandbox against a synthetic 45 %-cover mosaic, camera aimed
along the page's own sun vector (`window.__evSetCamDir(...__evSunDir())`):

- **The powder term was inverted.** Its blend weight was
  `clamp(cosT·0.5 + 0.5)`: full when looking *toward* the sun, zero in
  back-scatter — the opposite of the effect it names (edges darker than
  interiors when the sun is behind the viewer, i.e. the whole sunlit
  hemisphere seen from orbit). Now `clamp(−cosT·0.5 + 0.5)`.
- **Sunlit tops clipped to flat white.** The three multiple-scattering
  octaves were summed raw (1 + 0.52 + 0.27 = 1.79× single scatter) on top
  of the sky ambient, so a lit top reached radiance ~1.8 and the ACES
  shoulder plus bloom flattened every cloud into a cut-out. `msScatter` now
  divides by the octaves' total weight: the octaves shape the falloff,
  they are not extra energy.

Both were invisible in every earlier capture because every earlier capture
looked at the terminator or the night side. A frame of the sunlit
hemisphere is now part of the live gate for that reason.

Gates: `node tests/cloud-time.mjs tests/cloud-mosaic-core.mjs` +
`npx playwright test tests/cloud-timeline.spec.js tests/atmo-stack-smoke.spec.js tests/cloud-shells-smoke.spec.js tests/cloud-mosaic-e2e.spec.js`.

## 7. Known limits / not yet done

- **Not validated against real imagery.** The build sandbox is egress-blocked
  from NASA GIBS, Open-Meteo and the Blue Marble CDN, so every screenshot
  behind this work was taken over synthetic circulation and a texture-less
  globe. The structural wins (contrast, terminator, cloud masses with real
  gaps, the fan-out) are visible regardless, but **the density / extinction
  tuning wants a pass against a live mosaic** — `u_density` in
  `createVolumeUniforms` is the single knob that trades "dramatic" against
  "washed out".
- **The march is not temporally reprojected.** Each frame marches from
  scratch with a per-frame (interleaved-gradient) jitter. A TAA-style
  history buffer would let the step count drop further, at the cost of
  ghosting on a rotating globe. Not attempted; the half-res compositor
  (§6.1) took the cheaper win first.
- **The half-res upsample is plain bilinear.** Clouds are soft so it holds,
  but a depth-aware / nearest-depth upsample would tighten the planet limb
  by half a pixel if it ever reads as a halo.
- **Winds aloft are a gain on the 10 m wind** (`windGainAt`), not the
  pressure-level fields. The 850/500/250 hPa winds exist (tempVolFeed) but
  do not ride the hourly ring the scrubber replays, so they cannot yet be
  the flow field without breaking time coherence. Next step: put them on
  the ring.
- **The mosaic archive window is assumed** (§6.2). One production request
  at a known-old timestamp settles it; `MOSAIC.retentionMs` is the knob.
- **Profile columns are not pickable.** Clicking one could pin the existing
  column probe card; today the two are unrelated features.
- **The decal (fallback) shader's own noise still runs on the animation
  clock.** Its mosaic sample follows sim time like the volume's; its FBM
  morph does not. It is the software-GL / phone path, and moving its
  morph onto sim time is one uniform swap plus a retune of three drift
  constants that were chosen for a wall-clock viewer.
