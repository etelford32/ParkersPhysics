/**
 * Vercel Edge Function: /api/health
 *
 * Sprint-0 diagnostic aid. Pings every upstream the space-weather data plane
 * depends on and returns a flat JSON summary so the next outage can be
 * triaged from one request instead of an archaeology session.
 *
 *   GET /api/health
 *   { ok, checked_at, summary:{up,down,total}, upstreams:[
 *       { source:'swpc-plasma', ok:true, latency_ms:142, http_status:200 }, … ] }
 *
 * Caveat baked into the payload: services.swpc.noaa.gov is fetched
 * BROWSER-side on the live page (NOAA's WAF 403s server-side calls), so a
 * `down` here for an `swpc-*` row means "unreachable from the Vercel edge",
 * NOT necessarily "down for users". DONKI / JPL rows are authoritative
 * because the page proxies those through the edge.
 */
import { jsonOk, fetchWithTimeout, DEFAULT_USER_AGENT } from './_lib/responses.js';
import { DONKI_HOSTS } from './_lib/donki-upstream.js';

export const config = { runtime: 'edge' };


// source → url. Kept tiny on purpose; HEAD-ish GETs with a short timeout.
const UPSTREAMS = [
    { source: 'swpc-plasma',  url: 'https://services.swpc.noaa.gov/json/rtsw/rtsw_wind_1m.json',          edge_authoritative: false },
    { source: 'swpc-mag',     url: 'https://services.swpc.noaa.gov/json/rtsw/rtsw_mag_1m.json',           edge_authoritative: false },
    { source: 'swpc-kp',      url: 'https://services.swpc.noaa.gov/json/planetary_k_index_1m.json',       edge_authoritative: false },
    { source: 'swpc-xray',    url: 'https://services.swpc.noaa.gov/json/goes/primary/xrays-1-day.json',   edge_authoritative: false },
    { source: 'swpc-alerts',  url: 'https://services.swpc.noaa.gov/products/alerts.json',                 edge_authoritative: false },
    // Story 4.2 operator-readout feeds (browser-direct on the page; an edge
    // 403 here is expected, like the other swpc-* rows — ρ@400 is on-device
    // so it has no upstream to ping and is intentionally not listed).
    { source: 'swpc-dst-kyoto', url: 'https://services.swpc.noaa.gov/products/kyoto-dst.json',                  edge_authoritative: false },
    { source: 'swpc-f107',      url: 'https://services.swpc.noaa.gov/json/f107_cm_flux.json',                   edge_authoritative: false },
    { source: 'swpc-ap-daily',  url: 'https://services.swpc.noaa.gov/text/daily-geomagnetic-indices.txt',       edge_authoritative: false },
    // DONKI moved 2026-09-30 (api/_lib/donki-upstream.js header). The old
    // kauai URL kept answering 200 with an HTML announcement page, so this
    // row stayed green for eleven days while every DONKI route 503'd —
    // hence `expectJson`: a 200 that is not JSON is DOWN.
    // The new host answers 400 without an explicit range, so the window is
    // built per request (a getter — ping() destructures `url` each call).
    { source: 'donki-cme', get url() {
        const d = (ms) => new Date(ms).toISOString().slice(0, 10);
        return `${DONKI_HOSTS[0].base}/CME?startDate=${d(Date.now() - 86_400_000)}&endDate=${d(Date.now())}`;
    }, edge_authoritative: true, expectJson: true },
    // SDO browse frames — proxied by /api/solar/aia (the observed disk on
    // sun.html + the Stage / globe / heliosphere live Suns), so this row IS
    // authoritative. Smallest frame NASA serves, to keep the probe cheap.
    { source: 'sdo-latest',   url: 'https://sdo.gsfc.nasa.gov/assets/img/latest/latest_512_HMIIC.jpg', edge_authoritative: true },
    // GOES/SUVI, the off-limb layer's wide-field source. This is the HEAD of
    // js/suvi-geometry.js's candidate list — UNVERIFIED until one production
    // request settles it, so a red row here may mean the path, not the feed.
    // /api/solar/aia?channel=suvi304&meta=1 reports every candidate's status.
    { source: 'goes-suvi',    url: 'https://services.swpc.noaa.gov/images/animations/suvi/primary/304/latest.png', edge_authoritative: true },
    // LMSAL HEK — proxied by /api/hek/coronal-holes and /api/hek/filaments
    // (the coronal-hole cells on the space-weather globe, and the COOL-MATERIAL
    // channel of sun.html's volumetric corona). Authoritative for both. The
    // probe asks for a single row over a one-hour window so it stays cheap;
    // HEK is regularly >8 s cold, hence the generous timeouts on both routes.
    { source: 'lmsal-hek',    url: 'https://www.lmsal.com/hek/her?cmd=search&type=column&event_type=ch&event_starttime=2026-01-01T00:00:00&event_endtime=2026-01-01T01:00:00&result_limit=1&cosec=2', edge_authoritative: true },
    // Mars upstreams. Both are proxied through the edge (/api/mars/route and
    // /api/mars/weather), so these rows ARE authoritative. mars.nasa.gov has
    // been intermittent since 2024 — a `down` here is the expected steady
    // state for mars-rss and explains an amber mars-weather row on the status
    // board. jpl-horizons above already covers /api/mars/ephemeris.
    { source: 'mars-mmgis',   url: 'https://mars.nasa.gov/mmgis-maps/M20/Layers/json/M20_waypoints.json', edge_authoritative: true },
    { source: 'mars-rss',     url: 'https://mars.nasa.gov/rss/api/?feed=weather&category=mars2020&feedtype=json', edge_authoritative: true },
    { source: 'jpl-horizons', url: 'https://ssd.jpl.nasa.gov/api/horizons.api?format=json&COMMAND=%27399%27&EPHEM_TYPE=VECTORS&CENTER=%27500@10%27&START_TIME=%272026-01-01%27&STOP_TIME=%272026-01-02%27&STEP_SIZE=%271%20d%27', edge_authoritative: true },
    // JPL SSD small-body services — proxied by /api/neo/catalog and
    // /api/neo/watch (solar-system.html NEO layer), so this row IS
    // authoritative. The cheapest call on that host: one fireball row.
    { source: 'jpl-ssd-api',  url: 'https://ssd-api.jpl.nasa.gov/fireball.api?limit=1', edge_authoritative: true },
    // Environment upstreams. Both are proxied through the edge
    // (/api/wildfires/events, /api/air-quality/{grid,centers}), so these
    // rows are authoritative for the EarthView pollution/wildfire layers
    // and the Pollution Lab. The single-point CAMS probe is the cheapest
    // request that exercises the real air-quality API path.
    { source: 'eonet-wildfires', url: 'https://eonet.gsfc.nasa.gov/api/v3/events?category=wildfires&status=open&limit=1', edge_authoritative: true },
    { source: 'open-meteo-cams', url: 'https://air-quality-api.open-meteo.com/v1/air-quality?latitude=28.61&longitude=77.21&current=us_aqi', edge_authoritative: true },
];

async function ping({ source, url, edge_authoritative, expectJson = false }) {
    const t0 = Date.now();
    try {
        const res = await fetchWithTimeout(url, { timeoutMs: 8000, headers: { Accept: 'application/json' } });
        const type = res.headers.get('content-type') || '';
        const wrongType = expectJson && res.ok && !/json/i.test(type);
        res.body?.cancel?.();
        return {
            source,
            ok: res.ok && !wrongType,
            ...(wrongType ? { error: `expected JSON, got ${type.split(';')[0] || 'no content-type'}` } : {}),
            http_status: res.status,
            latency_ms: Date.now() - t0,
            edge_authoritative,
        };
    } catch (e) {
        return {
            source,
            ok: false,
            http_status: null,
            latency_ms: Date.now() - t0,
            error: e?.name === 'TimeoutError' ? 'timeout' : (e?.message ?? 'fetch_failed'),
            edge_authoritative,
        };
    }
}

/**
 * Credential PRESENCE report (never values). The 2026-07 feed audit found
 * the #1 diagnosability gap was silent DEMO_KEY fallback: every DONKI proxy
 * quietly degrades to api.nasa.gov's 30 req/hr shared demo quota when
 * NASA_API_KEY is unset, and nothing anywhere said so. Each entry is
 * {status, note} where status ∈ ok | degraded | off.
 */
function credentialPresence() {
    const env = (typeof process !== 'undefined' && process.env) || {};
    const has = (...names) => names.some((n) => !!env[n]);
    return {
        nasa_api_key: has('NASA_API_KEY')
            ? { status: 'ok', note: 'configured — full DONKI quota' }
            : { status: 'degraded', note: 'DEMO_KEY fallback — 30 req/hr shared quota throttles DONKI (CME/flares/SEP/GST)' },
        nasa_earthdata_token: has('NASA_EARTHDATA_TOKEN')
            ? { status: 'ok', note: 'set (unused today — reserved for the GES DISC/OPeNDAP numeric-grid path)' }
            : { status: 'off', note: 'not set — nothing consumes it yet; GIBS imagery is keyless' },
        metno_user_agent: has('METNO_USER_AGENT')
            ? { status: 'ok', note: 'configured' }
            : { status: 'degraded', note: 'default UA — MET.no policy prefers a contactable identifier' },
        nws_user_agent: has('NWS_USER_AGENT')
            ? { status: 'ok', note: 'configured' }
            : { status: 'degraded', note: 'default UA — api.weather.gov may throttle' },
        supabase_service_key: has('SUPABASE_SERVICE_KEY', 'SUPABASE_SECRET_KEY')
            ? { status: 'ok', note: 'configured' }
            : { status: 'off', note: 'MISSING — cron writes, caches, and heartbeats are down' },
        resend_api_key: has('RESEND_API_KEY')
            ? { status: 'ok', note: 'configured' }
            : { status: 'off', note: 'missing — all outbound email (alerts, digests) disabled' },
        cron_secret: has('CRON_SECRET')
            ? { status: 'ok', note: 'configured — manual cron kicks accepted' }
            : { status: 'degraded', note: 'not set — crons run on the Vercel header only; no manual kicks' },
        r2_mirror: has('R2_ACCOUNT_ID')
            ? { status: 'ok', note: 'configured — density/far-side mirrors active' }
            : { status: 'degraded', note: 'not set — TU Delft density + far-side fall back to live upstreams' },
        slack_webhook: has('SLACK_WEBHOOK_URL')
            ? { status: 'ok', note: 'configured' }
            : { status: 'off', note: 'not set — watchdog alerts go to email only' },
    };
}

export default async function handler() {
    const upstreams = await Promise.all(UPSTREAMS.map(ping));
    const up   = upstreams.filter(u => u.ok).length;
    const down = upstreams.length - up;
    // "ok" reflects only edge-authoritative upstreams — an swpc-* edge 403 is
    // expected (browser fetches those) and must not flip the overall health.
    const authoritativeDown = upstreams.filter(u => u.edge_authoritative && !u.ok).length;
    return jsonOk({
        ok: authoritativeDown === 0,
        checked_at: new Date().toISOString(),
        note: 'swpc-* rows are fetched browser-side on the live page; an edge 403 there is expected and does not affect users.',
        summary: { up, down, total: upstreams.length },
        upstreams,
        credentials: credentialPresence(),
    }, { maxAge: 30, swr: 15 });
}
