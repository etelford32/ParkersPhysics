# SUN_VISUALS_WORLD_CLASS_PLAN.md — the observed Sun, rendered like an engine would

> Plan to take `sun.html` from "procedural model with SDO reference images
> in a side drawer" to "the real Sun, live, wrapped on the sphere by
> default, with an engine-grade HDR render pipeline around it". Read
> CLAUDE.md §4 (load-bearing invariants) and §5 (the reversion pattern)
> before touching any of the files named here; read
> `SUN_CONVECTION_UPGRADE_PLAN.md` for the convection work this plan sits on
> top of and does NOT redo.

*Status: Phases 0–3 IMPLEMENTED (2026-09-06); Phases 4–6 planned. Decisions
in §1 are locked by the repo owner.*

### Progress log

- **2026-09-06** — plan written. Owner decisions: no game engine (§2),
  observed-by-default disk (§1).
- **2026-09-06 — Phase 0 (done, software-GL half).** `tests/sun-visual.spec.js`
  (`@gpu`, skipped unless `SUN_GPU=1`; 6 scenes × 720p/1440p; fixtures
  routed, off-origin blocked, sim clock frozen via `__sun.freeze`), the
  `snapshotPathTemplate` in `playwright.config.js` → `tests/__visual__/`,
  `window.__sun.perf` (p50/p95 over 120 frames) and `__sun.freeze`.
  **NASA egress is blocked from the build sandbox**, so the committed
  fixtures are SYNTHETIC (`tests/fixtures/sdo/synthetic_*.png`, 512², ~0.9 MB,
  rendered by `scripts/make-sdo-synthetic-fixtures.mjs` with the real
  browse-frame geometry + three planted ARs; README in the folder says so).
  `scripts/fetch-sdo-fixtures.mjs` writes the real set on a machine with
  egress and the visual spec prefers it. **The baseline PNGs are NOT yet
  captured** — that half of Phase 0 needs the owner's GPU:
  `SUN_GPU=1 npx playwright test tests/sun-visual.spec.js --update-snapshots`,
  then commit `tests/__visual__/` and add the GPU + perf numbers here.
- **2026-09-06 — Phase 1 (done).** `js/sun-observed.js` (pure half:
  Meeus B0/P ephemeris — pinned to the ±7.25° / ±26.25° extremes —,
  disk→sphere projection, disk MEASUREMENT from the decoded frame with
  per-instrument fallbacks, chip label; browser half: fetch through the
  proxy, cross-fade, keep-last-good, visibility-aware refresh),
  `tests/sun-observed.mjs` (17 checks incl. the 1.5° AR-alignment tolerance
  on the fixture ground truth), sunFS observed sample + composite (white
  light, EUV, magnetogram; far-side 15° graticule), the `#sun-provenance`
  chip (top-centre; click toggles Observed ↔ Model; `?observed=0`),
  `api/solar/aia.js` provenance headers + `meta=1` JSON, `solar-aia`
  registered in `js/pipeline-registry.js` (it had been unmonitored since
  July) + `sdo-latest` in `api/health.js`. `tests/sun-smoke.spec.js` gains
  four tests (feed-down → MODEL, observed boot, channel/cutaway/Doppler/chip
  round-trips, `?observed=0`); all 10 green on software GL. Verified by
  eye on software GL only: the planted west spot lands upper-right, the east
  spots left, north up. **Decisions and findings made while building:**
  - **Observed ⇒ real-time rotation.** The page's sim rotates ~2900× real
    time (0.014 rad per sim unit at 0.6 units/s), which would carry an
    observed frame off the near side in ~6 min. While Observed is on,
    `u_rot` = `REAL_TIME_ROT_MUL` × the rotation slider (one synodic
    rotation in 27.28 d); Model restores the slider's sim rate; the HUD
    says "real-time". The frame is also de-rotated in sunFS by exactly the
    AR-slot rotation, so image spots and shader spots stay locked whatever
    the clock does.
  - **Pre-existing discrepancy, not touched:** the AR slots (`u_arSpots`)
    rotate EASTWARD at 0.014 rad/unit while the marker `regionGroup`
    rotates WESTWARD at 0.004·2π/unit (`solarRotAngle`) — markers and
    shader sunspots have always drifted apart at sim rate. Invisible at
    real-time rate; a Phase 4 fix candidate (make both the slot math).
  - **B0 is applied, P is not.** NASA's browse frames are north-up, so only
    B0 (disk-centre latitude, up to ±7.25°) orients the projection; P is
    computed and shown in the chip tooltip as `not applied`. The default
    camera now sits on Earth's direction `(0, sin B0, cos B0)` so the
    visible limb and the observed/model terminator coincide on load.
  - **Disk radius is measured, per instrument.** HMI ≈ 0.465 and AIA ≈
    0.390 of the frame radius (plate scales differ). The Stage
    (`js/stage/stage.js:307`) uses 0.485 for both, ~25 % too large for its
    171 shell — recorded here, not fixed here (different page).
  - **Far-side graticule is 15°, not the 3° the plan first said** — 3° is
    a moiré at 128 segments. GONG far-side seeding of the far hemisphere is
    DEFERRED (the `series` format exists on `/api/solar/farside`; wiring it
    into a plage term is a small follow-up, listed in §9).
  - **HMI tint** `u_obsTint` (1.25, 1.02, 0.70) and the observed/procedural
    seam brightness were set on software GL and need the owner's eye; both
    are live on `__sun.uniforms`.
- **2026-09-06 — Phase 2 (done).** `js/sun-post.js`: ONE composer pass
  replacing both `UnrealBloomPass`es and the retired radial K-corona gather
  (`radialDiffusePass` + its 80-line shader are deleted — Phase 3's Thomson
  K-corona replaces what it approximated). Jimenez mip-chain bloom (13-tap
  downsample, Karis average on mip 0, six half-res mips at 720p, 9-tap tent
  upsample, no threshold ⇒ no rings), GPU 1×1 log-luminance reduction read
  back every 4 frames into the PURE `ExposureController`
  (`tests/sun-post.mjs`, 6 checks: geometric-mean calibration, τ 1.2 s /
  0.5 s asymmetry to 63.2 %, EV clamps, NaN-safe, recalibrate), soft
  shoulder above 1.0, dither, and lens effects (ghosts / CA / grain) behind
  `?lens=1` — OFF in Observed by default. `__sun.post.state` exposes EV,
  L̄, strength, mips. Smoke spec asserts the chain is live (6 mips, finite
  readback, lens off). The two rendering-panel bloom checkboxes still work
  (ambient = base strength, flare = boost). **Findings:**
  - **A global strength boost on an un-thresholded bloom lit the whole disk
    white on an X-flare (measured).** The flare boost is therefore applied
    to the BRIGHT PASS of the blurred image only (`max(bloom − 0.65, 0)`),
    which is what "tight, on-demand" meant in the old two-pass design.
  - **Lens ghosts must read the NORMALISED bloom** — `tBloom` is the sum of
    the whole chain (n+1 mips); an un-normalised ghost read blew the disk
    out at 7× (measured). Ghosts also threshold at 0.55 so the disk's own
    glow cannot re-light the disk.
  - **The flare kernel / ribbons / arcade / EIT wave are captured as
    `flareAdd`** (everything that section adds to `col`) and drawn ON TOP
    of the observed disk at 0.7 as an event overlay — the observed mix had
    silently erased the page's GOES-driven flare visuals on the near side.
    Observed pixels are still never recoloured; this is an additive marker.
  - **Exposure calibration is frame-count based** (20 readbacks × every 4
    frames = 80 frames ≈ 1.3 s at 60 fps); on software GL (~2 fps) it
    reaches calibration only after ~40 s, so headless screenshots show
    EV 0 — expected, not a fault.
  - **Colour pipeline is still display-referred upstream** (sunFS's own
    acesFilm; no OutputPass). The exposure multiply here is adaptation on
    tonemapped input; moving tone mapping to the end of the chain is Phase 6.
- **2026-09-06 — Phase 3 (done).** The volumetric AIA corona
  (`js/corona-volumetric.js`) is now the DEFAULT corona of every EUV channel
  view — it had been hiding behind `?corona=volumetric` while the channel
  views drew NO corona at all. It mounts lazily on the first channel view
  (`ensureVolumetricCorona()` in sun.html), renders on camera layer 1 through
  the new `js/corona-accumulate.js` pass (interleaved-gradient jitter per
  pixel advanced by the golden ratio per frame; history blended 1/(n+1)
  down to 1/33 while the camera is still; any camera motion, channel switch,
  AR update or loop rebuild resets — no reprojection needed for an additive,
  camera-locked layer), and lights its arcades from the PFSS-lite atlas
  splatted into a loop-density volume (`js/corona-loop-density.js`, PURE:
  R = closed lines → emission, G = open lines → topological coronal-hole
  suppression; `tests/corona-volumetric.mjs`, 10 checks). White light gains
  the Thomson K-corona + dust F-corona in coronaFS from the closed-form
  Baumbach–Allen LOS integrals (constants pinned by the node test and
  printed for the GLSL mirror; `u_kcorona` = 0 disables). **Findings:**
  - **`js/field-atlas.js` could never load its WASM**: `'./js/sunfield-wasm/…'`
    resolves relative to the module (already in `js/`) → `js/js/…` → every
    atlas build, including `?debug=field` / `?debug=prominence`, had been
    failing silently. Fixed (one path); the loop volume now builds in
    ~70–120 ms for ~300 lines.
  - **The tracer's AR arcades peak only 0.005–0.008 R☉ up** (measured on
    three planted ARs; the seed ring sits at 0.04–0.10 rad and the buried
    dipole keeps those lines low). A 64³ Cartesian cube (voxel 0.078 R☉)
    could not resolve them and a 12-step chord march sampled that layer
    ~once — so the volume moved to a **256×128×32 SHELL grid** (lon × lat ×
    √-stretched height; slice 1 is at 1.5 Mm) and the march is **two-scale**
    (6 coarse steps outside r = 1.30, 10 fine steps inside, 6 coarse behind
    on limb rays; front-to-back order kept). A/B against the legacy march
    via `u_marchLegacy` (kept as the perf/brightness reference): mean
    accumulated brightness 0.0169 vs 0.0204, peak 0.79 vs 0.81 — same
    energy, finer structure. At the default framing the loops are still
    ~1 px tall; they show at the limb and when zoomed. **Raising the seed
    ring / apex heights to the observed 0.05–0.15 R☉ is a Rust change**
    (cargo test + WASM rebuild per CLAUDE.md) — Phase 4 candidate, not
    done here.
  - **The smoke suite's noise filter was swallowing shader-compile
    errors**: a failed compile dumps the GLSL source, whose comments mention
    swpc/noaa/sdo, so the whole message matched the "expected feed noise"
    regex. coronaFS failed to compile for an entire run while all 10 tests
    stayed green. `isExpectedNoise` now refuses anything matching
    `Shader Error|GLSL|ERROR: 0:|program not valid` before the feed regex.
  - The magnetogram view shows no EUV corona (a magnetogram has none); the
    layer toggle now routes to whichever corona renderer the view uses.
  - Verified on software GL only (2 fps, accumulation reaches ~18 frames in
    the screenshots); the K-corona is deliberately subtle (0.048 of the limb
    brightness at 2 R☉) and needs a GPU + real frames to judge.

- **2026-09-09 — Phase 2b: observed ↔ model photometric fusion (done).**
  Reported as "the sun visuals are kinda broken now", with a screenshot of the
  disk split into two unrelated halves along a hard vertical terminator.
  Reproduced locally (orbit the camera ~55° off the Sun–Earth line with a
  gold-colorized white-light frame) and traced to **three cliffs stacked on the
  same edge**:
  1. **μ MISMATCH.** A browse frame carries its limb darkening baked in at the
     EARTH's μ; the procedural half applied Neckel & Labs at the VIEWER's μ.
     Off-axis those are different angles for the same point, so the frame's
     dark limb butted against the model's bright disk centre.
  2. **TONEMAP ORDER.** The observed pixel was composited AFTER the ACES curve
     the model half goes through, so the observation rendered flat and
     desaturated beside a filmic model.
  3. **LUT DOUBLE-APPLY.** `u_obsTint` mapped "greyscale HMI → the page's
     palette", but `sdo.gsfc.nasa.gov/…/latest_1024_HMIIC.jpg` is a GOLD-
     COLORIZED browse product. Our fixtures are greyscale, which is exactly
     why CI never saw any of this.

  **The fix stops treating a browse JPEG as radiometry.** Its absolute level
  and colour LUT are display choices; what IS a measurement is the RELATIVE
  structure — how much brighter or darker the Sun is than its own smooth
  limb-darkened disk. `calibrateDisk()` in `js/sun-observed.js` (PURE) measures,
  per refresh and off the same 256² readback the geometry already used:
  `I0` (disk-centre LINEAR luminance — the sRGB EOTF is undone because the
  texture is tagged `SRGBColorSpace`, so the shader's `texture2D` returns
  linear and the two must agree), the frame's OWN 2-term limb law `(u1,u2)`
  fitted on μ-binned MEDIANS (medians so a sunspot cannot bend it; the affine
  form `a0 + a1x + a2x²` with `I0` a FREE parameter, because anchoring `I0` on
  the innermost shell at μ = 0.979 biased u1 low by 0.07 — a systematic that
  survives averaging), its `chroma` normalised to unit luminance, its resolved
  contrast `sigma`, and the fit `resid`. `ok` is gated on the RESIDUAL, never
  on agreement with a textbook coefficient — a browse product carries an
  arbitrary display stretch, so an HMI frame whose physical u1 ≈ 0.9
  legitimately fits ≈ 1.7 here, and clamping to the physics range is what
  disabled fusion on the first colorized frame it saw.

  sunFS then draws `obsRel = L/(I0·limbLaw(μ_Earth))` — dimensionless, ≈1 on
  the quiet Sun — on the model's own blackbody × Neckel & Labs at the VIEWER's
  μ, **before** the tonemap. Structure is 100 % the observation's; level,
  palette, view geometry and tone curve are the model's, so the hemispheres
  agree at the terminator by construction rather than by a tuned constant
  (`u_obsLevel` = 1.0 and is a trim, not a fudge). The handoff WIDTH rides
  `|μ_view − μ_Earth|`: at the default camera the viewer IS the observer, the
  correction is the identity and the frame is trusted to the limb; off-axis it
  opens to 0.55 so the model takes over gently. EUV/magnetogram keep the
  channel colour untouched and take the μ re-projection only (AIA fits limb
  BRIGHTENING — negative coefficients — so one machinery covers both
  instruments). An uncalibratable frame sets `u_obsFuse = 0` and falls back to
  the legacy tint; the disk still draws.

  **Gate:** `tests/sun-fusion.spec.js` — AZIMUTHAL ASYMMETRY of the rendered
  disk (every point on a ring is at the same μ and must be at the same level;
  limb darkening lives ring-to-ring and cancels within a ring; sector MEDIANS
  and an IQR so a sunspot is a minority and a hemisphere is not). Self-
  validating: it measures the fused page AND the page with `u_obsFuse` forced
  to 0. **Inner disk 0.001–0.045 fused vs 0.20–0.31 legacy** — an order of
  magnitude, and the legacy path is broken at every radius including disk
  centre. Three metrics were tried and discarded first (5-px window
  differencing → scored granulation; low-pass + 2nd difference → scored a
  sunspot; straddling median patches → scored limb darkening); the spec
  records all three so the next session does not re-derive them.
  `tests/sun-observed.mjs` 17 → 24 checks, incl. the double-apply gate: a
  gold-colorized frame and its greyscale twin must yield the same law and the
  same `obsRel` field to 3 %.

- **2026-09-09 — nanoflares as a population, not a twinkle (done).**
  `js/sun-nanoflares.js` (PURE, `tests/sun-nanoflares.mjs`, 20 checks). The
  photosphere shader's old term put a few sites inside each active region on a
  `pow(sin, 9)` clock: it **fired only inside ARs** (which inverts Parker 1988
  — the proposal is about the QUIET corona, so a spotless Sun went dark) and
  had **no energy distribution**, hence no α to report or be wrong about.
  Now: a bounded power law dN/dE ∝ E^−α over 10²³–10²⁷ erg, sampled by inverse
  transform, with the duration–energy scaling T ∝ E^0.33; sites seeded over the
  whole surface weighted by where the field is braided (supergranular network
  lanes + a large AR boost). The shader uses the kernel's OWN transform, in
  log2(E) because the four-decade `B − A` loses the small end in float32, so
  the rendered population really carries the index the readout quotes — and the
  test measures that slope back out of 400k draws rather than trusting it.
  **The α = 2 threshold (Hudson 1991) is the point:** below it the large events
  carry the budget, above it the unresolved small ones do, and the published
  measurements straddle it (Crosby 1993 ≈ 1.8 … Krucker & Benz 1998 ≈ 2.45,
  all five on the slider's datalist). The readout scores the population against
  Withbroe & Noyes (1977) 3 × 10⁵ erg cm⁻² s⁻¹ and names the requirement.
  ONE kernel now feeds three consumers: the photospheric population, the
  loop-anchored Poisson sparks (which had a second hard-coded α = 2.2 and its
  own inverse-CDF), and the SOC avalanche grid — whose α is **EMERGENT**, so it
  is MEASURED (`AlphaMonitor`, bounded-power-law MLE by ternary search on the
  exact log-likelihood, NOT a binned log-log regression; the test shows it
  beating one on the same draw) and reported separately as `α_obs`.

  **Findings from actually measuring it:**
  - **The SOC grid never reached criticality for most visitors.** Stress was
    seeded at zero against `SOC_S_CRIT = 0.85` with `SOC_INJECT = 0.004`/sim-s,
    so the first avalanche was ~212 sim-seconds out — three and a half minutes
    of a nanoflare layer doing nothing. The stress field is now seeded as a
    SPREAD below critical (`0.40–0.95 × S_crit`), which is where an SOC system
    is defined to live anyway; a flat seed at critical would tip everywhere at
    once and open with one synchronised avalanche, so the spread is the point.
    Events now start within seconds.
  - **The monitor was measuring the wrong quantity, then the unit convention.**
    First it was fed one push per spawned SPARK, i.e. single-cell excesses,
    which are all within a whisker of the toppling threshold — a narrow,
    degenerate sample. It now takes one push per CASCADE carrying the cascade's
    total released energy, which is what flare statistics are about. Second,
    those energies are in the model's own stress units and span well under the
    kernel's nominal four decades, so fitting against the nominal range measured
    the erg mapping rather than the physics (α pinned at the search bound).
    `fitAlphaMLE` gained `autoRange`, fitting over the range the sample spans —
    legitimate because a power-law index is invariant under E → cE, which the
    test asserts directly.
  - **This grid's avalanche sizes are NOT power-law distributed**, and the page
    now says so instead of quoting an index. Best bounded-power-law fit sits at
    the estimator's lower search bound with KS ≈ 0.45 over ~180 cascades. The
    obvious suspect — dissipation, since SOC is scale-free only under
    near-conservative redistribution — was swept (`SOC_PROPAGATE` 0.65 → 0.85 →
    0.95 → 1.00, monitor reset between runs) and **made no difference**
    (KS 0.46 / 0.52 / 0.42 / 0.48). Recorded at the constant so it is not
    re-tried blind. Two untested suspects remain: the stress reset is to a fixed
    `S_CRIT·0.85` regardless of what the cell was carrying (so released energy
    is decoupled from redistribution), and the driver is 24 smooth Lorenz
    attractors, which is spatially correlated — cells tip in synchronised groups
    rather than in scale-free cascades. **Open follow-up.**
  - `fitAlphaMLE` therefore withholds on three separate grounds and the readout
    names which: fewer than 50 cascades, a KS distance that says the sample is
    not a power law, or a likelihood that ran to the edge of its search. The
    node test feeds it a log-normal to prove the KS guard bites.

- **2026-09-09 — the fluid solver was not enforcing incompressibility (fixed).**
  Found while gating the convection: `SolarFluid.probe()` reported residual
  |div| ≈ 1.2 RMS **that did not fall when the Jacobi count was tripled from 20
  to 60**, which is the signature of a solve that cannot see the error rather
  than one that has not converged. Cause: divergence and pressure gradient were
  BOTH central differences, and a central divergence of a central gradient is
  the WIDE (i±2) Laplacian — a different operator from the compact 5-point one
  the Jacobi inverts, whose null space is the odd–even checkerboard mode. So
  grid-scale divergence was invisible to the projection and survived it, every
  step, since the solver was written. The stencils are now **adjoint**
  (BACKWARD divergence, FORWARD gradient), which makes `div(grad p)` exactly
  the compact Laplacian; residual |div| 1.2 → 0.43 at 20 iterations and → 0.21
  at 40, i.e. it converges now. `iters` 20 → 26 in sun.html. Same class of bug
  in the curl-noise forcing: its stream-function difference used a fixed
  ε = 0.012 while the divergence operator used ±1 texel (0.0052), so the
  "divergence-free" forcing was injecting divergence every step; it now uses
  the matching central stencil, under which `div(curl ψ)` cancels exactly.

  With the projection actually working, **the surface is now convecting**:
  `∇·v` targets the local buoyancy `S ∝ (T − ⟨T⟩₃ₓ₃)` instead of 0, because the
  horizontal divergence of a convecting surface IS the vertical flow underneath
  it (`∇_h·v_h = −∂w/∂z`) — hot plasma boils OUT of granule centres and drains
  INTO the lanes. The local high-pass (rather than `T − T₀`) is load-bearing
  twice: it is zero-mean by construction so the Poisson problem stays solvable
  with no global reduction, and "buoyant relative to its surroundings" is the
  physically meaningful statement. Measured correlation between temperature
  excess and divergence: **0.70 coupled, −0.03 uncoupled**
  (`tests/sun-convection.spec.js`, which flips the coupling off to prove the
  gate measures the physics). Also added: explicit thermal diffusion, so the
  granule scale is a model parameter instead of the semi-Lagrangian's
  truncation error; and the Snodgrass & Ulrich (1990) differential rotation as
  a PRESCRIBED mean flow carried in the advection (not added to `vel`, or the
  projection would spend its iterations re-solving a flow we know in closed
  form). `probe()` auto-RANGES its two channels in both directions — a single
  calibration pass cannot fix an already-clipped channel, and that is how the
  first version of the gate scored a working solver as broken.

  Phase 4's planned `tests/solar-fluid.mjs` divergence assertion is partly
  discharged by this (measured in-browser rather than in node, because the
  solver is GPU-only); the cube-sphere domain is still open.

- **2026-09-15 — Phase 3b: the OBSERVED corona, off the limb (done).**
  `js/sun-observed.js` stopped at the limb, so everything the SDO frame carries
  outside ρ = 1 — prominences, post-flare arcades, streamer bases, every
  dimming and every eruption — was being thrown away. `js/sun-offlimb.js`
  (PURE half + `SunOffLimb`; `tests/sun-offlimb.mjs`, 17 checks) draws the
  1.0–1.6 R☉ annulus of the live **304 + 131** frames on a plane through Sun
  centre normal to the Sun–Earth line, additively, occluded by the
  photosphere, with a running-difference mode.

  **Why a plane is the honest place to put it.** An off-limb EUV pixel is not a
  measurement of a point: it is the line integral of ε along the ray whose
  closest approach to Sun centre is ρ. Plane-of-sky is its NATIVE geometry, and
  for a distant observer that plane IS the locus of closest approach — so the
  integral is drawn where the integral lives. Three consequences, all kept:
  the sphere OCCLUDES the far half (depth test, which is what makes the layer
  read as a 3-D object with the Sun in front of it); the plane does NOT
  co-rotate (a frame is a snapshot in the observer's frame — the Far-Side Watch
  rule, the clock moves the observer, not the data); and it FADES off-axis via
  `offAxisWeight`, the plane analogue of the per-fragment `stretch` term the
  disk fusion already uses. Full weight inside 12°, gone by 55°.

  **Findings:**
  - **The level reference is NOT `I0`.** The disk divides by the frame's own
    limb law at disk centre; off the limb there is no limb law, and disk centre
    is the wrong reference anyway — for 131 the disk is nearly empty while the
    off-limb arcade is the whole signal, so an I0 ratio would make the layer's
    brightness a function of the DISK. `calibrateOffLimb` measures the frame's
    own 1.05–1.15 R☉ REFERENCE SHELL (median, so one bright prominence cannot
    set the unit) and everything is drawn relative to that. A frame whose shell
    is black sets `ok = false` and the layer does not draw — dividing by ≈0
    would amplify JPEG ringing into a convincing corona.
  - **THERE HAS TO BE A DISPLAY STRETCH, and the first version did not have
    one.** Normalised by that shell the field spans ~70:1 between quiet corona
    and bright prominence. No linear gain shows both: hold the prominence and
    the corona is black, show the corona and every prominence clips. The layer
    draws √(L/ref) — the same square-root stretch AIA's own off-limb displays
    use — applied once, after the normalisation, on LUMINANCE (per-channel
    `pow` desaturates every bright feature toward white, i.e. recolours an
    observed pixel), and disclosed in the chip tooltip. Note for the next
    session: the 70:1 is partly the sRGB EOTF the texture tag applies — correct,
    and required for agreement with the disk path — re-expanding an 8:1 byte
    range. Do not "fix" the gain by turning it down until the prominences go.
  - **`REF_FLOOR` was a guess and the guess was wrong.** 2e-3 sat ABOVE what a
    faint 304 annulus carries, so the 304 channel calibrated only
    intermittently and the browser gate failed on 304 while passing on 131. It
    is now DERIVED: two 8-bit code values (`srgbToLinear(2)` ≈ 6.1e-4), which
    is the smallest signal a browse JPEG can distinguish from black.
  - **The synthetic fixtures could not exercise the layer.** All six AIA
    fixtures shared one faint halo (0.10·e^(−6(ρ−1))), which put the 304
    reference shell within a code value or two of black. `scripts/lib/sdo-synth.mjs`
    now renders a per-channel off-limb corona (304 bright and narrow, the
    coronal channels fainter and deeper) plus two PLANTED OFF-LIMB features at
    known plane-of-sky positions — a 304 prominence off the EAST limb and a
    131 arcade off the WEST — recorded in the manifest as `plantedOffLimb`.
    Fixtures regenerated.
  - **Gate:** five browser tests in `tests/sun-smoke.spec.js`, including an
    END-TO-END pixel gate that screenshots the page, finds each planted
    feature's screen position through the page's own camera, and asserts it is
    bright there and not at its MIRROR position — the handedness check, i.e.
    the class of bug that mirrored every SWPC flare until 2026-09-13. It
    measures with the layer on and off and divides out the scene underneath,
    so a gate that has stopped seeing the layer fails instead of passing.
    NOTE: comparing the two FEATURES to each other does not work and is not
    the test — each channel normalises by its own reference shell, so their
    relative brightness measures the fixture, not the mapping.

- **2026-09-15 — nanoflares moved to where an instrument could see them (done).**
  Two changes, one idea: a nanoflare is a 10²³–10²⁷ erg CORONAL energy release,
  so the white-light photospheric continuum cannot see one and each EUV channel
  sees it only as far as its temperature response reaches the event's own peak
  temperature.
  - **Out of white light.** The `col += … microflare …` line in sunFS is
    deleted. It was painting a 10²³ erg coronal event onto a continuum six to
    ten orders brighter.
  - **Into the EUV branches as campfires** (Berghmans et al. 2021,
    Solar Orbiter/EUI), at network lanes as before, but weighted by the ACTIVE
    channel's response — `u_nanoChan`, fed from `EUV_CHANNELS` via the new pure
    `channelResponseAt` in `js/corona-volumetric.js`, which is the raymarcher's
    own table. White light and the magnetogram carry σ = 0, so the response is
    identically zero and the campfires vanish there BY THE TABLE, not by a flag.
  - **`peakLogT` in `js/sun-nanoflares.js`** gives the event a temperature:
    T ∝ E^0.22 anchored at 1 MK for 10²⁴ erg (RTV family; Aschwanden & Parnell
    2002), an order-of-magnitude anchor and quoted as one. **The per-channel
    ordering everyone recognises from AIA movies is then EMERGENT**: the
    population is dominated by small, cool (log T ≈ 5.8) events, which is 171's
    peak, so 171 is full of campfires, 193 has fewer, 211 fewer still, and 94 /
    131 / 304 essentially none. `tests/sun-nanoflares.mjs` MEASURES that
    ordering out of 60 000 draws, and measures that moving α moves it — which a
    per-channel constant could not do.
  - **Size and duration are the kernel's too.** `sizeForKm` (L ∝ E^(1/3),
    1000 km at 10²⁴ — the bounded population then spans 464–10 000 km and the
    part α ≈ 2 makes commonest is the observed 400–4000 km campfire range) and
    the duration law fixed to the kernel's own E^0.33. The line replaced was
    LINEAR in normalised log-energy: right shape by accident, wrong law,
    spanning 8.4× where the exponent spans 21×. DISCLOSED FLOOR: a 1000 km
    campfire is ~0.3 px at the default framing, so the mark has a minimum
    angular size and the true diameters are quoted in the readout; above
    ~2×10²⁵ erg the physical size takes over, so relative sizes are real
    wherever they are resolvable.
  - **The loop sparks are no longer sprites.** They were additive
    `THREE.Points` drawn over everything, which made three wrong claims: a
    spark in front of the limb and one behind it looked identical, a filament
    between viewer and spark did not attenuate it, and the same gold→teal ramp
    was used whatever channel was on screen. They are now **transient hot DEM
    pulses inside the volumetric corona's own front-to-back march**
    (`u_sparks` / `u_sparkTP`, `setSparks`), so occlusion, extinction and
    per-channel response come for free, and each pulse RIDES THE CLOSED-LOOP
    DENSITY — a spark is a loop being heated, so it lights only where the atlas
    says there is closed field (gate opens to 1 with no atlas, so offline still
    draws). `NANOFLARE_VS`/`FS` and the Points/Group are deleted, not disabled.
    Two things are load-bearing in the feed: positions are turned by the page's
    ONE rotation accumulator through `FG.siteRotation` at the site's own
    latitude on the way out (the pool is in the co-rotating frame, the march is
    in the world frame), and the render is TRUNCATED to `N_SPARK_SLOTS` = 12 by
    the uniform budget, so the readout goes on quoting the POPULATION's rate,
    never the drawn count. `SPARK_R_RSUN` = 0.018 is the march's resolution,
    not a nanoflare's size, and says so.

- **2026-09-15 — the flare DEM cools (kernel done; see §9 for the wiring).**
  `js/flare-dem.js` (PURE, `tests/flare-dem.mjs`, 10 checks). The volumetric
  corona's flare term was one Gaussian at a FIXED log T 7.05, so every channel
  saw the flare at the same moment and in the same proportion for its whole
  life — the one thing a flare visibly does not do. The kernel gives it a
  temperature that FALLS: peak T from the GOES class (10–25 MK across C–X,
  Ryan et al. 2012), density from RTV at that temperature, then
  dT/dt = −T/τ_eff with τ_c (conduction, Culhane et al. 1994) and τ_r
  (radiation) combined. **The channel cascade is measured, not scripted:**
  131 → 94 → 211 → 193 → 171, with 131 in the first minutes and the 171
  post-flare arcade ~23 min later.
  - **The loop must DRAIN or the cool channels bunch.** At fixed density
    211/193/171 all peak within 36 s of each other (measured) — which renders
    as the three cool channels lighting simultaneously, i.e. the original bug
    moved down the track. With n ∝ T they separate to 961 / 1080 / 1387 s. The
    full exponent scan (0, ½, 1, 1½) is recorded at the constant; `DRAIN_EXP`
    = 1 is both the middle of the EBTEL-family range and the value that puts
    the 171 peak in the observed window, and is labelled as calibrated against
    that observable. The test re-runs itself with drainage OFF to prove the
    separation gate is not vacuous.
  - **304 Å is reported UNREACHABLE, not extrapolated.** The track stops at
    3×10⁵ K because Λ ∝ T^(−1/2) is a coronal approximation. 304's flare signal
    on this page is the RIBBONS (`flareAdd`), which are chromospheric and are
    not this cooling coronal plasma; observed 304 post-flare loops are coronal
    rain, past where this model is valid.

- **2026-09-15 — Phase 3c: the flare DEM cools, and a disk-measurement bug the
  new fixtures exposed (done).** `js/flare-dem.js` is now wired: the corona
  raymarcher's flare term takes `u_flare_dem` = (log₁₀ T, amplitude) from the
  cooling track instead of the constant log T 7.05 it carried for a flare's
  whole life, and the term RIDES THE CLOSED-LOOP DENSITY (a flare is a
  closed-field arcade lighting up; 0.30 floor because the atlas is coarse and a
  real flare must not vanish for want of a nearby seed; gate opens to 1 with no
  atlas). Amplitude takes THREE separate drives — live GOES level, impulsive
  flash, and the cooling track's own emission-measure envelope — because the
  last one has to OUTLIVE the soft-X-ray decay: by the time the plasma has
  cooled to 171 temperatures the GOES flux is back at background, and driving
  amplitude from it alone is why a post-flare arcade could never appear.
  The flare clock is WALL-CLOCK seconds × the sim-speed control, deliberately
  NOT `u_time` — whose rate changes by ~2900× with the Observed toggle, which
  would make the cooling a different claim every time someone switched mode.
  A live GOES flare loaded 20 min after onset therefore shows the 171 arcade,
  because that is where the plasma actually is. Browser gate drives
  `__sun.setFlareElapsed` rather than waiting 23 real minutes.

  **AND THE FIXTURE CHANGE CAUGHT A REAL BUG IN `measureDisk`.** Once the
  synthetic AIA frames carried a realistic off-limb corona, the EUV disk
  measurement came out **1.4 % too large** at the 256² readback the page took
  — while HMI was fine at −0.24 %. The two instruments have OPPOSITE edge
  shapes: HMI is limb-darkened and steps to black, AIA is limb-brightened and
  steps down into a bright corona that then decays, and straddling-window
  differencing on that sloping background biases outward. The fixed `+1.5` px
  offset compensating for the window centroid made it worse, because it is an
  ANGULAR bias that doubles when the frame is read at 256² instead of 512².
  A 1.4 % radius error draws the observed frame 1.4 % too large on the sphere
  and misregisters its sunspots against `u_arSpots` near the limb — i.e. it
  was quietly undoing part of what Phase 1 went to such trouble to lock.
  Two fixes, both gated: the edge is now the HALF-MAXIMUM CROSSING between the
  local inner and outer levels (which cancels whatever is outside the disk),
  and `readFrame`'s geometry readback is 512² rather than 256² — photometry is
  a set of shell medians and is resolution-insensitive, but an edge is exactly
  what a downsample destroys, and at 256² one pixel of blur IS one percent of
  the radius. Every channel now measures to 0.08–0.21 %; the smoke spec's
  tolerances went 1.2 % → 0.3 %, which is the accuracy the measurement has
  rather than the slop it used to need.

- **2026-09-15 — Phase 3d: cool material from OBSERVATIONS, and the microhair
  bundles promoted (done).** The volumetric corona's B channel now carries
  filaments and prominences as a density: dark on the disk in 171/193/211
  because it absorbs, bright off the limb in 304 because it emits, one field
  doing both with real occlusion and parallax. It replaces an analytic per-AR
  Gaussian that could only ever sit beside an active region, and therefore
  never had a quiescent polar-crown filament in it.

  **The material is OBSERVED because the model has none to give.** The channel
  was designed to be filled from magnetic dips; the dip measurement above says
  there are none, and that is what a potential field IS. So it comes from HEK's
  FI/FA/PG detections — `js/hek-filaments.js` (PURE, 18 checks) +
  `/api/hek/filaments`, registered in `js/pipeline-registry.js` and
  `api/health.js`. That is strictly more honest than dips in a field that has
  none, and it is the same HEK seeding the owner's own item asked for.

  **Findings:**
  - **THE KERNEL BELONGS IN `js/`, NOT `api/_lib/`.** It was written in
    `api/_lib/` alongside the route's other helpers, and `api/` is the
    serverless directory — Vercel and `dev-server.mjs` do not serve it as
    static files. sun.html's `import './api/_lib/…'` 404ed, and because the
    page is ONE module that 404 took the WHOLE PAGE down, not just the layer.
    It cost a full browser-suite run to find and it arrived as a boot timeout
    rather than an error. The repo's own convention is the fix (twenty-odd
    routes already do it): kernel in `js/`, route imports `../../js/…`.
  - **THE MICROHAIR BUNDLES HAD NEVER COMPILED.** The vertex shader declared
    `vec3 flat`; that word is an interpolation qualifier in GLSL ES 3.00 and
    reserved in ES 1.00, so the program never linked and the system has never
    drawn a single thread since it was written. Nobody saw it because the layer
    sat behind `?debug=prominence`, so no test and no visitor ever compiled it
    — the sibling of the scar CLAUDE.md already records about the smoke spec
    swallowing a broken coronaFS. Renamed to `curtain`, and the browser gate
    now asserts zero shader errors once the bundles mount.
    A failed link is also *expensive*: three.js re-logs it every frame, and on
    a software rasteriser that starved the page so completely that a 90-second
    `waitForFunction` poll never resolved. The mount itself is cheap —
    MEASURED on the same rasteriser: trace 5–9 ms, field textures <2 ms,
    classify 1.5 ms, first instance build 0.5 ms, and a one-off 3.8 s WASM
    load. So the promotion is affordable; the hang was the bug, not the cost.
  - **Promoted with a governor, not a tier.** Default ON (`?prom=0` opts out),
    starting at the FLOOR of a low/mid/high ladder and climbing only on 90
    sustained frames under 22 ms, demoting immediately above 40 ms —
    earth.html's cloud-governor shape, for its reason: a weak renderer that
    enters the expensive rung on frame 1 starves the re-evaluation that would
    demote it. `?promq=` pins and stands the governor down.
  - **Two cadences, which is what makes it affordable as a default.**
    `classify` + `update` walk every atlas line and rewrite the instance
    attributes, and they ran EVERY FRAME while this was a debug flag — where
    one developer paid for it. Now 4 Hz; classification changes on the
    timescale of flares and AR updates, not frames. `tick` stays per-frame.
    The mount is also ARMED after `PROM_ARM_FRAMES`, so the 3.8 s WASM load is
    never on the boot path.
  - **The bundles now show filaments the tracer cannot produce.**
    `appendObservedFilaments` puts each HEK spine into the atlas as a
    PIL-seeded closed line with `arIndex = -1` — the marker that says
    OBSERVED, so nothing pretends a detection came out of the field model. The
    Rust tracer only walks Br = 0 near an ACTIVE REGION, so without this the
    page could only ever draw active-region filaments.
  - **De-duplication is load-bearing, not tidying.** Several detectors see
    the same filament and each re-publishes it every few hours; splatting all
    of them stacks 5–10 copies into one voxel column and makes a much-watched
    structure denser than an unwatched one — the render would encode ATTENTION
    rather than material. Merged within 8° on the sphere, with the detection
    count carried so the page can say how many saw it.
  - A length in the wrong unit lands on a clamp bound and the route reports
    `freshness: 'stale'` + a note rather than drawing a Sun covered in
    identical filaments; a row with no position is dropped, never placed at
    disk centre. Both gated.

- **2026-09-17 — Phase 3e: GOES/SUVI as a second source for the off-limb ring
  (done).** The observed off-limb annulus now draws from either SDO/AIA or
  GOES/SUVI. `js/suvi-geometry.js` (PURE, 16 checks) + the `suvi###` channel
  family on `/api/solar/aia` + a source toggle on the layer. The disk is
  untouched and stays SDO — this is a LAYER, not a swap.

  **THE LAYER HAS BEEN DRAWING A DETECTOR EDGE AND NOBODY NOTICED.**
  `js/sun-offlimb.js` draws 1.0–1.6 R☉ and its shader correctly refuses to
  clamp-extend a border texel, so outside the frame it draws nothing. An AIA
  half-frame is 0.6″/px × 4096 px = 1229″ = **1.280 R☉ on axis** (1.811 into
  the corners). The ring asks for 1.6. MEASURED in closed form and
  cross-checked against grid quadrature to 3e-3: **an AIA frame supplies 65.9 %
  of the annulus the layer draws.** The missing third is four lobes on the
  axes, so the viewer has been reading the shape of the DETECTOR as the shape
  of the corona. SUVI is 2.5″/px × 1280 px = **1.667 R☉ on axis**, and supplies
  **100 %** — every azimuth, to the outer edge. That is the whole argument, and
  it is why SUVI is specifically the right feed for off-limb prominences and
  flare loops: those are the structures that live where AIA's frame stops.

  **Findings:**
  - **THE 23 % DISK-FRACTION GAP WOULD HAVE FAILED SILENTLY.** SUVI is 0.2999
    of its frame against AIA's 0.390, and `resolveDiskGeometry` accepts a
    measurement only within 12 % of the instrument's expected fraction. Fed a
    SUVI frame with the AIA fallback, the honest measurement is **rejected**
    and the layer falls back to 0.390 — drawing the ring **30 % too small**,
    with the observed limb a third of a solar radius inside the model's. The
    frame loads, the shader runs, nothing errors, and every prominence is in
    the wrong place. So `suvi` is a real instrument in `DISK_FRACTION`
    (imported from the kernel, ONE copy of the number) and every `suvi###`
    channel resolves to it. Both the node test and the browser gate assert the
    uniform carries ~0.300 and provably NOT 0.390.
  - **The vantage is the same, and that is what makes this drop in.** GOES is
    geostationary: 42 164 km at 1 AU subtends 0.0161°, and the East–West chord
    0.0197°. The layer's `OFF_AXIS_FULL_DEG` = 12° band is **~750×** that, so
    the plane of sky SUVI encodes and the plane AIA encodes are the same plane,
    and B0 is the same B0. `observerBasis` and `solarEphemeris` are reused
    UNCHANGED. (An earlier draft of this entry said "three orders of
    magnitude"; it is 745×, and the test computes the factor rather than
    trusting the prose.)
  - **SUVI IS NOT SIX AIA CHANNELS.** Its bands are 94/131/171/**195**/**284**/
    304. 195 (Fe XII) is not AIA's 193 (Fe XII + Fe XXIV) and 284 (Fe XV) is
    not AIA's 211 (Fe XIV) — a different ion at a similar temperature.
    `AIA_CORRESPONDENCE` carries the mapping with a `same` flag and the label
    prints SUVI's own wavelength; the test fails if 195 ever renders as "193".
    The off-limb pair (304, 131) are both shared lines, which is exactly what
    makes an A/B between the two sources meaningful.
  - **The URL is UNVERIFIED and resolves from a candidate list.**
    services.swpc.noaa.gov is egress-blocked at build time (verified, same as
    nasa.gov), so guessing one path would fail silently and look like a dead
    upstream — the `noaa-regions` / `mars-tiles` scar, twice paid for. Two
    policies on purpose: the IMAGE path tries candidates in order and stops at
    the first that answers (`X-SUVI-Source` names it); `meta=1` probes EVERY
    candidate in parallel and reports each one's status, so **ONE production
    request settles it**:

        curl -s 'https://parkersphysics.com/api/solar/aia?channel=suvi304&meta=1' \
          | jq '.source_id, .upstream, .candidates'

    Record the winner in `js/suvi-geometry.js` `SOURCE_CANDIDATES`, move it to
    the head, delete the ones that never hit. A 200 that is not an image is
    SWPC's HTML error page and is rejected as `not_an_image` rather than
    decoded as a frame. Primaries are always tried before secondaries (which
    physical GOES is primary is an operational decision we do not assume — the
    chip says `primary`/`secondary`, never a satellite number). The route's own
    contract is gated by `tests/suvi-route.mjs` against a stubbed upstream.
    Registered as
    `solar-suvi` in `js/pipeline-registry.js` + `api/health.js`; a total miss
    answers **200 + freshness:expired**, never a 5xx, so status.html reads the
    FEED as down rather than the route as broken.
  - **SUVI's cadence is 4 min, not AIA's 12.** The proxy caches SUVI at 240 s
    rather than inheriting `CACHE_S` — a layer whose reason for being is
    watching a prominence erupt must not be served three frames stale.
  - **The fixture proves the coverage claim on pixels, not arithmetic.**
    `scripts/lib/sdo-synth.mjs` now renders `suvi304` / `suvi131` at SUVI's own
    plate scale, and plants `PROM-FAR-W` on the +x axis at **1.50 R☉** —
    deliberately between the two instruments' on-axis reach, so it is
    physically absent from the AIA frame and present in the SUVI one. Nothing
    arranges that; it falls out of the plate scale, because the render loop
    only walks the frame. **`synthetic_304.png` is byte-identical to the frame
    that shipped before the probe existed**, so "absent from the AIA frame" is a
    property of the file rather than a claim about it — and getting there took
    two wrong sizings worth recording: σ=0.070 put 10.7 counts at the AIA edge
    (faintly VISIBLE, quietly contradicting the point), and σ=0.045 put 0.16
    counts there and STILL moved 30 samples by one count, because a
    sub-quantisation contribution added to the existing halo can cross a
    rounding boundary. Estimating the contribution alone is not enough; diff the
    fixture. `tests/sun-suvi-layer.spec.js` samples that point under both
    sources and requires SUVI brighter, with a CONTROL probe at 1.15 R☉ that
    both frames cover — without the control the test would pass on any overall
    brightness difference between sources.
  - **The UI states its own field of view.** The layer row's meta text is
    generated from `sourceCoverage()`, which computes the figure from the
    instrument's disk fraction, so the page cannot claim a field of view the
    geometry does not have. It reads "SDO/AIA 0.6″/px · 66% of the ring" by
    default — the disclosure is the point.
  - **Coverage is computed from DERIVED fractions, not the rounded table.**
    `DISK_FRACTION` keeps the 0.465 / 0.390 it has always shipped (they feed a
    ±12 % band where the fourth decimal cannot matter), while the disclosure
    uses `diskFractionFromPlateScale` — quoting 66.2 % for a number that is
    65.9 % would be the layer misreporting its own field of view.
  - **NOT done, deliberately:** the drawn ring stays 1.0–1.6 R☉ for both
    sources, so the two are directly comparable and an A/B measures field of
    view rather than two different annuli. SUVI could honestly carry the ring
    out to 1.667 R☉ (`u_radial` is already a uniform, so it is a per-source
    value and not a mesh rebuild); recorded here as the obvious next step
    rather than smuggled into this one.

- **2026-09-15 — two measurements that CONTRADICT this file's own Phase 3 log.**
  Recorded here because acting on the stale numbers would have re-broken
  working code (CLAUDE.md §5).
  1. **"The tracer's AR arcades peak only 0.005–0.008 R☉ up" is wrong** — that
     is the p10 of the distribution, not the distribution. Measured on the same
     three planted ARs with the page's own parameters (`cargo test` in
     `rust-sunfield`, new `tests/loop_geometry.rs`): **p10 0.0058, p50 0.0336,
     p90 0.1437, max 0.4498 R☉**, i.e. the median arcade is already inside the
     observed 0.03–0.2 R☉ band and the tall end reaches it comfortably. The
     scan against AR area (`examples/apex_scan.rs`) shows the same at every
     area the live feed produces. **The seed ring and burial depth do NOT need
     raising**, and the four new Rust tests pin that from now on.
  2. **The PFSS-lite field has NO MAGNETIC DIPS AT ALL.** Zero, in every
     configuration tried (`examples/dip_scan.rs`): one α region, one δ-spot
     region, three planted ARs, and two adjacent opposite-polarity regions —
     the classic filament-channel geometry. This is not a bug, it is what a
     POTENTIAL field is: dips that hold prominence material require sheared or
     twisted field, i.e. field-aligned currents, which is exactly why every
     prominence model (Kuperus–Raadu flux rope, Antiochos sheared arcade) is
     non-potential. **A prominence channel filled "where atlas lines have
     magnetic dips" therefore cannot be built on this atlas as it stands** —
     it would be empty. Open, with the options written up in §9.

---

## 1. Scope & locked decisions

Two forks were decided up front, in conversation with the owner:

- **No game engine.** Unreal has no web target (HTML5 export died in
  UE 4.24; UE5 never had one); Pixel Streaming means a GPU server per
  concurrent viewer, which Vercel serverless cannot host and which turns a
  simulation into a video service. Unity/Godot web exports ship a 30–80 MB
  runtime that owns the canvas and cannot reuse the Rust PFSS tracer, the GPU
  Navier–Stokes solver, the DEM corona raymarcher, or any live feed. CLAUDE.md
  §1 forbids frameworks and bundlers for the same reason. **The stack stays
  three.js + custom GLSL/WGSL.** Every "world class" Sun in a game engine or a
  film is a custom material + volumetrics + post chain; the gap here is
  technique and pipeline, not engine. Offline UE/Blender renders are fine for
  *marketing footage* (an MP4), never for the live page.
- **Observed by default.** When `sun.html` loads, the Earth-facing disk is the
  REAL Sun — SDO/HMI continuum in white light, SDO/AIA in the EUV modes —
  fetched through the house edge proxy. The procedural photosphere becomes
  (a) the far side, (b) the fallback when the feed is down, and (c) the
  opt-in "Model" mode that the convection plan's toggles (cutaway, Doppler,
  fluid) continue to run in. The product story is *observed where observed,
  modelled where not*, and the page says which is which at all times.

### 1.1 Explicitly OUT of scope

- Re-tuning the convection drift speeds or the fluid solver parameters
  (`SUN_CONVECTION_UPGRADE_PLAN.md` — tuned once, do not revert).
- A second heavy raymarch (the convective-zone cutaway stays shading-only,
  per that plan's §8).
- Historical Helioviewer JP2 retrieval for the scrubber. `api/solar/aia.js`
  already documents it as a deferred follow-up and labels scrubbed views
  honestly (`X-AIA-Mode: live-fallback`). It stays deferred; see §9.
- Touching `js/sun-shader.js` / `js/sun-skin.js` beyond what §5 needs — those
  are shared with `heliosphere3d.js` and the space-weather globe.

---

## 2. What exists today (verified 2026-09-06)

`sun.html` (11,690 lines) renders with the vendored three.js **r160**
(`js/vendor/three-0.160.0/`, shared by ~40 pages) and an EffectComposer chain:

```
RenderPass → UnrealBloomPass (ambient, 0.18/0.28/0.85)
           → UnrealBloomPass (flare,   0.00/0.20/1.10)
           → ShaderPass radialDiffuse (K-corona limb gather; off by default)
           → ShaderPass spaceOcclusion
```
at `sun.html:2353–2550`, ACES tonemap at fixed exposure 1.05
(`sun.html:2339`), sRGB output, DPR capped at 2.

Seven structural shells (core → corona), the photosphere `sunFS` inline at
~`sun.html:2632`, the GPU Stable-Fluids solver in `js/solar-fluid.js`, the
PFSS-lite tracer in `rust-sunfield/` → `js/sunfield-wasm/`, and the DEM
raymarched corona in `js/corona-volumetric.js` (mounted lazily by
`js/corona-volumetric-mount.js`).

**The EUV "wavelength views" are synthetic.** `u_viewMode` 1–6 at
`sun.html:3422` recolours the procedural disc from structural fields (network,
plage, fluid temperature, a noise-generated "coronal hole" field) into
AIA-styled ramps. The live SDO images exist on the page only as `<img>`
thumbnails in the `#sdo-drawer` strip (`sun.html:785`) and the
`js/sdo-compare-panel.js` A/B inset. **Nothing on `sun.html` wraps the
observed disk onto the sphere.**

**Other pages already do.** `js/stage/stage.js:307–470` samples the SDO/HMI
continuum on the Earth-facing hemisphere by orthographic disk→sphere
projection, keeps procedural granulation on the far side, is fail-quiet
offline, and runs a 171 shell + a magnetogram layer off the same proxy.
`js/space-weather-globe.js:470` and `js/heliosphere3d.js:1035` do the same
with `createSolarDisk` from `js/solar-disk.js`. All three go through
`api/solar/aia.js` (edge, 12-min `s-maxage`, channels `white | mag | 94 |
131 | 171 | 193 | 211 | 304`, resolutions 512–4096, CORS headers). **That
pattern is the thing to port — not a new one.**

Far side: `api/solar/farside.js` + `api/cron/farside-ingest.js` already
proxy/ingest GONG helioseismic far-side maps (`api/_lib/farside-sources.js`).
`js/sun-rotation.js` provides `carringtonL0` and Carrington→scene longitude,
which is what orients any synoptic texture.

Testing: `tests/sun-smoke.spec.js` (6 tests: boot, 7-layer toggle, loop,
cutaway, Doppler, wavelength cycle) on **software WebGL**. There is no
screenshot baseline anywhere in `tests/`, and the convection plan's own log
says every visual phase was "verified" without a GPU. That is the first thing
to fix (§3 Phase 0).

### 2.1 What is actually holding the render back

1. **LDR-flavoured post chain.** Two `UnrealBloomPass`es over a fixed-exposure
   ACES tonemap. UnrealBloom's ring artefacts are the "circles" the owner
   complained about in June; the de-bloom rework shrank them rather than
   replacing the pass. No exposure adaptation, so disk and corona cannot both
   be right in one frame and flying into the corona changes nothing.
2. **The fluid domain is 2-D equirectangular.** Pole pinch, no granule relief,
   no limb faculae, so the limb — where real imagery is most striking — reads
   flat.
3. **Single-sample corona raymarch.** No blue-noise jitter, no temporal
   accumulation, so it is either noisy or smeared; the PFSS loops are drawn as
   separate lines rather than lighting the volume.
4. **The disk is invented** while a free, near-real-time observation of the
   same disk is already proxied and cached for three other pages.
5. **No GPU verification loop.**

---

## 3. Phases

Each phase is one PR, independently verifiable, in the order given. Phase 0
first, always. Phases 1–2 are the product decision; 3–5 are the engine-grade
polish; 6 is the architectural lever that unlocks 3-D convection.

### Phase 0 — GPU screenshot baseline (small)

**Goal:** stop judging visual work on software GL.

- `tests/sun-visual.spec.js`: Playwright, tagged `@gpu`, skipped unless
  `SUN_GPU=1`. Loads `sun.html?visual=baseline` (fixed seed, fixed time via
  `window.__sun.setClock(iso)`, feeds mocked with committed fixture images so
  the frame is deterministic), waits for `__sun.ready`, captures the canvas at
  1280×720 and 2560×1440 for: white-light, 171, 304, Model mode, cutaway,
  Doppler. Stores under `tests/__visual__/sun/`.
- Fixture images: one 1024² frame per channel, committed under
  `tests/fixtures/sdo/` (public NASA imagery; ~8 files ≈ 2 MB). The page's
  loader takes a base URL override (`__sun.aiaBase`) so the spec points it at
  the fixtures instead of `/api/solar/aia`.
- Run locally on the owner's machine (real GPU) and attach the baseline PNGs
  to the PR. CI keeps running `sun-smoke.spec.js` on software GL; the visual
  spec is opt-in. Perceptual diff threshold 0.5% via Playwright's
  `toHaveScreenshot({ maxDiffPixelRatio })`.
- Add `window.__sun.perf` (rolling frame-time p50/p95 + GPU timer query when
  `EXT_disjoint_timer_query_webgl2` exists) so every later phase reports a
  number, not "seems fine".

**Exit:** baseline PNGs committed, spec green on real hardware, and a line in
this file's progress log with the GPU + frame times it was captured on.

### Phase 1 — Observed disk by default (medium) ★ the product decision

**Goal:** on load, the near hemisphere is the live SDO Sun.

New module **`js/sun-observed.js`** (page-scoped, three-free where possible so
`tests/sun-observed.mjs` can unit-test the projection math):

- `loadChannel(channel, { res, bucket })` → `/api/solar/aia?channel=…&res=2048&b=<5-min bucket>`
  — same URL contract as `space-weather-globe.js:478`. 2048 for the
  `sun.html` hero (it fills the viewport; 1024 visibly softens at 1440p);
  drop to 1024 on `devicePixelRatio < 1.5` or when `__sun.perf` p95 > 24 ms.
- **Projection.** Orthographic disk→sphere on the Earth-facing hemisphere,
  exactly the `stage.js:307` approach, but with the three SDO header angles
  applied instead of assumed: the disk centre/radius from the FITS-style
  metadata the proxy will start forwarding (`X-SDO-CRPIX1/2`, `X-SDO-R_SUN`,
  `X-SDO-CROTA2` — see the `api/solar/aia.js` change below), the P-angle
  roll, and B0 tilt so the projected disk's heliographic equator lines up with
  the AR markers `js/sun-rotation.js` already places. `projectDiskUV(dirObj,
  { cx, cy, rSun, pAngle, b0 })` is the pure function; the smoke test asserts
  an AR at (lat, lon) from the SWPC list lands on its sunspot in the HMI
  fixture within 1.5° (the fixture is a real frame with a known AR list).
- **Limb blend.** The observed disk is authoritative for `mu > 0.08`; a
  0.08→0.0 `smoothstep` cross-fades into the procedural limb + spicule fringe
  so the terminator between observed and modelled is never a hard edge and
  the chromosphere shell still has something to sit on.
- **Far side.** Procedural granulation seeded from the GONG far-side map when
  `/api/solar/farside?source=gong` answers: the map's strong-field cells
  modulate `u_regions` for the back hemisphere (dim plage, no invented
  sunspots — a helioseismic map has no continuum detail and the page must not
  pretend it does). No map → plain procedural far side. Either way the far
  hemisphere carries a subtle 3° graticule so a viewer can tell at a glance
  which half is observation.
- **EUV modes become observed.** `u_viewMode` 1–5 switch the near-side texture
  to the matching AIA channel (2048, same bucket) instead of the synthetic
  recolour; the synthetic ramp stays as the far-side fill and the offline
  fallback. Magnetogram (mode 6) uses `channel=mag`. The `photDim` table in
  `js/corona-volumetric.js` keeps dimming the disk under the volumetric
  corona exactly as now; the observed 171/193/211 disk is already the "disk
  is dark, loops are bright" look those dims were emulating.
- **Refresh.** 5-min bucket re-fetch (matches the globe), cross-fade over
  ~1.5 s between frames so the 12-min AIA cadence reads as a slow live feed
  rather than a hard cut. Tab hidden → no fetch (`document.visibilityState`).
- **Failure = honesty, never a blank.** Any fetch failure keeps the last good
  frame if there is one (with the status chip going amber + its age), else
  falls back to the procedural disk with the chip reading *Model (feed
  down)*. This is the `tests/sun-smoke.spec.js` path in CI, so the procedural
  branch stays exercised every run — it is NOT dead code.
- **Status chip + provenance line** (top-left, beside the existing view
  controls): `OBSERVED · SDO/HMI 4500 Å · 2026-09-06 14:12 UTC · 7 min old`
  or `MODEL · procedural photosphere` or `OBSERVED (stale 41 min)`. Clicking
  it toggles Observed ↔ Model. Model mode is what the convection plan's
  cutaway / Doppler / fluid toggles switch into automatically (they already
  snapshot-and-restore visibility; they add "observed" to that snapshot).
- **`api/solar/aia.js`**: forward the frame's UTC timestamp and disk geometry
  as response headers (parse the NASA "latest" JPEG's sidecar when available,
  else `Date` of the upstream response + the fixed SDO crop geometry —
  `latest_*` JPEGs are pre-centred, radius 0.455 of the frame, which is the
  `diskR: 0.455` constant `heliosphere3d.js:991` already uses). Add
  `X-SDO-Observed-At`. Register `solar-aia` in `js/pipeline-registry.js`
  (category `space-weather`, cadence 720 s, prewarm `hot`, warn 30 min, crit
  90 min) — it is currently unmonitored, exactly the `/api/mars/weather`
  failure CLAUDE.md §8 warns about. Emit `freshness: 'stale'` semantics via
  the `X-AIA-Mode` header the status probe can read.
- Delete nothing: the `#sdo-drawer` strip stays (it is the multi-channel
  picker), `js/sdo-compare-panel.js` stays (it becomes the A/B against the
  wrapped disk — now genuinely useful).

**Tests:** `tests/sun-observed.mjs` (projection pure function + AR alignment
on the fixture), `tests/sun-smoke.spec.js` gains "boots in Model mode when
the AIA route 502s" and "boots Observed with fixtures, chip says OBSERVED",
and the wavelength-cycle test asserts the texture swaps per channel.
Phase 0 visual baseline re-captured.

**Exit:** default load shows the real Sun; chip is truthful in all three
states; CI green on software GL with the feed down.

### Phase 2 — HDR post chain (medium)

**Goal:** kill the bloom rings, make disk and corona coexist, give the page a
camera.

New module **`js/sun-post.js`** replacing the two `UnrealBloomPass`es:

- **Mip-chain bloom** (Jimenez 2014 "Next Generation Post Processing in Call
  of Duty" — 13-tap downsample with Karis average on the first mip, 9-tap
  tent upsample, 6 mips at 1280p). Physically it is a wide, smooth PSF, no
  threshold, no ring. Strength ≤ 0.06 as an *additive fraction* — the
  observed disk is already correctly exposed; bloom exists for the limb, the
  flares, and the corona, not to make the disk glow.
- **Exposure adaptation.** Log-luminance average of a 64² mip of the scene,
  smoothed with τ = 1.2 s (brighten) / 0.5 s (darken), key value 0.18,
  clamped to EV range [−2, +4] around the Phase 1 calibration so the disk
  never crushes to white. Flying inside 1.4 R☉ shifts the key so the corona
  comes up as the disk leaves the frame. Exposed as `__sun.camera.ev`.
- **Lens.** Tasteful and OFF by default in Observed mode, ON in the
  cinematic camera paths (Phase 5): 6-ghost lens flare from a thresholded
  copy of the bloom source, subtle chromatic aberration (≤ 1.5 px at the
  frame edge), film grain at 0.015 amplitude, blue-noise dithered before the
  8-bit output. All four are one `ShaderPass`.
- **Colour.** Keep ACES; render targets `HalfFloatType` (r160
  `EffectComposer` already defaults to it — verify with
  `composer.renderTarget1.texture.type`, do not assume). Flare flash goes
  into the HDR buffer as a real >1.0 value, so the flash shows up as bloom +
  exposure drop rather than a white-out uniform.
- Retire `radialDiffusePass` (off by default since June; the Phase 3 K-corona
  replaces what it was for). Keep `spaceOcclusion`.

**Tests:** shader-compile assertion in the smoke spec; `__sun.perf` p95 must
not regress more than 2 ms at 1280p vs the Phase 1 baseline on the same GPU;
visual baseline re-captured. `tests/sun-post.mjs` unit-tests the exposure
controller (pure: given a luminance series, the EV trajectory).

**Exit:** no visible ring at any bloom strength; a flare reads as a real HDR
event; owner sign-off on the baseline PNGs.

### Phase 3 — Corona that shows structure (medium)

**Goal:** loops and streamers you can see, not a haze.

In `js/corona-volumetric.js` (kernel is the header; the physics stays):

- **Blue-noise jitter + temporal accumulation.** Per-pixel ray-start offset
  from a 64² blue-noise tile, accumulate 8 frames with camera-motion reject
  (reprojection via previous view-projection; reset on scrub / channel /
  camera change). Effective 8× samples at 1× cost. Static-camera frames
  converge in ~130 ms.
- **Field-aligned emission.** Rasterise the PFSS lines (already in
  `Float32Array` from `rust-sunfield`) into a 128³ "loop density" 3-D
  texture (R8, ~2 MB, rebuilt on AR-list update on a worker) and add it as a
  DEM term with the AR's loop temperature. The raymarcher then lights the
  loops as volume, so 171/193/211 show bright arcades where the tracer says
  there are closed loops and dark where field is open — the coronal-hole
  subtraction becomes derived from field topology (`Topology::Open`) instead
  of a Gaussian cell.
- **K-corona** from Thomson scattering of an electron-density model
  (Baumbach-Allen `n_e(r) = 10^8 (0.036 r^-1.5 + 1.55 r^-6 + 2.99 r^-16)`
  cm⁻³, with the streamer belt modulated by the source-surface neutral line
  from the tracer) plus a smooth **F-corona** term — visible in white light
  and the cinematic mode; this is what `radialDiffusePass` was approximating.
- LASCO C2/C3 (`js/soho-feed.js`) as an optional *observed* coronagraph plane
  beyond 2.2 R☉ in white light, occulter drawn honestly. Same chip/provenance
  rules as Phase 1.

**Tests:** new `tests/corona-volumetric.mjs` (there is none today) with a
loop-density rasteriser check (a known closed loop lights the expected voxels); smoke spec asserts
the accumulation resets on channel change (no ghosting of the previous
channel); visual baseline re-captured for 171/193.

### Phase 4 — Photosphere detail behind the observation (medium)

**Goal:** the far side and the Model mode stop looking flat, and the observed
disk gains what a 2048 JPEG cannot carry.

- **Cube-sphere fluid domain.** `js/solar-fluid.js` moves from one
  equirect target to six 256² faces with edge-copy boundaries (the standard
  cube-map fluid trick). Kills the pole pinch. Same solver, same tunables,
  same drift coefficients — *only the domain changes*. Sampled via
  `textureCube`. The procedural granulation is what it drives, so this is the
  far-side / Model-mode surface.
- **Granule relief and limb faculae.** Height field from the fluid
  temperature → micro-normal → the existing 5-term limb darkening gets a
  per-pixel μ perturbation. Near the limb (`mu < 0.3`) the intergranular
  lanes brighten (faculae) — the real "hot wall" effect. In Observed mode the
  same micro-normal is applied to the observed disk as a *shading* term only
  (never geometry, never colour), scaled by the local contrast of the HMI
  frame so it adds sub-pixel detail where the image has granulation and
  nothing where it is saturated.
- **Multi-scale detail.** At `camera.distance < 2 R☉` a second tile of
  procedural granulation at 8× frequency fades in under the observed disk so
  a 4K viewport still resolves individual granules. Disclosed in the chip
  (`OBSERVED + synthesised sub-pixel detail`) — the Mars regolith rule:
  everything below the raster's sample spacing is synthesised and says so.

**Tests:** `node tests/solar-fluid.mjs` (new; asserts divergence after
projection < 1e-3 on each face and continuity across a face edge);
convection plan's drift tunables asserted unchanged; visual baseline.

### Phase 5 — Cinematography (small)

- Scripted camera paths (`js/sun-camera.js`, pure keyframe math, unit-tested
  timing): *Approach* (6 → 1.3 R☉, lens on, exposure ramps), *Limb ride*
  (grazing pass over an AR with the 304 channel), *Flare* (triggered on a
  live M/X event or on demand — pull to the source AR, HDR flash, bloom
  bloom-out, exposure recovery). Each ends with the chip visible.
- Depth of field: one bokeh pass (hexagonal, CoC from a fixed focus at the
  photosphere) only during the paths, off in the free camera.
- `?preview=1` attract mode plays *Approach* → *Limb ride* on a loop (the
  Stage's attract pattern in `js/stage/stage.js`; do not fork its
  scheduler — import and drive it).

### Phase 6 — WebGPU renderer, page-scoped (large; only after 1–5 ship)

**Goal:** compute shaders for a 3-D convective shell and GPU field-line
tracing. This is the one phase that touches the vendored three.js.

- **Second vendored three, page-scoped.** WebGPU + TSL need ≥ r165; the r160
  `OrbitControls` behaviour is load-bearing on Mars, Moon, and the Stage
  (CLAUDE.md, the `camera.up` capture). So: `js/vendor/three-0.17x/` used
  ONLY by `sun.html`'s import map; r160 stays for the other ~40 pages.
  Nothing else changes its import. There is no vendor-audit script today;
  add `scripts/lint-three-vendor.mjs` in this phase so a page importing the
  wrong copy fails CI instead of silently mixing two three.js instances.
- `renderer = navigator.gpu ? new WebGPURenderer() : new WebGLRenderer()`
  with the Phase 2 post chain written once in TSL so it compiles to both
  WGSL and GLSL. Feature-gate, never feature-require: Safari 26 / Firefox
  141+ / Chrome all ship WebGPU as of 2026, but software-GL CI does not, so
  the WebGL2 path remains the tested default in `sun-smoke.spec.js` and the
  WebGPU path is tested by the `@gpu` visual spec.
- **3-D convection.** A 96×96×24 spherical-shell Boussinesq solver in
  compute (the convection plan's Phase 2 shading becomes real depth), driving
  the cutaway and the surface simultaneously. The 2-D cube-sphere solver from
  Phase 4 stays as the WebGL fallback — two paths, both live, like
  `msis | surrogate`.
- **PFSS on the GPU.** RK4 tracing in compute from the same seeds
  `rust-sunfield` builds; the Rust tracer stays the oracle and
  `tests/sunfield-kernel-smoke.mjs` (new) pins GPU ↔ Rust equality on a
  fixed AR list. Loop-density texture (Phase 3) then rebuilds per frame,
  which is what makes a flare's arcade evolve live.

**Exit:** WebGPU path within 10% of the WebGL frame time at 1440p on the
owner's GPU, and *identical* screenshots on the Phase 0 baseline scenes
(diff < 0.5%) — a renderer change must not be a look change.

---

## 4. File map

| Phase | New | Modified |
|---|---|---|
| 0 | `tests/sun-visual.spec.js`, `tests/fixtures/sdo/*`, `scripts/make-sdo-synthetic-fixtures.mjs`, `scripts/fetch-sdo-fixtures.mjs`, `scripts/lib/sdo-synth.mjs`, `tests/__visual__/` (baselines: pending GPU) | `sun.html` (`__sun.freeze`, `__sun.perf`), `playwright.config.js` (`snapshotPathTemplate`) |
| 1 | `js/sun-observed.js`, `tests/sun-observed.mjs` | `sun.html` (photosphere uniforms + sunFS + chip UI + mode handlers), `api/solar/aia.js` (headers + `meta=1`), `js/pipeline-registry.js` (`solar-aia`), `api/health.js` (`sdo-latest`), `tests/sun-smoke.spec.js` |
| 2 | `js/sun-post.js`, `tests/sun-post.mjs` | `sun.html` (composer wiring: UnrealBloom ×2 + radialDiffuse → `SunPostPass`; Doppler save/restore; resize; animate drive; `flareAdd` overlay in sunFS), `tests/sun-smoke.spec.js` |
| 3 | `js/corona-loop-density.js`, `js/corona-accumulate.js`, `tests/corona-volumetric.mjs` | `js/corona-volumetric.js` (loop sampler, two-scale jittered march, `u_marchLegacy`), `js/corona-volumetric-mount.js` (layer 1, `setLoopDensity`, `setJitter`), `js/field-atlas.js` (WASM path fix), `sun.html` (lazy default mount, accumulation pass, loop rebuild, K/F corona in coronaFS), `tests/sun-smoke.spec.js` |
| 4 | `tests/solar-fluid.mjs` | `js/solar-fluid.js`, `sun.html` `sunFS` |
| 5 | `js/sun-camera.js`, `tests/sun-camera.mjs` | `sun.html`, `js/preview-mode.js` |
| 6 | `js/vendor/three-0.17x/`, `js/sun-render.js`, `tests/sunfield-kernel-smoke.mjs`, `scripts/lint-three-vendor.mjs` | `sun.html` import map |

Extraction rule: shader code that Phase 2/6 needs to compile for two
back-ends moves out of `sun.html` into the module that owns it *in the phase
that needs it*, never as a standalone "cleanup" PR (§5 of CLAUDE.md — a
10k-line reshuffle with no visual change is exactly the diff nobody can
review).

---

## 5. Honesty rules (apply to every phase)

These mirror the rules the Mars and Moon pages already live by
(CLAUDE.md §3, Mars tiles: "the map is ARCHIVAL, the view is LIVE").

1. **The chip is never wrong.** Observed / Model / Stale with a UTC timestamp
   and an age. If a test can make the chip say OBSERVED while the texture is
   procedural, that test fails.
2. **Observation beats model on the near side, always.** No procedural term
   may change the *colour* or *shape* of an observed pixel; shading-only
   detail (Phase 4) is disclosed.
3. **The far side never invents sunspots.** Helioseismic maps give strong-field
   regions, not continuum. Plage-like dimming only.
4. **A dead feed is visible, not quiet.** Same as `flux-rope-live.html`'s
   DEMO badge — feeds down must look down.
5. **Scale is honest.** Corona extent, R☉ units, the 2.5 R☉ volume — no
   compression is introduced; the Stage's `scale.js` stays the only place
   that does that, on its own page.
6. **Nothing is "verified" without a GPU screenshot** in the PR after Phase 0
   exists.

---

## 6. Data sources

| Product | Route | Cadence | Used by |
|---|---|---|---|
| SDO/HMI continuum (`white`), LOS magnetogram (`mag`) | `/api/solar/aia` (exists) | 12 min | Phase 1 near-side disk |
| SDO/AIA 94/131/171/193/211/304 | `/api/solar/aia` (exists) | 12 min | Phase 1 EUV modes, Phase 3 |
| GONG far-side helioseismic map | `/api/solar/farside?source=gong` (exists) | ~24 h | Phase 1 far side |
| GOES/SUVI 94/131/171/195/284/304 | `/api/solar/aia?channel=suvi304` (candidate-resolved) | 4 min | Phase 3e off-limb ring (wide field) |
| SOHO/LASCO C2, C3 | `js/soho-feed.js` URLs (direct, `<img>`-safe); needs an edge proxy if used as a texture | 20–30 min | Phase 3 coronagraph plane |
| NOAA SWPC AR list, GOES X-ray | existing feeds | 1 min–daily | unchanged |

Helioviewer JP2 (historical frames) — deferred, §9.

---

## 7. Performance budget

Target: 60 fps at 1440p on a 2022 laptop GPU (Apple M2 / RTX 3050 class) in
Observed white-light with the corona on; 30 fps floor on Intel Iris Xe.
Measured via `__sun.perf`, reported in every phase's PR.

| Item | Budget (ms @1440p) |
|---|---|
| Photosphere + observed disk | 1.5 |
| Corona raymarch (Phase 3, 1 sample + accumulation) | 4.0 |
| Post chain (Phase 2) | 1.8 |
| Fluid step (Phase 4, 6×256²) | 1.2 |
| Everything else (shells, particles, UI) | 3.0 |
| **Total** | **≤ 11.5** |

The existing quality ladder (`u_quality`, sphere LOD 128/72/40) stays and
gains the resolution switch from Phase 1; a ladder step trades fidelity,
never the chip or the instruments.

---

## 8. Sequencing and PR discipline

1. Phase 0 — one PR, baseline PNGs attached. Nothing visual merges before it.
2. Phase 1 — the headline. Ship it, capture the baseline on real hardware,
   get the owner's eyes on the chip in all three states before Phase 2.
3. Phase 2 — post chain. Owner sign-off on bloom/exposure from screenshots.
4. Phases 3 and 4 are independent; either order.
5. Phase 5 — polish, after 2 and 3.
6. Phase 6 — only after 1–5 are merged and stable for a couple of weeks; it
   is the one phase with cross-page blast radius (the second vendored three).

Every PR: `node tests/sun-observed.mjs` (once it exists) + `npx playwright
test tests/sun-smoke.spec.js` in CI, `SUN_GPU=1 npx playwright test
tests/sun-visual.spec.js` on hardware, and a line in this file's progress
log. Re-read CLAUDE.md §5 before opening it.

---

## 9. Deferred / open

- **GONG far-side plage seeding** (`/api/solar/farside?format=series` →
  the strongest detections modulate a far-hemisphere plage term; no
  invented sunspots). Deferred from Phase 1; small.
- **Markers vs shader spots rotation sense** — see the Phase 1 log entry;
  fold into Phase 4 when the photosphere shader is open anyway.
- **Historical frames for the scrubber** (Helioviewer `getJP2Image` →
  edge decode). Needs a JP2 decoder at the edge or a client-side WASM
  OpenJPEG; not free. Until then the scrubber keeps the honest
  `live-fallback` label.
- **Doppler mode in Observed.** HMI Dopplergrams exist
  (`latest_1024_HMID.jpg`); adding a `dop` channel to the proxy would make the
  convection plan's Phase 5 view observed too. Cheap; do it in Phase 1 if the
  NASA URL resolves from the deploy's network policy.
- **Solar Orbiter EUI far-side EUV** when geometry cooperates
  (`farside-sources.js` already lists it) — would let the far hemisphere be
  observed some of the time. Chip must say which spacecraft.
- **Settle the SUVI upstream path** (Phase 3e). The browse URL is UNVERIFIED —
  services.swpc.noaa.gov is egress-blocked from the build sandbox — so it
  resolves from a candidate list. ONE production request settles it:
  `curl -s '…/api/solar/aia?channel=suvi304&meta=1' | jq '.source_id, .upstream, .candidates'`.
  Record the winner in `js/suvi-geometry.js` `SOURCE_CANDIDATES`, move it to the
  head, delete the ones that never hit, and swap `api/health.js`'s `goes-suvi`
  URL for it. Until then `status.html` may show that row red for the PATH rather
  than the feed, which is why the notes field says so.
- **Carry the off-limb ring out to SUVI's full reach** (Phase 3e). The drawn
  annulus is 1.0–1.6 R☉ for both sources so an A/B measures field of view and
  not two different annuli. SUVI honestly supports 1.667 R☉ on axis, and
  `u_radial` is already a uniform — so this is a per-source value plus a mesh
  built to the larger outer radius, not a rebuild. Small.
- **The other four SUVI bands.** `/api/solar/aia` already serves 94/171/195/284
  and `js/suvi-geometry.js` carries their ions and peak temperatures; only the
  off-limb layer's cool+hot pair consumes them today. 195 and 284 are NOT AIA's
  193 and 211 and must never be labelled as such — `AIA_CORRESPONDENCE` carries
  the flag.
- **Stereo pair / VR** — nothing here blocks it, nothing here does it.
