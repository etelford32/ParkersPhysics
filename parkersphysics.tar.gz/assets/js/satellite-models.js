/**
 * satellite-models.js — rough 3D shapes for orbital probes
 * ═══════════════════════════════════════════════════════════════════════════
 * Builds approximate Three.js meshes for the named satellites the
 * upper-atmosphere page tracks. Style is "recognisable silhouette",
 * not "engineering CAD" — the goal is for a user who's zoomed close
 * enough to see "that's the ISS truss" or "that's a Starlink panel"
 * without needing megabytes of GLTF assets.
 *
 * Body-frame convention (matches _stepSatellites' lookAt in
 * upper-atmosphere-globe.js):
 *
 *   −Z  = velocity vector (ram direction)
 *   +Y  = radial-out (away from Earth, "up" in the local-orbit frame)
 *   ±X  = orbit-normal (cross-track) — solar panels typically extend
 *          along this axis on Earth-pointing missions.
 *
 * All dimensions are in scene units (1 = Earth radius = 6371 km). The
 * artistic scale is intentionally exaggerated: a real ISS at 110 m
 * would be ~1.7e-5 units across, way too small to see. We render at
 * ~0.04 units (~250 km equivalent) so the silhouette is visible at
 * useful camera distances.
 *
 * Each builder returns a THREE.Group with a `.userData.kind` set so
 * the picker can resolve clicks back to the satellite spec.
 */

import * as THREE from 'three';

// ── Shared materials (cheap; reused across all meshes) ──────────────────────
//
// Cached at module scope so building 50 satellites doesn't allocate
// 50 copies of the same MaterialBasic. They use Basic (not Standard)
// to avoid forcing a lighting pass — the page already has a busy
// shader budget for the atmosphere shells.

// LIT, PHYSICALLY BASED (2026-10-11, plan §9.19 phase 1). The scene's only
// light was a faint ambient and every hull was an unlit flat colour, so a
// spacecraft read the same from the Sun side and from the shadow side. The
// upper-atmosphere globe now carries a sun-aligned DirectionalLight, an
// earthshine HemisphereLight aimed from the planet below the target, and
// hands these materials a SPACE ENVIRONMENT so metals have something to
// reflect — a metal with no environment under one light is a black shape
// with a highlight. `buildSpaceEnvironment` (black sky, a lit Earth below,
// the Sun's disc) is the PROCEDURAL baseline every model wears in the orbit
// view; in close-up the globe swaps in the REAL planet (phase 4: a cube
// render of the skin from the followed object's position, through PMREM)
// via the same `setModelEnvironment`. Roughness/metalness are generic spacecraft
// finishes (aluminium skin, gold MLI, glossy cells, white radiators), not
// measured BRDFs.
const _M = {
    bus:       new THREE.MeshStandardMaterial({ color: 0xdfe3e8, metalness: 0.85, roughness: 0.38 }),   // aluminium skin
    busDark:   new THREE.MeshStandardMaterial({ color: 0x8a96a8, metalness: 0.60, roughness: 0.55 }),   // shaded panels
    truss:     new THREE.MeshStandardMaterial({ color: 0xb8c0cc, metalness: 0.80, roughness: 0.45 }),   // structural
    panel:     new THREE.MeshStandardMaterial({ color: 0x101c4e, metalness: 0.35, roughness: 0.20 }),   // solar cells (glossy)
    panelEdge: new THREE.MeshStandardMaterial({ color: 0xffd060, metalness: 1.00, roughness: 0.32 }),   // gold edge trim
    antenna:   new THREE.MeshStandardMaterial({ color: 0xffd060, metalness: 1.00, roughness: 0.35 }),   // gold-MLI dish
    nozzle:    new THREE.MeshStandardMaterial({ color: 0x3a3a42, metalness: 0.90, roughness: 0.55 }),   // engine bell
    radiator:  new THREE.MeshStandardMaterial({ color: 0xf0f0f4, metalness: 0.10, roughness: 0.70 }),   // white thermal
};
const _tinted = [];
// LIT, and therefore TONE-MAPPED (plan §9.19 phase 5): the globe runs the
// renderer's filmic curve only while a model is in close-up, and exempts
// every material in the scene that does not carry this flag — the planet
// skin, the airglow, the ops rings and the catalogue dots are data
// visualisation, not light transport. A new model material must be lit
// through here (or `markLit`) or it renders a stop darker than its
// neighbours under the chase exposure.
for (const m of Object.values(_M)) m.userData.lit = true;
export function markLit(m) { m.userData.lit = true; return m; }
export const isLitMaterial = (m) => !!m?.userData?.lit;

/** Convenience: tint a fresh lit material. Used when the spec wants
 *  the bus colour-coded (Starlink shells in blue, Iridium in purple…). */
function _matTinted(hex) {
    const m = markLit(new THREE.MeshStandardMaterial({ color: new THREE.Color(hex), metalness: 0.45, roughness: 0.45 }));
    if (_env) m.envMap = _env;
    _tinted.push(m);
    return m;
}

let _env = null;
/** Every model material (shared + tinted) reflects this environment. */
export function setModelEnvironment(tex, intensity = 1.0) {
    _env = tex || null;
    for (const m of [...Object.values(_M), ..._tinted]) { m.envMap = _env; m.envMapIntensity = intensity; m.needsUpdate = true; }
}

/**
 * A procedural environment for spacecraft materials: an equirectangular
 * canvas — black space above, the lit Earth's blue-white filling the lower
 * hemisphere with a bright limb band at the horizon, a small Sun disc —
 * run through PMREM. Symbolic (the real environment is the planet's own
 * image), cheap (128×64), and enough to give a hull its reflections.
 */
export function buildSpaceEnvironment(renderer, { sunAzDeg = 30, sunElDeg = 25 } = {}) {
    const W = 128, H = 64;
    const c = document.createElement('canvas'); c.width = W; c.height = H;
    const ctx = c.getContext('2d');
    const img = ctx.createImageData(W, H);
    for (let j = 0; j < H; j++) {
        const el = 90 - (j + 0.5) / H * 180;        // +90 top … −90 bottom
        for (let i = 0; i < W; i++) {
            const az = (i + 0.5) / W * 360 - 180;
            let r = 2, g = 3, b = 8;                    // space
            if (el < 0) {                                // the Earth below the horizon
                const t = Math.min(1, -el / 90);
                r = 70 + 40 * t; g = 110 + 40 * t; b = 170 + 30 * t;
            }
            if (el < 4 && el > -10) {                    // the limb's airglow band
                const w = Math.exp(-((el + 1) * (el + 1)) / 8);
                r += 120 * w; g += 150 * w; b += 170 * w;
            }
            const dAz = Math.abs(((az - sunAzDeg + 540) % 360) - 180), dEl = el - sunElDeg;
            if (dAz * dAz + dEl * dEl < 9) { r = 255; g = 250; b = 235; }     // the Sun
            const o = (j * W + i) * 4;
            img.data[o] = Math.min(255, r); img.data[o + 1] = Math.min(255, g); img.data[o + 2] = Math.min(255, b); img.data[o + 3] = 255;
        }
    }
    ctx.putImageData(img, 0, 0);
    const tex = new THREE.CanvasTexture(c);
    tex.mapping = THREE.EquirectangularReflectionMapping;
    tex.colorSpace = THREE.SRGBColorSpace;
    const pmrem = new THREE.PMREMGenerator(renderer);
    const env = pmrem.fromEquirectangular(tex).texture;
    pmrem.dispose(); tex.dispose();
    return env;
}

/**
 * A solar-array pivot: the array (and its trim) in a Group tagged
 * `userData.solarArray = { axis: 'x' }` so the globe can turn it about the
 * boom/truss axis toward the Sun (kernel `arrayAlpha`). `collectSolarArrays`
 * finds them once per model.
 */
function _wing(x, y, z, children) {
    const w = new THREE.Group();
    w.position.set(x, y, z);
    w.userData.solarArray = { axis: 'x' };
    // An array is a flat specular surface: its local +Y normal can throw
    // the Sun at the camera (plan §9.19 phase 3). Cells are not mirrors:
    // a wide, weak flare.
    w.userData.glint = { sigmaDeg: 2.5, gain: 0.6, normal: [0, 1, 0] };
    for (const ch of children) w.add(ch);
    return w;
}
export function collectSolarArrays(group) {
    const out = [];
    group.traverse((o) => { if (o.userData?.solarArray) out.push(o); });
    return out;
}
/** Every surface that can flare: its object (the normal is in ITS local frame) and the glint spec. */
export function collectGlintSurfaces(group) {
    const out = [];
    group.traverse((o) => { if (o.userData?.glint) out.push(o); });
    return out;
}
/** Shadows (plan §9.19 phase 2): every mesh of a model casts and receives. */
export function enableModelShadows(group, on = true) {
    group.traverse((o) => { if (o.isMesh) { o.castShadow = on; o.receiveShadow = on; } });
}

let _glintTex = null;
/**
 * The flare sprite: a star glare (a hot core, a soft halo and four
 * diffraction spikes) drawn once to a canvas, additive, scaled by the
 * glint value at render time. A sprite, not a post-process bloom: this
 * page renders directly and a full-frame pass is a GPU-only upgrade (the
 * plan's phase 3 note); the mip-chain bloom of sun-post.js is the one to
 * reuse when it comes, never a thresholded UnrealBloom.
 */
export function makeGlintSprite() {
    if (!_glintTex) {
        const N = 128, c = document.createElement('canvas'); c.width = c.height = N;
        const ctx = c.getContext('2d');
        const g = ctx.createRadialGradient(N / 2, N / 2, 0, N / 2, N / 2, N / 2);
        g.addColorStop(0, 'rgba(255,255,255,1)'); g.addColorStop(0.08, 'rgba(255,250,235,0.95)');
        g.addColorStop(0.25, 'rgba(255,235,200,0.35)'); g.addColorStop(0.6, 'rgba(255,220,180,0.08)'); g.addColorStop(1, 'rgba(255,220,180,0)');
        ctx.fillStyle = g; ctx.fillRect(0, 0, N, N);
        ctx.globalCompositeOperation = 'lighter';
        for (const a of [0, Math.PI / 2]) {
            const sg = ctx.createLinearGradient(N / 2 - Math.cos(a) * N / 2, N / 2 - Math.sin(a) * N / 2, N / 2 + Math.cos(a) * N / 2, N / 2 + Math.sin(a) * N / 2);
            sg.addColorStop(0, 'rgba(255,245,225,0)'); sg.addColorStop(0.5, 'rgba(255,245,225,0.7)'); sg.addColorStop(1, 'rgba(255,245,225,0)');
            ctx.save(); ctx.translate(N / 2, N / 2); ctx.rotate(a); ctx.fillStyle = sg; ctx.translate(-N / 2, -N / 2);
            ctx.fillRect(0, N / 2 - 1.5, N, 3); ctx.restore();
        }
        _glintTex = new THREE.CanvasTexture(c);
        _glintTex.colorSpace = THREE.SRGBColorSpace;
    }
    const sp = new THREE.Sprite(markLit(new THREE.SpriteMaterial({ map: _glintTex, transparent: true, opacity: 0, depthWrite: false, depthTest: false, blending: THREE.AdditiveBlending })));
    sp.scale.setScalar(0.0001);
    sp.visible = false;
    sp.raycast = () => {};
    sp.userData = { kind: 'glint', untargetable: true };
    return sp;
}

// ── ISS ─────────────────────────────────────────────────────────────────────
//
// The defining ISS silhouette is the Integrated Truss Structure (ITS)
// running cross-track with eight large solar arrays at the ends, and
// the pressurised modules running along the velocity axis. We model:
//   • Main truss as a long thin box along X (cross-track)
//   • 8 solar arrays as dark blue rectangles, 4 per side
//   • Pressurised modules as a stack of 3 short cylinders along Z
//   • Cupola + Soyuz/Dragon as small protrusions
//
// Total span ~0.06 units (≈ 380 km artistic — visible from a couple
// Earth radii out without overwhelming the layer shells).

export function buildISSModel() {
    const g = new THREE.Group();
    g.name = 'iss-model';

    // Central pressurised module stack (lab + nodes + Russian segment),
    // running along the velocity axis (Z). Three short cylinders give
    // the right "tube of cans" feel without modeling each module.
    for (let i = -1; i <= 1; i++) {
        const mod = new THREE.Mesh(
            new THREE.CylinderGeometry(0.0035, 0.0035, 0.011, 12),
            _M.bus,
        );
        mod.rotation.x = Math.PI / 2;          // long axis → Z
        mod.position.z = i * 0.011;
        g.add(mod);
    }

    // Cross-track truss — the iconic ISS spar.
    const truss = new THREE.Mesh(
        new THREE.BoxGeometry(0.060, 0.0025, 0.0025),
        _M.truss,
    );
    g.add(truss);

    // Eight solar arrays, four per truss end. Arranged in 4 stacked
    // pairs (port-outboard, port-inboard, stbd-inboard, stbd-outboard).
    const arrayGeom = new THREE.BoxGeometry(0.013, 0.0006, 0.0085);
    const positions = [
        // port (−X)
        { x: -0.030, y:  0.005, z:  0.005 },
        { x: -0.030, y:  0.005, z: -0.005 },
        { x: -0.030, y: -0.005, z:  0.005 },
        { x: -0.030, y: -0.005, z: -0.005 },
        // starboard (+X)
        { x:  0.030, y:  0.005, z:  0.005 },
        { x:  0.030, y:  0.005, z: -0.005 },
        { x:  0.030, y: -0.005, z:  0.005 },
        { x:  0.030, y: -0.005, z: -0.005 },
    ];
    for (const p of positions) {
        const arr = new THREE.Mesh(arrayGeom, _M.panel);
        // Thin gold trim along the long edge — sells the silhouette.
        const trim = new THREE.Mesh(
            new THREE.BoxGeometry(0.013, 0.0007, 0.0008),
            _M.panelEdge,
        );
        trim.position.set(0, 0.0008 * Math.sign(p.y), 0);
        g.add(_wing(p.x, p.y, p.z, [arr, trim]));
    }

    // Two thermal-control radiators perpendicular to solar arrays —
    // gives a recognisable "white wings" cue distinct from the dark
    // solar panels.
    for (const sgn of [-1, 1]) {
        const rad = new THREE.Mesh(
            new THREE.BoxGeometry(0.018, 0.0006, 0.005),
            _M.radiator,
        );
        rad.position.set(sgn * 0.014, 0, 0.012);
        g.add(rad);
    }

    // Soyuz / Dragon dock at the −Z (forward) end — short cylinder.
    const visit = new THREE.Mesh(
        new THREE.CylinderGeometry(0.002, 0.002, 0.006, 10),
        _M.bus,
    );
    visit.rotation.x = Math.PI / 2;
    visit.position.z = -0.018;
    g.add(visit);

    return g;
}

// ── Hubble Space Telescope ─────────────────────────────────────────────────
//
// The HST is essentially a 13-m cylindrical tube with two solar arrays
// on opposite sides and an aperture door at one end. Long axis points
// inertially at the science target (not nadir or velocity), so this
// builder reflects the canonical "cylinder + wings" profile without
// trying to model attitude.

export function buildHubbleModel() {
    const g = new THREE.Group();
    g.name = 'hubble-model';

    // Main optical tube (long axis along Z = "ram" by convention; in
    // reality HST points wherever it's commanded, but Z is fine for
    // the silhouette).
    const tube = new THREE.Mesh(
        new THREE.CylinderGeometry(0.0055, 0.0055, 0.026, 18),
        _M.bus,
    );
    tube.rotation.x = Math.PI / 2;
    g.add(tube);

    // Aperture door at +Z end — short open cap.
    const door = new THREE.Mesh(
        new THREE.CylinderGeometry(0.0055, 0.0055, 0.0035, 18),
        _M.busDark,
    );
    door.rotation.x = Math.PI / 2;
    door.position.z = 0.014;
    g.add(door);

    // Two solar arrays extended along ±X from the mid-tube. Single
    // wing each (HST's are roller-blind cylindrical arrays in real
    // life, but a flat panel reads correctly at this scale).
    for (const sgn of [-1, 1]) {
        const wing = new THREE.Mesh(
            new THREE.BoxGeometry(0.020, 0.0005, 0.008),
            _M.panel,
        );
        g.add(_wing(sgn * 0.012, 0, 0, [wing]));
        // Boom connecting wing to bus.
        const boom = new THREE.Mesh(
            new THREE.CylinderGeometry(0.0008, 0.0008, 0.005, 6),
            _M.truss,
        );
        boom.rotation.z = Math.PI / 2;
        boom.position.set(sgn * 0.0035, 0, 0);
        g.add(boom);
    }

    // High-gain antenna dish on a boom (one of two real HGAs).
    const dish = new THREE.Mesh(
        new THREE.SphereGeometry(0.003, 10, 6, 0, Math.PI * 2, 0, Math.PI / 2),
        _M.antenna,
    );
    dish.rotation.x = Math.PI;          // bowl faces +Y (Earth)
    dish.position.set(0, -0.008, 0.005);
    g.add(dish);

    return g;
}

// ── Starlink (v1.0 / v1.5 generic) ──────────────────────────────────────────
//
// Starlink v1.x is a flat slab bus with a single roll-out solar
// array deployed once on orbit. Stowed it's a tabletop; deployed it's
// a long single wing. We build the deployed configuration since
// that's what the page is showing operational birds in.

export function buildStarlinkModel(tintHex = '#60a0ff') {
    const g = new THREE.Group();
    g.name = 'starlink-model';
    const tint = _matTinted(tintHex);

    // Bus: thin flat slab. Antenna face (+Y nadir) tinted with the
    // constellation colour for visual ID.
    const bus = new THREE.Mesh(
        new THREE.BoxGeometry(0.012, 0.0025, 0.014),
        _M.bus,
    );
    g.add(bus);
    // Tinted nadir-facing phased-array slab.
    const arr = new THREE.Mesh(
        new THREE.BoxGeometry(0.011, 0.0006, 0.013),
        tint,
    );
    arr.position.y = -0.0016;
    g.add(arr);

    // Single solar wing extended along +X (asymmetric is correct for
    // Starlink; the v1.5 birds fold out one side).
    const panel = new THREE.Mesh(
        new THREE.BoxGeometry(0.030, 0.0006, 0.008),
        _M.panel,
    );
    g.add(_wing(0.020, 0, 0, [panel]));
    // Boom mounting the panel.
    const boom = new THREE.Mesh(
        new THREE.CylinderGeometry(0.0007, 0.0007, 0.006, 6),
        _M.truss,
    );
    boom.rotation.z = Math.PI / 2;
    boom.position.set(0.008, 0, 0);
    g.add(boom);

    return g;
}

// ── Iridium NEXT ────────────────────────────────────────────────────────────
//
// Iridium NEXT has a triangular bus with three large mission antennas
// arrayed around it (the L-band cross-link and main mission antenna),
// plus a solar array. The triangular bus + radial antennas give the
// "starfish" silhouette seen in flares.

export function buildIridiumModel(tintHex = '#a080ff') {
    const g = new THREE.Group();
    g.name = 'iridium-model';
    const tint = _matTinted(tintHex);

    // Triangular-prism bus along Z.
    const bus = new THREE.Mesh(
        new THREE.CylinderGeometry(0.006, 0.006, 0.012, 3),
        _M.bus,
    );
    bus.rotation.x = Math.PI / 2;
    g.add(bus);

    // Three mission antenna panels arrayed at 120° around the bus.
    // These are the famous "Iridium flare" surfaces.
    for (let i = 0; i < 3; i++) {
        const ang = (i / 3) * Math.PI * 2;
        const pn = new THREE.Mesh(
            new THREE.BoxGeometry(0.013, 0.0008, 0.012),
            tint,
        );
        pn.position.set(Math.cos(ang) * 0.009, Math.sin(ang) * 0.009, 0);
        pn.rotation.z = ang;
        // The MMA is a polished aluminium plate: narrow, bright flares
        // (the real ones reached −8 mag). Its outward normal is local +Y.
        pn.userData.glint = { sigmaDeg: 0.7, gain: 1.6, normal: [0, 1, 0] };
        g.add(pn);
    }

    // Solar array along +X.
    const panel = new THREE.Mesh(
        new THREE.BoxGeometry(0.020, 0.0006, 0.007),
        _M.panel,
    );
    g.add(_wing(0.018, 0, 0, [panel]));

    return g;
}

// ── Generic cubesat / bus + panels ──────────────────────────────────────────
//
// Used for everything we don't have a custom model for (constellation
// dots, debris payloads, etc.). Cube bus with two solar wings — the
// universal "satellite" silhouette.

export function buildGenericSatModel(tintHex = '#cccccc') {
    const g = new THREE.Group();
    g.name = 'generic-sat-model';
    const tint = _matTinted(tintHex);

    const bus = new THREE.Mesh(
        new THREE.BoxGeometry(0.008, 0.008, 0.012),
        tint,
    );
    g.add(bus);

    // Two solar wings, ±X.
    for (const sgn of [-1, 1]) {
        const wing = new THREE.Mesh(
            new THREE.BoxGeometry(0.018, 0.0005, 0.007),
            _M.panel,
        );
        g.add(_wing(sgn * 0.013, 0, 0, [wing]));
    }

    // Small high-gain antenna dish nadir (+Y down? we use −Y for nadir
    // since +Y is radial-out by convention).
    const dish = new THREE.Mesh(
        new THREE.SphereGeometry(0.0025, 10, 6, 0, Math.PI * 2, 0, Math.PI / 2),
        _M.antenna,
    );
    dish.rotation.x = Math.PI;
    dish.position.set(0, -0.005, 0);
    g.add(dish);

    return g;
}

// ── Spent rocket body ──────────────────────────────────────────────────────
//
// Long cylinder + tapered nozzle at one end. No solar panels (these
// are dead hardware). Used for the rocket-bodies debris family when
// the camera is close enough to see one.

export function buildRocketBodyModel(tintHex = '#60d8a0') {
    const g = new THREE.Group();
    g.name = 'rb-model';
    const tint = _matTinted(tintHex);

    // Main stage cylinder (Z axis).
    const stage = new THREE.Mesh(
        new THREE.CylinderGeometry(0.005, 0.005, 0.030, 12),
        tint,
    );
    stage.rotation.x = Math.PI / 2;
    g.add(stage);

    // Conical nozzle at −Z end.
    const noz = new THREE.Mesh(
        new THREE.CylinderGeometry(0.0035, 0.006, 0.006, 14),
        _M.nozzle,
    );
    noz.rotation.x = -Math.PI / 2;
    noz.position.z = -0.018;
    g.add(noz);

    // Nose cap (or interstage) at +Z end.
    const nose = new THREE.Mesh(
        new THREE.CylinderGeometry(0.0035, 0.005, 0.005, 12),
        _M.bus,
    );
    nose.rotation.x = Math.PI / 2;
    nose.position.z = 0.0175;
    g.add(nose);

    return g;
}

// ── Debris fragment (small irregular shard) ────────────────────────────────
//
// A jagged tetrahedron-ish shape with a single small panel-like flap.
// Tiny — meant to be visible only when the camera is right next to a
// fragment. Tint matches the source-event family colour.

export function buildDebrisFragmentModel(tintHex = '#ff7099') {
    const g = new THREE.Group();
    g.name = 'debris-frag-model';
    const tint = _matTinted(tintHex);

    // Irregular core: a low-poly icosahedron offset slightly.
    const core = new THREE.Mesh(
        new THREE.IcosahedronGeometry(0.005, 0),
        tint,
    );
    core.rotation.set(0.4, 0.7, 0.2);
    g.add(core);

    // Bent panel-fragment hanging off one side (gives the shard a sense
    // of "this used to be part of something larger").
    const flap = new THREE.Mesh(
        new THREE.BoxGeometry(0.010, 0.0005, 0.005),
        _M.panel,
    );
    flap.position.set(0.005, 0.002, 0.001);
    flap.rotation.z = 0.6;
    flap.rotation.y = 0.3;
    g.add(flap);

    return g;
}

// ── Builder dispatch ───────────────────────────────────────────────────────
//
// Maps a satellite spec.id (or a constellation id) to the right
// builder. Falls back to the generic builder so unknown specs still
// get a recognisable shape. The dispatch covers both the named probes
// (iss, hubble, starlink, iridium) and constellation-cloud entries
// (where spec._constellationId resolves the family).

export function buildSatelliteModel(spec) {
    const id = spec?.id || '';
    const cId = spec?._constellationId || '';
    const tint = spec?.color || '#cccccc';

    if (id === 'iss')                                return buildISSModel();
    if (id === 'hubble')                             return buildHubbleModel();
    if (id === 'starlink' || cId.startsWith('starlink')) return buildStarlinkModel(tint);
    if (id === 'iridium'  || cId === 'iridium')      return buildIridiumModel(tint);
    return buildGenericSatModel(tint);
}

/**
 * Build a low-poly version of the same shape (currently identical to
 * the high-poly builder; kept as a separate entry point so we can
 * decimate later without touching call sites).
 *
 * The LOD tier list in upper-atmosphere-globe.js plugs both this and
 * buildSatelliteModel into a THREE.LOD.
 */
export function buildSatelliteModelLow(spec) {
    return buildSatelliteModel(spec);
}
