/**
 * satellite-tracker.js — Satellite orbit visualization and GP element management
 *
 * Fetches CCSDS OMM catalogs from the CelesTrak proxy endpoint, propagates orbits
 * using either the Rust SGP4 WASM module (when available) or a pure-JS
 * fallback, and renders satellite positions + orbit trails on a 3D Earth globe.
 *
 * ── Usage ────────────────────────────────────────────────────────────────────
 *   import { SatelliteTracker } from './js/satellite-tracker.js';
 *   const tracker = new SatelliteTracker(earthGroup, earthRadius);
 *   await tracker.loadGroup('stations');  // ISS, Tiangong, etc.
 *   // In animation loop:
 *   tracker.tick(Date.now());
 *
 * ── Data Flow ────────────────────────────────────────────────────────────────
 *   /api/celestrak/tle?group=stations → normalized CCSDS OMM records
 *   → SGP4 propagate each satellite to current time
 *   → TEME → ECEF → lat/lon/alt → 3D position on globe
 *   → Render as dots + optional orbit trails
 *
 * ── Coordinate Frames ────────────────────────────────────────────────────────
 *   GP epoch → SGP4 → TEME (True Equator Mean Equinox)
 *   TEME → GMST rotation → ECEF (Earth-Centered Earth-Fixed)
 *   ECEF → lat/lon/alt → 3D scene position on globe
 *
 * ── Data Quality Notes ──────────────────────────────────────────────────────
 *   - OMM/TLE GP records are mean elements, not osculating — use SGP4.
 *   - Accuracy: ~1 km at epoch, degrades ~1-2 km/day for LEO.
 *   - CelesTrak checks for a new GP release every two hours.
 *   - TEME→ECEF conversion uses a simplified GMST (no nutation/precession).
 *     For conjunction screening, IAU-2006/2000A precession-nutation would
 *     be needed — but for visualization, GMST is sufficient (<1 km error).
 */

import * as THREE from 'three';
import { geo, DEG, RAD } from './geo/coords.js';

const TWOPI    = 2 * Math.PI;
const DEG2RAD  = DEG;         // kept as alias for SGP4 orbital-element conversions
const RE_KM    = 6378.135;    // WGS-72 (SGP4 standard — distinct from geo.radiusKm)
const MIN_PER_DAY = 1440;

// Atomics slot indices in the sync Int32Array shared with the
// propagation worker. Mirrored at the top of
// js/operations/propagation-worker.js — keep in lockstep.
//
// The "true SAB protocol" uses these to coordinate the entire hot
// tick path without touching postMessage — main bumps REQUEST and
// Atomics.notify; worker waitAsync's, propagates, bumps PUBLISH and
// Atomics.notify; main polls PUBLISH each frame and gates the GPU
// upload on WRITING. add-sats / clear / init still flow over
// postMessage (rare control plane), and waitAsync yields the worker
// to the event loop between ticks so those handlers actually run.
const SYNC_PUBLISH_SLOT = 0;   // worker writes after each completed frame
const SYNC_WRITING_SLOT = 1;   // 1 while worker is mid-write, 0 when done
const SYNC_REQUEST_SLOT = 2;   // main writes the next frameId, notifies
const SYNC_RUNNING_SLOT = 3;   // main writes 0 to terminate the worker tick loop

// Control Float64 slot indices in the parallel ctrl SharedArrayBuffer.
const CTRL_JD_SLOT      = 0;
const CTRL_GMST_SLOT    = 1;
const CTRL_SCALE_SLOT   = 2;

// ── Rust WASM SGP4 (high-performance, loaded async) ────────────────────────
// Falls back to the JS propagator if WASM isn't available.
let _wasmSgp4 = null;
let _wasmLoading = false;

async function _loadWasmSgp4() {
    if (_wasmSgp4 || _wasmLoading) return _wasmSgp4;
    _wasmLoading = true;
    const t0 = performance.now();
    try {
        const mod = await import('./sgp4-wasm/sgp4_wasm.js');
        await mod.default();  // init WASM
        _wasmSgp4 = mod;
        console.info('[SatTracker] Rust SGP4 WASM loaded — high-performance propagation active');
        // Telemetry: how long did the WASM cold-start take? Big swings
        // in p95 here are usually network / CDN edge problems, not
        // wasm-bindgen instantiation. Lazy import so satellite-tracker
        // doesn't pull telemetry into pages that don't need it.
        try {
            const { telemetry } = await import('./telemetry.js');
            telemetry.recordPerf('wasm_sgp4_init', performance.now() - t0);
        } catch {}
    } catch (err) {
        console.debug('[SatTracker] WASM SGP4 not available, using JS fallback:', err.message);
        // Telemetry: don't burn an `error` row on this — WASM-unavailable
        // is an expected fallback for older browsers. Log as a tagged
        // app_perf with a -1 value so we can count occurrence rates
        // without polluting the error top-N.
        try {
            const { telemetry } = await import('./telemetry.js');
            telemetry.recordPerf('wasm_sgp4_init_failed', -1);
        } catch {}
    }
    _wasmLoading = false;
    return _wasmSgp4;
}

// Try to load WASM immediately (non-blocking)
const _wasmReady = _loadWasmSgp4();

/** Resolves (with the module, or null if it could not load) once the WASM
 *  load has settled. Callers that must use ONE propagator for a whole
 *  computation (js/climate-lab/lab-satellites.js) wait on this, because
 *  propagate() silently uses the JS path until the WASM arrives. */
export function whenWasmSettled() { return _wasmReady; }

/** Check if WASM SGP4 is loaded. */
export function isWasmLoaded() { return _wasmSgp4 !== null; }

/** Get the WASM module (or null). */
export function getWasmSgp4() { return _wasmSgp4; }

/** True when a normalized record has the complete OMM mean-element set. */
export function hasOmmElements(tle) {
    return !!tle
        && Number.isInteger(Number(tle.norad_id))
        && Number(tle.norad_id) > 0
        && Number.isFinite(Number(tle.epoch_jd))
        && Number.isFinite(Number(tle.inclination))
        && Number.isFinite(Number(tle.raan))
        && Number.isFinite(Number(tle.eccentricity))
        && Number.isFinite(Number(tle.arg_perigee))
        && Number.isFinite(Number(tle.mean_anomaly))
        && Number.isFinite(Number(tle.mean_motion))
        && Number(tle.mean_motion) > 0;
}

/** Positional argument contract shared by the main-thread and worker WASM APIs. */
export function ommElementArgs(tle) {
    return [
        Number(tle.norad_id),
        Number(tle.epoch_jd),
        Number.isFinite(Number(tle.bstar)) ? Number(tle.bstar) : 0,
        Number(tle.inclination),
        Number(tle.raan),
        Number(tle.eccentricity),
        Number(tle.arg_perigee),
        Number(tle.mean_anomaly),
        Number(tle.mean_motion),
        Number.isFinite(Number(tle.rev_at_epoch)) ? Math.max(0, Math.floor(Number(tle.rev_at_epoch))) : 0,
    ];
}

/** Propagate a TLE via Rust WASM if available, else JS fallback.
 *  Exported so pass-predictor.js and conjunction tools can reuse the same
 *  propagator the live tracker draws with. */
export function propagate(tle, tsince_min) {
    if (_wasmSgp4) {
        try {
            const result = tle.line1 && tle.line2
                ? _wasmSgp4.propagate_tle(tle.line1, tle.line2, tsince_min)
                : hasOmmElements(tle) && _wasmSgp4.propagate_omm
                    ? _wasmSgp4.propagate_omm(...ommElementArgs(tle), tsince_min)
                    : null;
            if (result && result.length >= 3 && isFinite(result[0])) {
                return { x: result[0], y: result[1], z: result[2] };
            }
        } catch (_) {
            // WASM propagation failed — fall through to JS
        }
    }
    return jsFallbackPropagate(tle, tsince_min);
}

/** Full-SGP4 batch propagation for either legacy TLE or normalized OMM. */
export function propagateBatch(tle, timesMin) {
    if (!_wasmSgp4) return null;
    try {
        if (tle?.line1 && tle?.line2 && _wasmSgp4.propagate_batch) {
            return _wasmSgp4.propagate_batch(tle.line1, tle.line2, timesMin);
        }
        if (hasOmmElements(tle) && _wasmSgp4.propagate_batch_omm) {
            return _wasmSgp4.propagate_batch_omm(...ommElementArgs(tle), timesMin);
        }
    } catch (_) { /* caller chooses its fallback */ }
    return null;
}

/** Whether the loaded WASM bundle can batch-propagate this record format. */
export function canBatchPropagate(tle) {
    return !!_wasmSgp4 && (
        (!!tle?.line1 && !!tle?.line2 && typeof _wasmSgp4.propagate_batch === 'function')
        || (hasOmmElements(tle) && typeof _wasmSgp4.propagate_batch_omm === 'function')
    );
}

// ── Pure JS SGP4 fallback (simplified Brouwer mean elements) ─────────────────
// This is a simplified propagator for when the Rust WASM module isn't loaded.
// Uses the same Keplerian mean motion + J2 secular perturbations, but skips
// the full SGP4 drag and deep-space corrections. Good to ~5 km for LEO.
//
// Exported for callers that need a synchronous propagator with no WASM wait.
// Measured against Vallado et al. 2006's SGP4 verification vectors it lands
// 7–18 km at epoch and ~60–110 km after 6–12 h (no drag) — fine for pass
// times, not for conjunction-grade work. The WASM kernel is the accurate
// path: since 2026-09-24 it is the `sgp4` crate and matches every Vallado
// row to < 1 m (tests/sgp4-vallado.mjs). Before that it was a broken
// hand-rolled SGP4 (5 260 km off at epoch), which is why the dashboard and
// satellites.html briefly routed around it.
export function jsFallbackPropagate(tle, tsince_min) {
    const n0 = tle.mean_motion * TWOPI / MIN_PER_DAY;  // rad/min
    const e0 = tle.eccentricity;
    const i0 = tle.inclination * DEG2RAD;
    const raan0 = tle.raan * DEG2RAD;
    const argp0 = tle.arg_perigee * DEG2RAD;
    const M0 = tle.mean_anomaly * DEG2RAD;

    const cosI = Math.cos(i0);
    const J2 = 0.001082616;
    const a = Math.pow(398600.8 / (n0 * n0 / 3600), 1 / 3);  // km
    const p = a * (1 - e0 * e0);

    // J2 secular rates
    const n0_corr = n0 * (1 + 1.5 * J2 * (RE_KM / p) ** 2 * (1 - 1.5 * (1 - cosI * cosI)));
    const raanDot = -1.5 * J2 * (RE_KM / p) ** 2 * n0 * cosI;
    const argpDot = 0.75 * J2 * (RE_KM / p) ** 2 * n0 * (5 * cosI * cosI - 1);

    const t = tsince_min;
    const M = M0 + n0_corr * t;
    const raan = raan0 + raanDot * t;
    const argp = argp0 + argpDot * t;

    // Kepler's equation (Newton-Raphson)
    let E = M;
    for (let k = 0; k < 10; k++) {
        const dE = (E - e0 * Math.sin(E) - M) / (1 - e0 * Math.cos(E));
        E -= dE;
        if (Math.abs(dE) < 1e-12) break;
    }

    const cosE = Math.cos(E);
    const sinE = Math.sin(E);
    const nu = Math.atan2(Math.sqrt(1 - e0 * e0) * sinE, cosE - e0);
    const r = a * (1 - e0 * cosE);

    // Position in orbital plane
    const u = argp + nu;
    const cosU = Math.cos(u), sinU = Math.sin(u);
    const cosR = Math.cos(raan), sinR = Math.sin(raan);
    const cosI2 = Math.cos(i0), sinI2 = Math.sin(i0);

    // TEME position (km)
    const x = r * (cosR * cosU - sinR * sinU * cosI2);
    const y = r * (sinR * cosU + cosR * sinU * cosI2);
    const z = r * sinU * sinI2;

    // Velocity (simplified — not needed for visualization)
    return { x, y, z };
}

// ── TEME → scene-frame position via unified coordinate module ───────────────
// GMST rotation, ECI→ECEF mapping, and the scene-frame flip (astronomical
// Z = north → Three.js Y = north, plus the −Z = +90°E convention) all live
// in js/geo/coords.js. This file stays focused on orbital mechanics (SGP4,
// Kepler) and delegates every Earth-geography conversion to the module.
//
// `_temeScratch` / `_sceneScratch` are module-level scratch vectors used by
// the per-frame `tick()` loop to avoid per-sat Vector3 allocations.
const _temeScratch  = new THREE.Vector3();
const _sceneScratch = new THREE.Vector3();

// Reused scratch for the LOD frustum + occlusion cull (_collectVisible).
// Module-level so the per-frame view update allocates nothing.
const _lodFrustum  = new THREE.Frustum();
const _lodProj     = new THREE.Matrix4();
const _lodInvWorld = new THREE.Matrix4();
const _lodCamLocal = new THREE.Vector3();

// ── Constellation color map ─────────────────────────────────────────────────
// Each group gets a distinct color for per-vertex coloring.
const GROUP_COLORS = {
    'stations':      new THREE.Color(0xffffff),  // white — ISS, Tiangong
    'starlink':      new THREE.Color(0xccddff),  // cool white — SpaceX
    'oneweb':        new THREE.Color(0x4488ff),  // blue — OneWeb
    'gps-ops':       new THREE.Color(0x00ff88),  // green — GPS
    'galileo':       new THREE.Color(0x00ccff),  // cyan — Galileo
    'beidou':        new THREE.Color(0xff8844),  // orange — BeiDou
    'glonass':       new THREE.Color(0xff4444),  // red — GLONASS
    'weather':       new THREE.Color(0xffdd44),  // yellow — GOES/JPSS/Meteosat
    'resource':      new THREE.Color(0x44ff44),  // lime — Landsat/Sentinel
    'science':       new THREE.Color(0xcc66ff),  // purple — Hubble/JWST/Chandra
    'iridium':       new THREE.Color(0xff66aa),  // pink — Iridium
    'globalstar':    new THREE.Color(0xffaa66),  // peach — Globalstar
    'amateur':       new THREE.Color(0x66ffcc),  // teal — Ham radio
    'visual':        new THREE.Color(0xffffaa),  // pale yellow — Bright objects
    'active':        new THREE.Color(0x88aacc),  // muted blue — All active
    'debris':        new THREE.Color(0xff2200),  // danger red — Debris (composite)
    // Per-event debris groups, colored to match debris-catalog.js families so
    // the satellites globe and the upper-atmosphere globe agree on what each
    // breakup cloud looks like. Hot reds → ASAT clouds, amber/peach → CZ-6A
    // upper-stage breakups, etc.
    'fengyun-1c-debris':  new THREE.Color(0xff3060),  // FY-1C ASAT (2007) — largest single event
    'cosmos-1408-debris': new THREE.Color(0xff5070),  // C1408 ASAT (2021) — ISS shell hazard
    'iridium-33-debris':  new THREE.Color(0xff7040),  // Iridium 33 collision (2009)
    'cosmos-2251-debris': new THREE.Color(0xff9050),  // Cosmos 2251 collision (2009)
    'sl-16-rb':      new THREE.Color(0xd6b070),  // tan — SL-16 / Zenit-2 R/B (large intact debris)
    'sl-8-rb':       new THREE.Color(0xaab0a8),  // cool grey — SL-8 / Cosmos-3M R/B
    'envisat':       new THREE.Color(0xe6c060),  // warm gold — Envisat (defunct ESA EO platform)
    'last-30-days':  new THREE.Color(0x00ffaa),  // mint — Recent launches
    'geo':           new THREE.Color(0xffaa00),  // amber — Geostationary
    'planet':        new THREE.Color(0x88ff88),  // light green — Planet Labs
    'search':        new THREE.Color(0x00ffcc),  // original cyan — Manual search
    '_default':      new THREE.Color(0x00ffcc),  // fallback
};

// Set of CelesTrak group IDs that represent tracked debris. Used by
// altitude-cohort + conjunction-screening helpers so a per-event toggle
// (just FY-1C, just Cosmos 1408, etc.) is still treated as "debris" when
// counting hazards in a sat's shell. Keep this in lockstep with
// GROUP_COLORS / GROUP_MAP / debris-catalog.js families.
export const DEBRIS_GROUP_IDS = new Set([
    'debris',
    'fengyun-1c-debris',
    'cosmos-1408-debris',
    'iridium-33-debris',
    'cosmos-2251-debris',
]);

/** True when a group id represents a tracked-debris layer. */
export function isDebrisGroup(group) { return DEBRIS_GROUP_IDS.has(group); }

/** Get the color for a constellation group. */
export function getGroupColor(group) {
    return GROUP_COLORS[group] ?? GROUP_COLORS._default;
}

/** Get the hex string for a group (for CSS). */
export function getGroupColorHex(group) {
    return '#' + (GROUP_COLORS[group] ?? GROUP_COLORS._default).getHexString();
}

// ── SatelliteTracker class ───────────────────────────────────────────────────

export class SatelliteTracker {
    /**
     * @param {THREE.Object3D} parent      Earth group to attach satellites to
     * @param {number}         earthRadius  Earth sphere radius in scene units
     * @param {object}         [opts]
     * @param {number}         [opts.maxSatellites=50000] Max satellites to render
     * @param {boolean}        [opts.showOrbits=true]     Draw orbit trails
     */
    constructor(parent, earthRadius, { maxSatellites = 50000, showOrbits = true } = {}) {
        this._parent = parent;
        // HEADLESS when parent is null: catalogue + propagation + conjunction
        // screening with nothing attached to a scene and no render-propagation
        // worker. js/conjunction-alert.js constructs it this way; before this
        // existed `parent.add` threw a TypeError there, the monitor swallowed
        // it as a console.warn, and conjunction screening never ran once.
        this._headless = !parent;
        this._earthR = earthRadius;
        this._maxSats = maxSatellites;
        this._showOrbits = showOrbits;
        this._satellites = [];   // array of { tle, epochJd, group, lat, lon, alt }
        // O(1) NORAD ID → index lookup. Kept in lockstep with _satellites
        // by _addSatellites; every consumer that needs a per-sat slot
        // (highlight sprite, TCA arcs, color overrides) uses this.
        this._indexByNorad = new Map();
        this._groups = new Map(); // group name → { visible, count, color }
        this._group = new THREE.Group();
        this._group.name = 'satellites';
        if (parent) parent.add(this._group);

        // Per-vertex color material (replaces uniform cyan)
        this._dotMat = new THREE.PointsMaterial({
            size: 0.008, sizeAttenuation: true,
            transparent: true, opacity: 0.9, depthWrite: false,
            vertexColors: true,
        });

        this._positions = null;
        this._colors = null;
        this._pointsMesh = null;

        // ── LOD draw-budget (opt-in) ────────────────────────────────
        // Off by default: satellites.html and any caller that never calls
        // setDrawBudget() draws every catalogued point, exactly as before.
        // When a caller (the Operations console's LOD controller) sets a
        // finite budget below the catalogue size, we attach a uniform-
        // stride index buffer that draws only `budget` points — a
        // spatially representative decimation across all groups. The
        // worker still propagates every object (propagation lives off the
        // render thread); we just stop feeding the GPU tens of thousands
        // of vertices it would draw on top of each other anyway.
        this._lodEnabled  = false;
        this._lodBudget   = Infinity;
        this._lodCull     = false;  // frustum + Earth-occlusion cull (camera-driven)
        this._lodIndexArr = null;   // reused Uint32Array(n) of drawn indices
        this._lodCand     = null;   // reused Uint32Array(n) of visible candidates
        this._lodDrawn    = 0;      // points actually drawn last apply

        // Batch propagation hot-path. WASM keeps a parallel registry
        // of parsed Sgp4State so the per-frame tick can call one
        // function instead of N (parse + init + propagate)s. The
        // registry is append-only and indices line up with
        // `_satellites[i]`. `_batchSyncedTo` tracks how many slots
        // have been registered; new sats get registered lazily at
        // the next tick or via _syncRegistry() so add-at-load and
        // WASM-ready-after-load both converge on a consistent state.
        this._batchOut       = null;       // Float32Array of length 3·maxSats
        this._batchSyncedTo  = 0;          // index up to which the registry is in sync
        this._batchAvailable = false;      // true once WASM exposes registry_*

        // Off-thread propagation. When a Worker spawns and reports
        // ready, the live tick stops calling WASM in-line and instead
        // hands the work to the worker. Two transports:
        //
        //   - SAB ("shared")     : crossOriginIsolated === true. We
        //     allocate a SharedArrayBuffer once, pass it to the worker,
        //     and use the same memory as the THREE position attribute.
        //     Tick messages carry only jd/gmst/scale; the worker writes
        //     directly into the SAB; the main thread sets needsUpdate
        //     and reads lat/lon from the same buffer. Zero CPU copies.
        //
        //   - Transferable       : not isolated (older browser, no
        //     COOP/COEP, mobile Safari). Single ArrayBuffer ping-pongs
        //     between main and worker via postMessage transfer.
        //
        // Both share the same _workerInFlight / _workerSyncedTo
        // bookkeeping; the difference is only in how positions
        // surface.
        this._worker          = null;
        this._workerReady     = false;
        this._workerSyncedTo  = 0;          // sats already shipped to the worker
        this._workerBuf       = null;       // transferable: Float32Array, our half of the ping-pong
        this._workerInFlight  = false;
        this._workerFrameId   = 0;
        this._workerLastFrame = 0;          // most recent frameId that landed
        this._workerEnabled   = !this._headless && (typeof Worker !== 'undefined');

        // SAB fast path. crossOriginIsolated requires COOP/COEP to be
        // set on the document; vercel.json + dev-server.mjs add them
        // on /operations.html. Pages without those headers (or
        // browsers that don't honour `credentialless` — Safari today)
        // see crossOriginIsolated === false and stay on the
        // transferable path.
        //
        // _syncSab is a tiny (16-byte) SAB carrying an Int32Array we
        // use as an Atomics fence between the worker's SAB writes
        // and the main thread's gl.bufferData read. Slot 0 is the
        // publish counter (worker writes after each completed
        // frame), slot 1 is the writing flag (1 while writes are in
        // progress, 0 when done). Without the fence, a slow render
        // could in principle overlap a worker write — bounded but
        // visually torn. With it, we just defer the upload one frame
        // when the writing flag is set.
        const isolated = !this._headless && typeof self !== 'undefined'
            && self.crossOriginIsolated
            && typeof SharedArrayBuffer !== 'undefined';
        this._posSab        = null;
        this._syncSab       = null;
        this._syncView      = null;
        this._ctrlSab       = null;
        this._ctrlView      = null;
        this._sabReady      = false;             // worker has accepted the SAB
        this._lastUploadedFrame = 0;             // frameId we last uploaded for
        // Atomics.waitAsync is what lets the worker stay coordinated
        // via SAB without burning a postMessage per frame. Falls
        // back to the message-driven path on engines that don't
        // support it (Chrome <87, FF <89, Safari <15.4).
        this._atomicsTickEnabled = isolated && typeof Atomics?.waitAsync === 'function';
        if (isolated) {
            try {
                this._posSab   = new SharedArrayBuffer(this._maxSats * 3 * 4);
                this._syncSab  = new SharedArrayBuffer(16);
                this._syncView = new Int32Array(this._syncSab);
                if (this._atomicsTickEnabled) {
                    this._ctrlSab  = new SharedArrayBuffer(24);
                    this._ctrlView = new Float64Array(this._ctrlSab);
                    // Worker starts the tick loop; main marks RUNNING=1
                    // so the worker's loop doesn't shut down before the
                    // first tick lands.
                    Atomics.store(this._syncView, SYNC_RUNNING_SLOT, 1);
                }
            } catch (err) {
                console.debug('[SatTracker] SAB alloc failed, transferable path only:', err.message);
                this._posSab = null;
                this._syncSab = null;
                this._syncView = null;
                this._ctrlSab = null;
                this._ctrlView = null;
                this._atomicsTickEnabled = false;
            }
        }

        if (this._workerEnabled) this._spawnWorker();

        // Shell visualization group
        this._shellGroup = new THREE.Group();
        this._shellGroup.name = 'orbital-shells';
        this._shellGroup.visible = false;
        if (parent) parent.add(this._shellGroup);

        // Optional single-satellite highlight (e.g. pin "ISS" out of the
        // stations group). Lazily built on the first setHighlight() call.
        this._highlightNoradId = null;
        this._highlightOpts    = null;
        this._highlightSprite  = null;
        this._highlightCanvas  = null;
        this._highlightTexture = null;

        // Colour-override layer. Map<noradId, THREE.Color>. Applied in
        // _updateColors() and _rebuildPoints(), so overrides survive
        // group-visibility toggles and catalog loads. Used by the
        // weather-alert overlay to tint flagged sats without disturbing
        // group colours.
        this._colorOverrides = null;
    }

    // ── Highlight a single satellite with a sprite (dot + text label) ────
    // So a specific NORAD ID stays findable in a field of ~30 k dots. The
    // sprite is a child of the tracker's internal group, so it inherits
    // whatever coordinate frame the parent container is in.
    //
    // opts: { label: string, color: hex }
    setHighlight(noradId, opts = {}) {
        this._highlightNoradId = noradId;
        this._highlightOpts    = {
            label: opts.label ?? '',
            color: opts.color ?? 0x00ffcc,
        };
        if (!this._highlightSprite) this._buildHighlightSprite();
        else                        this._rebuildHighlightTexture();
        this._highlightSprite.visible = true;
    }

    clearHighlight() {
        this._highlightNoradId = null;
        if (this._highlightSprite) this._highlightSprite.visible = false;
    }

    setHighlightVisible(v) {
        if (this._highlightSprite) {
            this._highlightSprite.visible = !!v && this._highlightNoradId != null;
        }
    }

    // ── Bulk per-satellite colour tinting ────────────────────────────────
    // For overlays that want to recolour many specific satellites at once
    // (e.g. "these sats are currently passing over an active NWS alert")
    // without fighting the group-colour system or allocating new geometry.
    // Writes into the existing colour buffer in-place.
    //
    // `overrideMap` is a Map<noradId, THREE.Color>, or null/undefined to
    // clear. Null clears; an empty Map also clears (cheap no-op).
    //
    // Safe to call every animation frame — but the matcher shouldn't
    // need more than ~1 Hz because satellites don't move far enough per
    // frame to cross alert-footprint boundaries.
    setColorOverrides(overrideMap) {
        this._colorOverrides = overrideMap && overrideMap.size > 0
            ? overrideMap
            : null;
        this._updateColors();
    }

    /** Remove any active colour overrides and restore group colours. */
    clearColorOverrides() {
        if (this._colorOverrides === null) return;
        this._colorOverrides = null;
        this._updateColors();
    }

    /**
     * Screen a target satellite against the loaded debris catalog only.
     *
     * Thin wrapper over screenConjunctions with groupFilter='debris' and
     * LEO-friendly defaults (50 km threshold, 24 h look-ahead, 10-min
     * step). Returns the same shape as screenConjunctions — caller can
     * derive a count, closest approach, or render a list.
     *
     * Callers should only invoke this on user demand (click Screen) —
     * it still propagates every debris entry via SGP4 and is NOT cheap
     * enough to run per frame.
     */
    async countDebrisApproaches(noradId, opts = {}) {
        const {
            withinKm  = 50,
            horizonH  = 24,
            stepMin   = 10,
        } = opts;
        // Screen against every loaded debris layer — the composite 'debris'
        // group OR any of the per-event subgroups (FY-1C, C-1408, IR-33,
        // C-2251) the user may have toggled on individually.
        return this.screenConjunctions(
            noradId, horizonH, stepMin, withinKm,
            [...DEBRIS_GROUP_IDS],
        );
    }

    /**
     * Instant per-altitude-band census of the catalog: given a reference
     * altitude and a band half-width (km), count how many debris / active
     * satellites currently sit within that band. Purely a filter over the
     * `alt` field the tracker updates each tick, so this is O(N_sats)
     * and safe to call every animation frame.
     *
     * @param {number}  altKm        Reference altitude (km above RE).
     * @param {number}  [bandKm=25]  Band half-width (km). Total band = 2·bandKm.
     * @param {number|null} [excludeId=null]  NORAD ID to exclude (usually the
     *                                        selected sat itself).
     * @returns {{ debris:number, active:number, total:number, bandKm:number }}
     */
    getAltitudeCohort(altKm, bandKm = 25, excludeId = null) {
        const lo = altKm - bandKm;
        const hi = altKm + bandKm;
        let debris = 0, active = 0;
        for (const s of this._satellites) {
            if (s.tle.norad_id === excludeId) continue;
            if (!Number.isFinite(s.alt))      continue;
            if (s.alt < lo || s.alt > hi)     continue;
            if (DEBRIS_GROUP_IDS.has(s.group)) debris++;
            else                               active++;
        }
        return { debris, active, total: debris + active, bandKm };
    }

    /**
     * Return the satellites in a given CelesTrak group, shaped like
     * getSatellites() entries.  Handy for group-scoped analytics /
     * overlays that shouldn't re-filter the full catalog each time.
     */
    getSatellitesByGroup(group) {
        return this._satellites
            .filter(s => s.group === group)
            .map(s => ({
                name:        s.tle.name,
                norad_id:    s.tle.norad_id,
                group:       s.group,
                lat:         s.lat,
                lon:         s.lon,
                alt:         s.alt,
                period_min:  s.tle.period_min,
                inclination: s.tle.inclination,
                apogee_km:   s.tle.apogee_km,
                perigee_km:  s.tle.perigee_km,
            }));
    }

    /**
     * Return the raw TLE objects for a given CelesTrak group, or an
     * array aggregated across groups when `group === null`.  Used by
     * the Web Worker pre-compute path to ship catalogs across the
     * postMessage boundary without including the scratch render state.
     *
     * @param {string|string[]|null} group  group name, list of names,
     *        or null to mean "every loaded group".
     */
    getTlesByGroup(group) {
        const matches = (g) => {
            if (group == null) return true;
            if (Array.isArray(group)) return group.includes(g);
            // 'debris' is treated as the union of every loaded debris
            // layer (the composite + the four per-event groups). Without
            // this, callers asking for the "debris catalog" would miss
            // anything the user loaded via a per-event toggle (FY-1C,
            // Cosmos 1408, etc.) and the density map / conjunction
            // screener would silently undercount hazards.
            if (group === 'debris') return DEBRIS_GROUP_IDS.has(g);
            return g === group;
        };
        return this._satellites
            .filter(s => matches(s.group))
            .map(s => s.tle);
    }

    _buildHighlightSprite() {
        const cv  = document.createElement('canvas');
        cv.width  = 128;
        cv.height = 40;
        const tex = new THREE.CanvasTexture(cv);
        tex.minFilter = THREE.LinearFilter;
        const mat = new THREE.SpriteMaterial({
            map: tex, transparent: true,
            depthWrite: false, depthTest: false,
        });
        const sprite = new THREE.Sprite(mat);
        // World-unit size: ≈1/5 of Earth radius. Keep 128×40 canvas aspect.
        sprite.scale.set(0.20, 0.0625, 1);
        // Anchor the sprite on the *dot* (drawn at canvas x=20 / 128 = 0.156),
        // not the canvas centre — so sprite.position = sat.position puts the
        // dot right on the satellite and the label trails to the right.
        sprite.center.set(20 / 128, 0.5);
        sprite.renderOrder = 12;
        this._highlightSprite  = sprite;
        this._highlightCanvas  = cv;
        this._highlightTexture = tex;
        this._group.add(sprite);
        this._rebuildHighlightTexture();
    }

    _rebuildHighlightTexture() {
        const cv    = this._highlightCanvas;
        const ctx   = cv.getContext('2d');
        const color = this._highlightOpts.color;
        const label = this._highlightOpts.label;
        const hex   = '#' + color.toString(16).padStart(6, '0');

        ctx.clearRect(0, 0, cv.width, cv.height);
        // Soft halo + solid core so the dot stands out on bright and dark
        // continents alike. Three concentric fills at decreasing radius.
        ctx.fillStyle = hex;
        ctx.globalAlpha = 0.22;
        ctx.beginPath(); ctx.arc(20, 20, 16, 0, Math.PI * 2); ctx.fill();
        ctx.globalAlpha = 0.55;
        ctx.beginPath(); ctx.arc(20, 20, 10, 0, Math.PI * 2); ctx.fill();
        ctx.globalAlpha = 1.0;
        ctx.beginPath(); ctx.arc(20, 20,  5, 0, Math.PI * 2); ctx.fill();

        // Label — outlined for legibility over any globe colour.
        ctx.font         = 'bold 18px system-ui, sans-serif';
        ctx.textAlign    = 'left';
        ctx.textBaseline = 'middle';
        ctx.lineWidth    = 4;
        ctx.strokeStyle  = 'rgba(0, 0, 0, 0.85)';
        ctx.strokeText(label, 38, 22);
        ctx.fillStyle    = hex;
        ctx.fillText(label, 38, 22);

        this._highlightTexture.needsUpdate = true;
    }

    /**
     * Fetch a CelesTrak satellite group and ADD to existing catalog.
     * Supports loading multiple groups without replacing previous data.
     * @param {string} group  CelesTrak group name (e.g. 'stations', 'starlink')
     */
    async loadGroup(group = 'stations') {
        if (this._groups.has(group)) return this._groups.get(group).count;
        const _t0 = performance.now();
        try {
            const res = await fetch(`/api/celestrak/tle?group=${group}`);
            const data = await res.json().catch(() => ({}));
            if (!res.ok || data.error) {
                const reason = data.error
                    ? `${data.error}${data.detail ? `: ${data.detail}` : ''}`
                    : `HTTP ${res.status}`;
                throw new Error(reason);
            }
            // Telemetry: record the TLE-load latency for the superadmin
            // perf summary. Surfaces as `tle_load_ms` per route. Slow
            // p95 here is a CelesTrak / edge proxy issue, not a client
            // one. Lazy import keeps satellite-tracker free of a
            // hard dep on telemetry.
            try {
                const { telemetry } = await import('./telemetry.js');
                telemetry.recordPerf(`tle_load_${group}`, performance.now() - _t0);
            } catch {}

            const tles = data.satellites ?? [];
            const added = this._addSatellites(tles, group);
            this._groups.set(group, {
                visible: true,
                count: added,
                color: GROUP_COLORS[group] ?? GROUP_COLORS._default,
                error: null,
                composite: data.composite ?? false,
                subgroups: data.subgroups ?? null,
                fetched: data.fetched ?? new Date().toISOString(),
                source: data.source ?? 'CelesTrak GP',
                sourceFormat: data.source_format ?? 'unknown',
                upstreamCount: Number(data.upstream_count ?? tles.length),
                rejectedCount: Number(data.rejected_count ?? 0),
                updateCadenceHours: Number(data.update_cadence_hours ?? 2),
                health: data.health ?? null,
            });

            // Composite groups can succeed-with-partial. Keep that visible.
            const partial = (data.subgroups ?? []).filter(s => s.status === 'error');
            if (partial.length > 0) {
                console.warn(`[SatTracker] ${group}: ${partial.length}/${data.subgroups.length} subgroups failed:`,
                    partial.map(p => `${p.group} (${p.error})`).join(', '));
            }
            console.info(`[SatTracker] +${added} satellites (${group}) — total: ${this._satellites.length}`);

            window.dispatchEvent(new CustomEvent('satellites-loaded', {
                detail: {
                    group, count: added, total: this._satellites.length,
                    sourceFormat: data.source_format ?? 'unknown',
                    rejectedCount: Number(data.rejected_count ?? 0),
                },
            }));

            return added;
        } catch (err) {
            console.warn(`[SatTracker] Failed to load ${group}:`, err.message);
            // Record the failure so the UI can render a "failed (retry)"
            // state instead of an indeterminate "—". A subsequent
            // loadGroup() call will short-circuit on hasGroup(); callers
            // wanting a retry should remove the group first.
            this._groups.set(group, {
                visible: false,
                count: 0,
                color: GROUP_COLORS[group] ?? GROUP_COLORS._default,
                error: err.message || 'unknown',
                fetched: new Date().toISOString(),
            });
            window.dispatchEvent(new CustomEvent('satellites-load-failed', {
                detail: { group, error: err.message },
            }));
            return 0;
        }
    }

    /**
     * Forget a group entry so a subsequent loadGroup() will refetch.
     * Used by the layer panel's retry-on-failed-load button. Does not
     * remove already-rendered satellites for the group (call
     * unloadGroup() for that).
     */
    forgetGroup(group) {
        if (!this._groups.has(group)) return;
        const entry = this._groups.get(group);
        // Only forget failed entries — a successful load keeps its
        // satellites in _satellites so a forget+reload would dupe them.
        if (entry.error) this._groups.delete(group);
    }

    /**
     * Load a single satellite by NORAD ID.
     * @param {number} noradId  NORAD catalog number
     */
    async loadNorad(noradId) {
        const _t0 = performance.now();
        try {
            const res = await fetch(`/api/celestrak/tle?norad=${noradId}`);
            if (!res.ok) throw new Error(`HTTP ${res.status}`);
            const data = await res.json();
            if (data.error) throw new Error(data.error);

            const sats = data.satellites ?? [];
            this._addSatellites(sats, 'search');
            try {
                const { telemetry } = await import('./telemetry.js');
                telemetry.recordPerf('tle_load_norad', performance.now() - _t0);
            } catch {}
            return sats[0] ?? null;
        } catch (err) {
            console.warn(`[SatTracker] Failed to load NORAD ${noradId}:`, err.message);
            return null;
        }
    }

    /** Toggle visibility of a constellation group. */
    setGroupVisible(group, visible) {
        const g = this._groups.get(group);
        if (!g) return;
        g.visible = visible;
        this._updateColors();
    }

    /**
     * Suppress only the point-sprite render for a group while keeping
     * propagation, picking, and group visibility otherwise unchanged.
     *
     * Used by alternate renderers (e.g. the Starlink InstancedMesh in
     * `operations/starlink-model.js`) that replace dots with real 3D
     * geometry — without this, every Starlink would draw both a dot
     * and a mesh at the same point, the dot bleeding visibly through
     * the mesh on near-zoom and showing as a tiny artefact on far-zoom.
     */
    setGroupDotsVisible(group, dotsVisible) {
        const g = this._groups.get(group);
        if (!g) return;
        const hidden = !dotsVisible;
        if (g.dotsHidden === hidden) return;
        g.dotsHidden = hidden;
        this._updateColors();
    }

    /** Check if a group is loaded. */
    hasGroup(group) { return this._groups.has(group); }

    /** Get loaded group info. */
    getGroupInfo(group) { return this._groups.get(group) ?? null; }

    /** Get all loaded group names. */
    getLoadedGroups() { return [...this._groups.keys()]; }

    /** Maximum normalized records this tracker instance can retain. */
    getCatalogCapacity() { return this._maxSats; }

    /** Get count per group. */
    getGroupCounts() {
        const out = {};
        for (const [name, g] of this._groups) out[name] = g.count;
        return out;
    }

    /** Get altitude distribution for loaded satellites (for heatmap). */
    getAltitudeDistribution(binSizeKm = 25) {
        const bins = {};
        for (const sat of this._satellites) {
            const alt = (sat.tle.perigee_km + sat.tle.apogee_km) / 2;
            const bin = Math.round(alt / binSizeKm) * binSizeKm;
            bins[bin] = (bins[bin] || 0) + 1;
        }
        return Object.entries(bins)
            .map(([alt, count]) => ({ alt: +alt, count }))
            .sort((a, b) => a.alt - b.alt);
    }

    /** Add satellites to catalog, tagged with their group. Returns count added. */
    _addSatellites(tles, group = '_default') {
        let added = 0;
        const color = GROUP_COLORS[group] ?? GROUP_COLORS._default;
        for (const tle of tles) {
            if (this._satellites.length >= this._maxSats) break;
            // O(1) dedupe via the NORAD→index map; previously an O(N)
            // `find` per TLE, which turned loading a 30 k-row group into
            // an O(N²) start-up.
            if (this._indexByNorad.has(tle.norad_id)) continue;

            const epochJd = tleEpochToJd(tle);
            this._indexByNorad.set(tle.norad_id, this._satellites.length);
            this._satellites.push({ tle, epochJd, group, color, lat: 0, lon: 0, alt: 400 });
            added++;
        }
        if (added > 0) this._rebuildPoints();
        return added;
    }

    /**
     * Pick the nearest currently-visible satellite under an NDC point.
     * Uses Three.js Raycaster against the internal Points mesh, then
     * filters hits whose group is toggled off so only visible dots can
     * be selected. Returns { noradId, distance } or null.
     *
     * @param {{x:number,y:number}} ndc         NDC cursor coords (−1..+1).
     * @param {THREE.Camera} camera             The rendering camera.
     * @param {object} [opts]
     * @param {number} [opts.threshold=0.02]   World-space pick radius.
     */
    pickAtNDC(ndc, camera, { threshold = 0.02 } = {}) {
        if (!this._pointsMesh) return null;
        const ray = new THREE.Raycaster();
        ray.setFromCamera(ndc, camera);
        ray.params.Points = { threshold };
        const hits = ray.intersectObject(this._pointsMesh);
        for (const hit of hits) {
            const sat = this._satellites[hit.index];
            if (!sat) continue;
            const g = this._groups.get(sat.group);
            if (g && !g.visible) continue;   // skip hidden groups
            return { noradId: sat.tle.norad_id, distance: hit.distance };
        }
        return null;
    }

    /**
     * Read the current scene-space Vec3 of a tracked satellite. Returns
     * `out` on success (for chaining) and null when the sat isn't in the
     * catalog or positions haven't been built yet.  Used by the TCA
     * collision-arc renderer; O(1) via `_indexByNorad`.
     */
    getPositionXYZ(noradId, out) {
        const idx = this._indexByNorad.get(noradId);
        if (idx == null || !this._positions) return null;
        const a = this._positions.array;
        const o = out ?? { x: 0, y: 0, z: 0 };
        o.x = a[idx * 3];
        o.y = a[idx * 3 + 1];
        o.z = a[idx * 3 + 2];
        return o;
    }

    /** Rebuild the Points mesh with per-vertex colors. */
    _rebuildPoints() {
        if (this._pointsMesh) {
            this._group.remove(this._pointsMesh);
            this._pointsMesh.geometry.dispose();
        }
        const n = this._satellites.length;
        // SAB fast path: the position attribute is a Float32Array
        // view over the shared SAB the worker is also writing to. As
        // n grows we re-wrap the view; the SAB itself was sized to
        // maxSats at construction so we never reallocate. WebGL's
        // bufferData reads through the typed array view, which works
        // regardless of whether the underlying buffer is an
        // ArrayBuffer or a SharedArrayBuffer.
        const posArr = this._posSab
            ? new Float32Array(this._posSab, 0, n * 3)
            : new Float32Array(n * 3);
        const colArr = new Float32Array(n * 3);

        const overrides = this._colorOverrides;
        for (let i = 0; i < n; i++) {
            const sat   = this._satellites[i];
            const gInfo = this._groups.get(sat.group);
            const visible = gInfo ? gInfo.visible : true;
            const dotsOff = gInfo ? !!gInfo.dotsHidden : false;
            // Explicit override (e.g. weather-alert tint) wins over group
            // colour, but still respects group visibility — a hidden group
            // stays hidden even if its sat is flagged. `dotsHidden`
            // forces the hidden colour regardless of override; that's
            // the path the Starlink mesh renderer takes to silence the
            // underlying point.
            const override = overrides?.get(sat.tle.norad_id);
            const c = !visible || dotsOff ? _hiddenColor
                    : override            ? override
                    :                       sat.color;
            colArr[i * 3]     = c.r;
            colArr[i * 3 + 1] = c.g;
            colArr[i * 3 + 2] = c.b;
        }

        this._positions = new THREE.BufferAttribute(posArr, 3);
        this._colors = new THREE.BufferAttribute(colArr, 3);
        const bufGeo = new THREE.BufferGeometry();
        bufGeo.setAttribute('position', this._positions);
        bufGeo.setAttribute('color', this._colors);
        this._pointsMesh = new THREE.Points(bufGeo, this._dotMat);
        this._pointsMesh.renderOrder = 10;
        this._group.add(this._pointsMesh);

        // Catalogue size changed → the prior index/candidate buffers no
        // longer map. Drop them and recompute (no-op when LOD is disabled).
        this._lodIndexArr = null;
        this._lodCand     = null;
        this._applyLod(null);
    }

    /**
     * Set the maximum number of points to draw individually (no view cull).
     * Pass a finite number to enable uniform-stride decimation; Infinity /
     * null draws the whole catalogue. Cheap and idempotent.
     */
    setDrawBudget(maxDrawn) {
        const b = Number.isFinite(maxDrawn) ? Math.max(1, Math.floor(maxDrawn)) : Infinity;
        if (b === this._lodBudget && !this._lodCull) return;
        this._lodBudget  = b;
        this._lodCull    = false;
        this._lodEnabled = Number.isFinite(b);
        this._applyLod(null);
    }

    /**
     * Camera-driven LOD: keep only points inside the frustum and not
     * occluded by Earth, then decimate that visible set to `budget`. This
     * spends the draw budget on what's actually on screen instead of the
     * far side of the globe. Call every frame (the Operations LOD
     * controller throttles to camera motion). Returns the points drawn.
     */
    updateLodView(camera, { budget = this._lodBudget, cull = true } = {}) {
        this._lodBudget  = Number.isFinite(budget) ? Math.max(1, Math.floor(budget)) : Infinity;
        this._lodCull    = !!cull && !!camera;
        this._lodEnabled = Number.isFinite(this._lodBudget) || this._lodCull;
        this._applyLod(camera);
        return this._lodDrawn;
    }

    /** Points actually drawn (after any LOD decimation). */
    getDrawnCount() { return this._lodDrawn || this._satellites.length; }
    /** Total catalogued (and still fully propagated) objects. */
    getCatalogSize() { return this._satellites.length; }

    /** Normalized orbit records currently retained, deduplicated by NORAD ID. */
    getCatalogRecords() { return this._satellites.map(sat => sat.tle); }

    /**
     * Recompute the draw set. With cull on, the candidate list is the
     * frustum-visible, un-occluded points; otherwise it's the whole
     * catalogue. The list is then decimated to the budget via uniform
     * stride (so every group thins proportionally) and written into a
     * reused index buffer drawn via setDrawRange — no per-frame realloc.
     */
    _applyLod(camera) {
        if (!this._pointsMesh) return;
        const geo = this._pointsMesh.geometry;
        const n = this._satellites.length;

        // Disabled, empty, or nothing to thin and no cull → draw everything,
        // no index. This is the exact pre-LOD path (satellites.html stays here).
        if (!this._lodEnabled || n === 0 || (!this._lodCull && this._lodBudget >= n)) {
            if (geo.index !== null) geo.setIndex(null);
            geo.setDrawRange(0, Infinity);
            this._lodDrawn = n;
            return;
        }

        // Candidate list.
        const cand = this._ensureLodBuf('_lodCand', n);
        let m;
        if (this._lodCull && camera) {
            m = this._collectVisible(camera, cand, n);
        } else {
            for (let i = 0; i < n; i++) cand[i] = i;
            m = n;
        }

        // Decimate candidates → drawn budget.
        const budget = this._lodBudget >= n ? m : this._lodBudget;
        const K = Math.max(0, Math.min(m, budget));
        const idx = this._ensureLodIndex(n, geo);
        if (K === m) {
            idx.set(cand.subarray(0, K));
        } else if (K > 0) {
            const stride = m / K;
            for (let j = 0; j < K; j++) idx[j] = cand[Math.min(m - 1, (j * stride) | 0)];
        }
        geo.index.needsUpdate = true;
        geo.setDrawRange(0, K);
        this._lodDrawn = K;
    }

    /** Ensure a reused Uint32Array(≥n) field; reallocs only when it grows. */
    _ensureLodBuf(field, n) {
        let buf = this[field];
        if (!buf || buf.length < n) buf = this[field] = new Uint32Array(n);
        return buf;
    }

    /** Ensure the geometry's index attribute is our reused full-size array. */
    _ensureLodIndex(n, geo) {
        if (!this._lodIndexArr || this._lodIndexArr.length < n) {
            this._lodIndexArr = new Uint32Array(n);
            geo.setIndex(new THREE.BufferAttribute(this._lodIndexArr, 1));
        } else if (geo.index?.array !== this._lodIndexArr) {
            geo.setIndex(new THREE.BufferAttribute(this._lodIndexArr, 1));
        }
        return this._lodIndexArr;
    }

    /**
     * Collect indices of points that are inside the camera frustum and not
     * hidden behind Earth, into `cand`. Returns the count. Works in the
     * points mesh's local space: the frustum planes and the camera position
     * are transformed once into local coords, so the per-point test is a
     * handful of dot products (no per-point matrix multiply). Hidden groups
     * are skipped so the budget isn't spent on invisible dots.
     */
    _collectVisible(camera, cand, n) {
        const mesh = this._pointsMesh;
        mesh.updateWorldMatrix(true, false);
        _lodInvWorld.copy(mesh.matrixWorld).invert();
        // Our caller runs inside onTick, before the renderer refreshes the
        // camera matrices — derive a current view matrix ourselves so the
        // frustum matches what will be drawn this frame.
        camera.updateMatrixWorld();
        camera.matrixWorldInverse.copy(camera.matrixWorld).invert();
        _lodProj.multiplyMatrices(camera.projectionMatrix, camera.matrixWorldInverse);
        _lodFrustum.setFromProjectionMatrix(_lodProj);
        for (const plane of _lodFrustum.planes) plane.applyMatrix4(_lodInvWorld);
        _lodCamLocal.setFromMatrixPosition(camera.matrixWorld).applyMatrix4(_lodInvWorld);

        const R2 = this._earthR * this._earthR;
        const cDotC = _lodCamLocal.lengthSq();            // |C-O|², O = origin
        const cOutside = cDotC > R2;                       // camera above surface
        const planes = _lodFrustum.planes;
        const pos = this._positions.array;

        // Precompute hidden groups so the inner loop skips invisible dots.
        let hidden = null;
        for (const [name, g] of this._groups) {
            if (!g.visible || g.dotsHidden) (hidden ??= new Set()).add(name);
        }
        const sats = this._satellites;

        let m = 0;
        for (let i = 0; i < n; i++) {
            if (hidden && hidden.has(sats[i].group)) continue;
            const x = pos[i * 3], y = pos[i * 3 + 1], z = pos[i * 3 + 2];

            // Frustum: inside all six planes (signed distance ≥ 0).
            let inside = true;
            for (let p = 0; p < 6; p++) {
                const pl = planes[p].normal;
                if (pl.x * x + pl.y * y + pl.z * z + planes[p].constant < 0) { inside = false; break; }
            }
            if (!inside) continue;

            // Earth occlusion: does the segment C→P pierce the globe before P?
            // Quadratic |C + t(P−C)|² = R² ; occluded if a root lies in (0,1).
            if (cOutside) {
                const dx = x - _lodCamLocal.x, dy = y - _lodCamLocal.y, dz = z - _lodCamLocal.z;
                const a = dx * dx + dy * dy + dz * dz;
                const b = 2 * (_lodCamLocal.x * dx + _lodCamLocal.y * dy + _lodCamLocal.z * dz);
                const c = cDotC - R2;
                const disc = b * b - 4 * a * c;
                if (disc > 0) {
                    const t = (-b - Math.sqrt(disc)) / (2 * a);
                    if (t > 0 && t < 1) continue;          // globe blocks the point
                }
            }
            cand[m++] = i;
        }
        return m;
    }

    /** Update only the color buffer (for show/hide toggles + alert tints). */
    _updateColors() {
        if (!this._colors) return;
        const colArr = this._colors.array;
        const overrides = this._colorOverrides;
        for (let i = 0; i < this._satellites.length; i++) {
            const sat = this._satellites[i];
            const gInfo = this._groups.get(sat.group);
            const visible = gInfo ? gInfo.visible : true;
            const dotsOff = gInfo ? !!gInfo.dotsHidden : false;
            const override = overrides?.get(sat.tle.norad_id);
            if (visible && !dotsOff && override) {
                colArr[i * 3]     = override.r;
                colArr[i * 3 + 1] = override.g;
                colArr[i * 3 + 2] = override.b;
            } else if (visible && !dotsOff) {
                colArr[i * 3]     = sat.color.r;
                colArr[i * 3 + 1] = sat.color.g;
                colArr[i * 3 + 2] = sat.color.b;
            } else {
                colArr[i * 3] = colArr[i * 3 + 1] = colArr[i * 3 + 2] = 0;
            }
        }
        this._colors.needsUpdate = true;
    }

    /* ─── Off-thread propagation ────────────────────────────── */

    _spawnWorker() {
        try {
            const url = new URL('./operations/propagation-worker.js', import.meta.url);
            this._worker = new Worker(url, { type: 'module' });
            this._worker.onerror = (ev) => {
                console.warn('[SatTracker] propagation worker errored, falling back:', ev.message);
                this._teardownWorker();
            };
            this._worker.onmessage = (ev) => this._onWorkerMessage(ev.data);
            this._worker.postMessage({ type: 'init' });
            // Initial buffer for the ping-pong. Sized to maxSats so we
            // never need to reallocate even after the catalog grows.
            this._workerBuf = new Float32Array(this._maxSats * 3);
        } catch (err) {
            console.debug('[SatTracker] worker unavailable, staying on main thread:', err.message);
            this._worker        = null;
            this._workerEnabled = false;
        }
    }

    _teardownWorker() {
        if (!this._worker) return;
        // Signal the Atomics tick loop to drop out of waitAsync, then
        // terminate. The notify is needed because the worker is
        // parked in waitAsync — without it, terminate still works
        // but waitAsync may keep its promise pending until GC.
        if (this._syncView) {
            try {
                Atomics.store(this._syncView, SYNC_RUNNING_SLOT, 0);
                Atomics.notify(this._syncView, SYNC_REQUEST_SLOT, 1);
            } catch (_) { /* sync view may already be detached */ }
        }
        try { this._worker.terminate(); } catch (_) {}
        this._worker             = null;
        this._workerEnabled      = false;
        this._workerReady        = false;
        this._workerInFlight     = false;
        this._atomicsTickEnabled = false;
        // _workerBuf is whatever's lying around; main-batch path will
        // allocate its own.
    }

    _onWorkerMessage(msg) {
        if (msg.type === 'ready') {
            if (msg.ok && msg.hasRegistry) {
                this._workerReady = true;
                // If the page is crossOriginIsolated and we got a SAB
                // allocated, hand it over now. The worker will switch
                // to shared-memory mode for ticks.
                if (this._posSab) {
                    this._worker.postMessage({
                        type:           'init-shared',
                        sab:            this._posSab,
                        syncSab:        this._syncSab ?? null,
                        ctrlSab:        this._ctrlSab ?? null,
                        atomicsTickRequested: !!this._atomicsTickEnabled,
                    });
                }
                // Ship every sat we already know about.
                this._workerSync();
            } else {
                console.debug('[SatTracker] worker WASM init failed:', msg.error || 'no registry');
                this._teardownWorker();
            }
            return;
        }
        if (msg.type === 'shared-ready') {
            if (msg.ok) {
                this._sabReady = true;
            } else {
                console.debug('[SatTracker] worker rejected SAB, falling back to transferable:', msg.error);
                this._posSab   = null;
                this._sabReady = false;
            }
            return;
        }
        if (msg.type === 'add-ack' || msg.type === 'clear-ack') return;
        if (msg.type === 'positions') {
            this._workerInFlight = false;
            this._workerLastFrame = msg.frameId;

            if (msg.mismatch) {
                // Slot count drifted — re-ship everything and skip
                // this frame's upload (positions would be NaN).
                this._workerSyncedTo = 0;
                this._worker.postMessage({ type: 'clear' });
                this._workerSync();
                return;
            }

            if (this._sabReady && msg.buffer == null) {
                // SAB path: positions are already in shared memory
                // (which the THREE position attribute is a view over).
                // Just refresh lat/lon and tell the GPU to re-upload.
                this._refreshFromSab(msg.slots, msg.frameId);
            } else {
                // Transferable path: wrap a view, copy in.
                const buf = new Float32Array(msg.buffer);
                this._workerBuf = buf;
                this._uploadPositionsFromBuffer(buf, msg.slots);
            }
            return;
        }
        if (msg.type === 'error') {
            console.warn('[SatTracker] worker error:', msg.error);
            return;
        }
    }

    /**
     * SAB-mode counterpart to _uploadPositionsFromBuffer. The position
     * attribute already shares memory with the worker, so there's
     * nothing to copy — we just walk the buffer for lat/lon recovery
     * and the highlight sprite, and flag the attribute as dirty so
     * the next render uploads it to the GPU.
     *
     * Atomics fence: read the worker's writing flag with
     * Atomics.load. Pairs with the worker's Atomics.store before its
     * SAB writes, so this load is the synchronization edge that
     * makes those writes visible. If the flag is set we skip the
     * needsUpdate (uploading mid-write would tear positions); the
     * next 'positions' message will retry. We still do lat/lon
     * recovery — the read is still a valid snapshot for tooltip /
     * cohort consumers, just not for GPU upload.
     */
    _refreshFromSab(slotCount, frameId) {
        if (!this._positions || !this._posSab) return;
        const writing = this._syncView
            ? Atomics.load(this._syncView, SYNC_WRITING_SLOT)
            : 0;
        const view = this._positions.array;
        const n = Math.min(slotCount, this._satellites.length);
        const kmToScene = this._earthR / RE_KM;
        let dirty = false;
        for (let i = 0; i < n; i++) {
            const off = i * 3;
            const x = view[off];
            const y = view[off + 1];
            const z = view[off + 2];
            if (x !== x) continue;   // NaN — keep last known position
            dirty = true;

            const sat = this._satellites[i];
            const sx = x / kmToScene;
            const sy = y / kmToScene;
            const sz = z / kmToScene;
            const r  = Math.sqrt(sx * sx + sy * sy + sz * sz);
            if (r > 1e-9) {
                const cy = sy / r;
                sat.lat = Math.asin(cy < -1 ? -1 : cy > 1 ? 1 : cy) * RAD;
                sat.lon = Math.atan2(-sz, sx) * RAD;
                sat.alt = r - RE_KM;
            }
            if (this._highlightNoradId != null
                && sat.tle.norad_id === this._highlightNoradId
                && this._highlightSprite) {
                this._highlightSprite.position.set(x, y, z);
            }
        }
        if (dirty && !writing && Number.isFinite(frameId)) {
            // Safe to upload — worker has finished writes for this
            // frame. Without the fence we'd unconditionally set
            // needsUpdate and risk a torn gl.bufferData on slow GPUs.
            this._positions.needsUpdate = true;
            this._lastUploadedFrame = frameId;
        } else if (dirty && !this._syncView) {
            // No sync SAB available (browser doesn't support it for
            // some reason) — fall back to the previous behaviour:
            // assume the postMessage barrier is enough.
            this._positions.needsUpdate = true;
        }
    }

    /**
     * Send any new sats since the last sync to the worker registry.
     * Chunked so a 30 k-row catalog landing in one shot doesn't park
     * the worker on TLE parsing for ~1 s while tick messages queue
     * behind it. The next tick fires `_workerSync` again, so the
     * remainder lands on subsequent frames — first frames render the
     * already-shipped slots and the new ones come online a frame or
     * two later.
     */
    _workerSync(maxThisCall = 5000) {
        if (!this._worker || !this._workerReady) return;
        const n = this._satellites.length;
        if (n <= this._workerSyncedTo) return;
        const upTo = Math.min(n, this._workerSyncedTo + maxThisCall);
        const tles = [];
        for (let i = this._workerSyncedTo; i < upTo; i++) {
            const t = this._satellites[i].tle;
            tles.push({
                line1: t.line1 || null,
                line2: t.line2 || null,
                norad_id: t.norad_id,
                epoch_jd: t.epoch_jd,
                bstar: t.bstar,
                inclination: t.inclination,
                raan: t.raan,
                eccentricity: t.eccentricity,
                arg_perigee: t.arg_perigee,
                mean_anomaly: t.mean_anomaly,
                mean_motion: t.mean_motion,
                rev_at_epoch: t.rev_at_epoch,
            });
        }
        this._workerSyncedTo = upTo;
        this._worker.postMessage({ type: 'add-sats', tles });
    }

    /**
     * Copy worker-returned positions into the THREE position attribute
     * and refresh lat/lon/alt for tooltip / cohort consumers. NaN
     * triplets indicate parse-failed or decayed slots; we leave them
     * at their last known position so the dot doesn't snap to origin.
     */
    _uploadPositionsFromBuffer(buf, slotCount) {
        if (!this._positions) return;
        const posArr = this._positions.array;
        const n = Math.min(slotCount, this._satellites.length);
        const kmToScene = this._earthR / RE_KM;

        let dirty = false;
        for (let i = 0; i < n; i++) {
            const off = i * 3;
            const x = buf[off];
            const y = buf[off + 1];
            const z = buf[off + 2];
            if (x !== x) continue;   // NaN — keep last known position

            posArr[off]     = x;
            posArr[off + 1] = y;
            posArr[off + 2] = z;
            dirty = true;

            const sat = this._satellites[i];
            const sx = x / kmToScene;
            const sy = y / kmToScene;
            const sz = z / kmToScene;
            const r  = Math.sqrt(sx * sx + sy * sy + sz * sz);
            if (r > 1e-9) {
                const cy = sy / r;
                sat.lat = Math.asin(cy < -1 ? -1 : cy > 1 ? 1 : cy) * RAD;
                sat.lon = Math.atan2(-sz, sx) * RAD;
                sat.alt = r - RE_KM;
            }

            if (this._highlightNoradId != null
                && sat.tle.norad_id === this._highlightNoradId
                && this._highlightSprite) {
                this._highlightSprite.position.set(x, y, z);
            }
        }
        if (dirty) this._positions.needsUpdate = true;
    }

    /**
     * Lazy-register any not-yet-batched sats with the WASM registry.
     * Idempotent — safe to call every frame; usually a no-op once
     * the load has settled. Slot indices line up with `_satellites[i]`,
     * so a JS→WASM mismatch (parse failure, decay) reserves a blank
     * slot to keep the alignment stable.
     */
    _syncRegistry() {
        if (!_wasmSgp4 || !_wasmSgp4.registry_propagate) return false;
        this._batchAvailable = true;

        const n = this._satellites.length;
        for (let i = this._batchSyncedTo; i < n; i++) {
            const sat = this._satellites[i];
            let registered = false;
            if (sat.tle.line1 && sat.tle.line2) {
                try {
                    _wasmSgp4.registry_add(sat.tle.line1, sat.tle.line2);
                    sat._batchOk = true;
                    registered = true;
                } catch (_) {
                    // Parse / init failed — fall through to blank slot.
                }
            } else if (hasOmmElements(sat.tle) && _wasmSgp4.registry_add_omm) {
                try {
                    _wasmSgp4.registry_add_omm(...ommElementArgs(sat.tle));
                    sat._batchOk = true;
                    registered = true;
                } catch (_) {
                    // Validation / init failed — fall through to blank slot.
                }
            }
            if (!registered) {
                _wasmSgp4.registry_reserve_blank();
                sat._batchOk = false;
            }
        }
        this._batchSyncedTo = n;
        return true;
    }

    /** Update satellite positions to current time. Call every frame. */
    tick(nowMs = Date.now()) {
        if (!this._positions || this._satellites.length === 0) return;

        const jd      = nowMs / 86400000 + 2440587.5;
        const gmstRad = geo.greenwichSiderealTimeFromJD(jd);
        const kmToScene = this._earthR / RE_KM;
        const posArr  = this._positions.array;

        // Worker path (preferred). The worker has its own WASM
        // registry; the main thread keeps it in sync via add-sats
        // messages. Two transports converge here:
        //
        //   - SAB    : tick is a tiny header message; the worker
        //              writes positions straight into the shared
        //              memory the THREE position attribute is a view
        //              over.
        //   - Xfer   : a Float32Array's buffer ping-pongs across
        //              postMessage transfer.
        //
        // Either way we hold at most one outstanding tick — if the
        // worker hasn't acked yet, this frame skips and positions
        // stay one frame stale (invisible at 60 fps).
        if (this._workerReady && this._workerEnabled) {
            this._workerSync();

            // Atomics-only protocol: zero postMessage on the hot tick
            // path. Main writes (jd, gmst, scale) into a shared
            // Float64 control SAB, bumps REQUEST in the sync SAB,
            // and Atomics.notify wakes the worker (which is parked
            // in waitAsync). Each frame we also poll PUBLISH for the
            // most recent worker-completed frame; if newer than the
            // last one we uploaded for, refresh lat/lon and flag the
            // GPU upload (gated on the WRITING flag).
            if (this._atomicsTickEnabled && this._sabReady) {
                const published = Atomics.load(this._syncView, SYNC_PUBLISH_SLOT);
                if (published !== this._lastUploadedFrame) {
                    this._refreshFromSab(this._workerSyncedTo, published);
                }

                // Write control + bump request. The 32-bit wrap on the
                // request id is fine: PUBLISH and REQUEST are
                // compared with !== so a wrap-around still triggers
                // an upload and wakes the worker.
                this._ctrlView[CTRL_JD_SLOT]    = jd;
                this._ctrlView[CTRL_GMST_SLOT]  = gmstRad;
                this._ctrlView[CTRL_SCALE_SLOT] = kmToScene;
                const id = (this._workerFrameId + 1) | 0;
                this._workerFrameId = id;
                Atomics.store(this._syncView, SYNC_REQUEST_SLOT, id);
                Atomics.notify(this._syncView, SYNC_REQUEST_SLOT, 1);
                return;
            }

            if (this._workerInFlight) return;

            // postMessage protocol — the previous fast path. Defers
            // the post to a microtask so the worker's next SAB write
            // begins only after this frame's renderer.render() call
            // has completed gl.bufferData. The Atomics fence in
            // _refreshFromSab is the safety net.
            if (this._sabReady) {
                this._workerInFlight = true;
                const frameId        = ++this._workerFrameId;
                queueMicrotask(() => {
                    this._worker?.postMessage({
                        type:           'tick',
                        jd, gmst:        gmstRad,
                        scale:           kmToScene,
                        frameId,
                        expectedSlots:   this._workerSyncedTo,
                    });
                });
                return;
            }
            if (this._workerBuf) {
                const buf = this._workerBuf;
                this._workerBuf       = null;
                this._workerInFlight  = true;
                const frameId         = ++this._workerFrameId;
                queueMicrotask(() => {
                    this._worker?.postMessage(
                        {
                            type:           'tick',
                            jd, gmst:        gmstRad,
                            scale:           kmToScene,
                            buffer:          buf.buffer,
                            frameId,
                            expectedSlots:   this._workerSyncedTo,
                        },
                        [buf.buffer],
                    );
                });
            }
            return;
        }

        const useBatch = this._syncRegistry();

        if (useBatch) {
            // One WASM call propagates every sat AND folds in the
            // TEME → scene-frame transform (matches geo.eciToEcef +
            // the Y=north scene flip). Returns NaN per slot for
            // un-batched / decayed sats — those drop to the JS
            // fallback below. Note we re-receive the buffer each
            // frame because wasm-bindgen passes &mut [f32] as
            // input-only; a returned Vec<f32> is the path that
            // actually carries data back to JS.
            const out = _wasmSgp4.registry_propagate(jd, gmstRad, kmToScene);
            this._batchOut = out;

            const n = this._satellites.length;
            for (let i = 0; i < n; i++) {
                const off = i * 3;
                const sat = this._satellites[i];

                let x = out[off];
                let y = out[off + 1];
                let z = out[off + 2];

                if (sat._batchOk === false || x !== x /* NaN */) {
                    // Per-sat fallback: parse-failed slots and decayed
                    // sats land here. propagate() will pick its own
                    // best path (WASM single-call → JS Kepler).
                    const tsince = (jd - sat.epochJd) * MIN_PER_DAY;
                    const teme = propagate(sat.tle, tsince);
                    _temeScratch.set(teme.x, teme.y, teme.z);
                    geo.eciToEcef(_temeScratch, gmstRad, _sceneScratch);
                    x = _sceneScratch.x * kmToScene;
                    y = _sceneScratch.y * kmToScene;
                    z = _sceneScratch.z * kmToScene;
                }

                posArr[off]     = x;
                posArr[off + 1] = y;
                posArr[off + 2] = z;

                // Lat/lon/alt — keep the legacy fields in sync. Use
                // the (already-computed) scene-frame coords directly
                // instead of round-tripping through positionToLatLon
                // so we save a Vector3 + a few extra trig calls per
                // sat. positionToLatLon's mapping is:
                //   lat = asin(y/r); lon = atan2(-z, x); r in km.
                const sx = x / kmToScene;
                const sy = y / kmToScene;
                const sz = z / kmToScene;
                const r  = Math.sqrt(sx * sx + sy * sy + sz * sz);
                if (r > 1e-9) {
                    const cy = sy / r;
                    sat.lat = Math.asin(cy < -1 ? -1 : cy > 1 ? 1 : cy) * RAD;
                    sat.lon = Math.atan2(-sz, sx) * RAD;
                    sat.alt = r - RE_KM;
                }

                if (this._highlightNoradId != null
                    && sat.tle.norad_id === this._highlightNoradId
                    && this._highlightSprite) {
                    this._highlightSprite.position.set(x, y, z);
                }
            }
        } else {
            // No registry API (older WASM build, or WASM not loaded
            // yet). Original per-sat path; same numerics.
            for (let i = 0; i < this._satellites.length; i++) {
                const sat    = this._satellites[i];
                const tsince = (jd - sat.epochJd) * MIN_PER_DAY;

                const teme = propagate(sat.tle, tsince);
                _temeScratch.set(teme.x, teme.y, teme.z);

                geo.eciToEcef(_temeScratch, gmstRad, _sceneScratch);

                const x = _sceneScratch.x * kmToScene;
                const y = _sceneScratch.y * kmToScene;
                const z = _sceneScratch.z * kmToScene;
                posArr[i * 3]     = x;
                posArr[i * 3 + 1] = y;
                posArr[i * 3 + 2] = z;

                const ll = geo.positionToLatLon(_sceneScratch);
                sat.lat = ll.lat * RAD;
                sat.lon = ll.lon * RAD;
                sat.alt = ll.radiusUnits - RE_KM;

                if (this._highlightNoradId != null
                    && sat.tle.norad_id === this._highlightNoradId
                    && this._highlightSprite) {
                    this._highlightSprite.position.set(x, y, z);
                }
            }
        }

        this._positions.needsUpdate = true;
    }

    /** Get all satellite positions + info. */
    getSatellites() {
        return this._satellites.map(s => ({
            name: s.tle.name,
            norad_id: s.tle.norad_id,
            group: s.group,
            lat: s.lat,
            lon: s.lon,
            alt: s.alt,
            period_min: s.tle.period_min,
            inclination: s.tle.inclination,
            apogee_km: s.tle.apogee_km,
            perigee_km: s.tle.perigee_km,
        }));
    }

    /** Get a single satellite by NORAD ID. */
    getSatellite(noradId) {
        const s = this._satellites.find(s => s.tle.norad_id === noradId);
        if (!s) return null;
        return {
            name: s.tle.name, norad_id: s.tle.norad_id,
            group: s.group,
            lat: s.lat, lon: s.lon, alt: s.alt,
            period_min: s.tle.period_min, inclination: s.tle.inclination,
            tle: s.tle,
        };
    }

    /** Set visibility. */
    setVisible(v) { this._group.visible = v; }

    // ── Starlink shell visualization ────────────────────────────────────────

    /**
     * Build translucent orbital shell rings for Starlink's operating altitudes.
     * Each shell is a tilted ring at the constellation's inclination.
     */
    buildStarlinkShells(visible = true) {
        // Clear previous shells
        while (this._shellGroup.children.length) {
            const c = this._shellGroup.children[0];
            c.geometry?.dispose();
            c.material?.dispose();
            this._shellGroup.remove(c);
        }

        // Starlink orbital shells (altitude km, inclination deg, label)
        const shells = [
            { alt: 550, inc: 53.0,  label: 'Gen1 Shell 1',  color: 0x4466ff, count: '~1584' },
            { alt: 540, inc: 53.2,  label: 'Gen1 Shell 2',  color: 0x5577ff, count: '~1584' },
            { alt: 570, inc: 70.0,  label: 'Gen1 Polar',    color: 0x6688ff, count: '~720' },
            { alt: 560, inc: 97.6,  label: 'Gen1 SSO',      color: 0x88aaff, count: '~348' },
            { alt: 525, inc: 53.0,  label: 'Gen2 V-band',   color: 0x3355dd, count: '~7178' },
            { alt: 530, inc: 43.0,  label: 'Gen2 Mid-Inc',  color: 0x4466dd, count: '~2000' },
        ];

        for (const sh of shells) {
            const r = this._earthR * (1 + sh.alt / RE_KM);
            const ring = new THREE.Mesh(
                new THREE.RingGeometry(r - 0.003, r + 0.003, 128),
                new THREE.MeshBasicMaterial({
                    color: sh.color, side: THREE.DoubleSide,
                    transparent: true, opacity: 0.25, depthWrite: false,
                    blending: THREE.AdditiveBlending,
                })
            );
            ring.rotation.x = (90 - sh.inc) * DEG2RAD;
            ring.userData = { ...sh };
            this._shellGroup.add(ring);
        }

        this._shellGroup.visible = visible;
    }

    /** Toggle shell visibility. */
    setShellsVisible(v) { this._shellGroup.visible = v; }

    /** Get shell group for external access. */
    getShellGroup() { return this._shellGroup; }

    /**
     * Compute ground track for a satellite (one full orbit).
     * Returns array of { lat, lon, alt } at N equally-spaced time steps.
     * @param {number} noradId  NORAD ID of the satellite
     * @param {number} [steps=360]  Number of points along the orbit
     * @returns {Array<{lat:number, lon:number, alt:number}>|null}
     */
    computeGroundTrack(noradId, steps = 360) {
        const sat = this._satellites.find(s => s.tle.norad_id === noradId);
        if (!sat) return null;

        const periodMin = sat.tle.period_min || 90;
        const jd = Date.now() / 86400000 + 2440587.5;
        const tsinceBase = (jd - sat.epochJd) * MIN_PER_DAY;
        const track = [];

        for (let i = 0; i <= steps; i++) {
            const tsince  = tsinceBase + (i / steps) * periodMin;
            const teme    = propagate(sat.tle, tsince);
            const jdStep  = jd + (i / steps) * periodMin / MIN_PER_DAY;
            const gmstRad = geo.greenwichSiderealTimeFromJD(jdStep);

            _temeScratch.set(teme.x, teme.y, teme.z);
            geo.eciToEcef(_temeScratch, gmstRad, _sceneScratch);

            const ll = geo.positionToLatLon(_sceneScratch);
            track.push({
                lat: ll.lat * RAD,
                lon: ll.lon * RAD,
                alt: ll.radiusUnits - RE_KM,
            });
        }
        return track;
    }

    /**
     * Build a Three.js line for the ground track projected onto the globe surface.
     * @param {number} noradId
     * @param {number} [heightOffset=0.002] Extra height above the globe surface
     * @returns {THREE.Line|null}
     */
    buildGroundTrackLine(noradId, heightOffset = 0.002) {
        const track = this.computeGroundTrack(noradId, 360);
        if (!track) return null;

        const points = [];
        let prevLon = null;
        for (const pt of track) {
            // Detect antimeridian crossing — break the line to avoid wraparound artifact
            if (prevLon !== null && Math.abs(pt.lon - prevLon) > 180) {
                // Insert NaN to break the line (Three.js Line will gap here)
                points.push(new THREE.Vector3(NaN, NaN, NaN));
            }
            prevLon = pt.lon;

            const r = this._earthR + heightOffset;  // on the surface
            points.push(geo.latLonToPosition(pt.lat * DEG, pt.lon * DEG, r));
        }

        const bufGeo = new THREE.BufferGeometry().setFromPoints(points);
        const mat = new THREE.LineBasicMaterial({
            color: 0xffcc00, transparent: true, opacity: 0.5, depthWrite: false,
        });
        return new THREE.Line(bufGeo, mat);
    }

    /**
     * Build a Three.js line for the orbital path (above the surface, at altitude).
     * @param {number} noradId
     * @returns {THREE.Line|null}
     */
    buildOrbitLine(noradId) {
        const track = this.computeGroundTrack(noradId, 360);
        if (!track) return null;

        const points = [];
        for (const pt of track) {
            const r = this._earthR * (1 + pt.alt / RE_KM);
            points.push(geo.latLonToPosition(pt.lat * DEG, pt.lon * DEG, r));
        }

        const bufGeo = new THREE.BufferGeometry().setFromPoints(points);
        const mat = new THREE.LineBasicMaterial({
            color: 0x00ffcc, transparent: true, opacity: 0.35, depthWrite: false,
        });
        return new THREE.Line(bufGeo, mat);
    }

    /**
     * Conjunction screening: find close approaches between a target satellite
     * and all loaded catalog objects over the next N hours.
     *
     * Anchors at `opts.epochMs` (defaults to wall-clock now) so callers
     * can screen relative to a scrubbed sim time. After the coarse
     * SGP4 sweep, each candidate's closest sample is refined with a
     * parabolic fit through dist²(i-1, i, i+1) — sub-step TCA + miss.
     * When `opts.withDv` is set, finite-differences relative velocity
     * at the refined TCA and reports |Δv| (km/s) plus the unit miss
     * vector (useful for a real B-plane).
     *
     * @param {number} targetNoradId    NORAD ID of the target satellite
     * @param {number} [hoursAhead=72]  Look-ahead window
     * @param {number} [stepMin=10]     Time step in minutes
     * @param {number} [thresholdKm=25] Distance threshold
     * @param {string|string[]|null} [groupFilter=null]
     *        Restrict secondaries to one group, an array of groups, or
     *        null (every loaded sat except the primary). Saves
     *        thousands of propagate() calls per run when the caller
     *        only cares about one constellation kind.
     * @param {object}  [opts]
     * @param {number}  [opts.epochMs]   Anchor in ms since epoch.
     * @param {boolean} [opts.refine=true]   Parabolic refine.
     * @param {boolean} [opts.withDv=true]   Include |Δv| + miss unit.
     * @returns {Array<{ name, norad_id, group, dist_km, tca_jd,
     *                   tca_ms, hours_ahead, dv_kms, miss_unit }>}
     */
    async screenConjunctions(targetNoradId, hoursAhead = 72, stepMin = 10, thresholdKm = 25, groupFilter = null, opts = {}) {
        const target = this._satellites.find(s => s.tle.norad_id === targetNoradId);
        if (!target) return [];

        const epochMs   = Number.isFinite(opts.epochMs) ? opts.epochMs : Date.now();
        const refine    = opts.refine    !== false;
        const withDv    = opts.withDv    !== false;
        const withSpark = opts.withSpark !== false;
        const SPARK_HALF_WINDOW = 5;   // ±5 samples around TCA coarse

        const matchesGroup = (g) => {
            if (groupFilter == null) return true;
            if (Array.isArray(groupFilter)) return groupFilter.includes(g);
            return g === groupFilter;
        };

        const nSteps = Math.ceil(hoursAhead * 60 / stepMin);
        const jd = epochMs / 86400000 + 2440587.5;
        const tsinceBase = (jd - target.epochJd) * MIN_PER_DAY;

        // Generate time array
        const times = new Float64Array(nSteps);
        for (let i = 0; i < nSteps; i++) {
            times[i] = tsinceBase + i * stepMin;
        }

        // Propagate target at all time steps
        let targetPositions;  // Array of {x, y, z} per step

        if (_wasmSgp4) {
            try {
                const result = propagateBatch(target.tle, times);
                if (!result) throw new Error('batch propagator unavailable');
                targetPositions = [];
                for (let i = 0; i < nSteps; i++) {
                    const off = i * 6;
                    targetPositions.push({ x: result[off], y: result[off + 1], z: result[off + 2] });
                }
                console.debug(`[Conjunction] Target propagated via WASM: ${nSteps} steps`);
            } catch (_) {
                targetPositions = null;  // fall through to JS
            }
        }

        if (!targetPositions) {
            // JS fallback — propagate one step at a time. Array.from, NOT
            // times.map: `times` is a Float64Array, and a typed array's map
            // returns a Float64Array, coercing every {x,y,z} to NaN — every
            // sample was then skipped and the screen returned [] whenever the
            // WASM was not loaded (found 2026-09-24; tests/conjunction-monitor.spec.js).
            targetPositions = Array.from(times, t => propagate(target.tle, t));
            console.debug(`[Conjunction] Target propagated via JS fallback: ${nSteps} steps`);
        }

        // Pre-filter widens with the horizon: a debris piece in an
        // eccentric orbit can drift through the asset's altitude shell
        // over a 14-day window, so the bound has to grow with time.
        // ~50 km/d worst-case altitude drift in high-drag LEO; cap so
        // the filter still does work at long horizons.
        const targetAltAvg = (target.tle.perigee_km + target.tle.apogee_km) / 2;
        const altMargin    = Math.min(50 * (hoursAhead / 24) + 200, 1500);

        // Screen all catalog objects
        const conjunctions = [];

        for (const cat of this._satellites) {
            if (cat.tle.norad_id === targetNoradId) continue;
            if (!matchesGroup(cat.group)) continue;

            // Pre-filter on apogee/perigee overlap with the target's
            // shell ± altMargin. Tighter than a "mean-altitude within
            // 200 km" check while still horizon-aware.
            const catPerigee = cat.tle.perigee_km;
            const catApogee  = cat.tle.apogee_km;
            if (catApogee  + altMargin < targetAltAvg - 200) continue;
            if (catPerigee - altMargin > targetAltAvg + 200) continue;

            // Propagate catalog object at each step.
            const catTsinceBase = (jd - cat.epochJd) * MIN_PER_DAY;

            // Track the closest sample over the *full* window. The
            // previous version broke on the first sample under the
            // threshold, which is the wrong number — closest-approach
            // is deeper than the first dip into the threshold.
            let bestI  = -1;
            let bestD2 = Infinity;
            const catPos = new Array(nSteps);
            // Sample-distance buffer (km) — kept so we can crop a
            // window around bestI for the sparkline without
            // re-propagating.
            const dists = new Float32Array(nSteps);

            for (let i = 0; i < nSteps; i++) {
                const tgt = targetPositions[i];
                if (!isFinite(tgt.x)) { dists[i] = NaN; continue; }

                const cp = propagate(cat.tle, catTsinceBase + i * stepMin);
                catPos[i] = cp;
                if (!isFinite(cp.x)) { dists[i] = NaN; continue; }

                const dx = tgt.x - cp.x;
                const dy = tgt.y - cp.y;
                const dz = tgt.z - cp.z;
                const d2 = dx * dx + dy * dy + dz * dz;
                dists[i] = Math.sqrt(d2);

                if (d2 < bestD2) { bestD2 = d2; bestI = i; }
            }

            if (bestI < 0) continue;

            let missKm    = Math.sqrt(bestD2);
            let tcaOffMin = bestI * stepMin;

            // Parabolic refine through dist²(i-1, i, i+1). Sub-step
            // TCA + miss without extra propagate calls — we already
            // have the neighbours from the sweep. Skip at the window
            // boundary; there's no reliable "outside" sample.
            if (refine && bestI > 0 && bestI < nSteps - 1) {
                const tgtL = targetPositions[bestI - 1];
                const tgtR = targetPositions[bestI + 1];
                const cpL  = catPos[bestI - 1];
                const cpR  = catPos[bestI + 1];
                if (isFinite(tgtL?.x) && isFinite(tgtR?.x) && isFinite(cpL?.x) && isFinite(cpR?.x)) {
                    const dL = (tgtL.x - cpL.x) ** 2 + (tgtL.y - cpL.y) ** 2 + (tgtL.z - cpL.z) ** 2;
                    const dC = bestD2;
                    const dR = (tgtR.x - cpR.x) ** 2 + (tgtR.y - cpR.y) ** 2 + (tgtR.z - cpR.z) ** 2;
                    const denom = dL - 2 * dC + dR;
                    if (Math.abs(denom) > 1e-9) {
                        const delta = 0.5 * (dL - dR) / denom;
                        if (delta > -1 && delta < 1) {
                            tcaOffMin = (bestI + delta) * stepMin;
                            const d2Min = dC - 0.25 * (dL - dR) * delta;
                            if (d2Min > 0 && isFinite(d2Min)) missKm = Math.sqrt(d2Min);
                        }
                    }
                }
            }

            if (missKm > thresholdKm) continue;

            // |Δv| at TCA via central-difference (10 s either side) on
            // both objects, then the magnitude of the relative-velocity
            // vector. Cheap (4 propagates) and gives the encounter
            // energy proxy callers want.
            let dvKms    = null;
            let missUnit = null;
            let vRel     = null;
            let missVec  = null;
            if (withDv) {
                const tcaT  = tsinceBase + tcaOffMin;
                const halfH = 10 / 60;
                const pA = propagate(target.tle, tcaT - halfH);
                const pB = propagate(target.tle, tcaT + halfH);
                const sA = propagate(cat.tle,    catTsinceBase + tcaOffMin - halfH);
                const sB = propagate(cat.tle,    catTsinceBase + tcaOffMin + halfH);
                if (isFinite(pA.x) && isFinite(pB.x) && isFinite(sA.x) && isFinite(sB.x)) {
                    const dt = 20; // seconds of central-diff span
                    const vRelX = ((pB.x - pA.x) - (sB.x - sA.x)) / dt;
                    const vRelY = ((pB.y - pA.y) - (sB.y - sA.y)) / dt;
                    const vRelZ = ((pB.z - pA.z) - (sB.z - sA.z)) / dt;
                    dvKms = Math.sqrt(vRelX * vRelX + vRelY * vRelY + vRelZ * vRelZ);
                    vRel  = { x: vRelX, y: vRelY, z: vRelZ };

                    const tcaP = propagate(target.tle, tcaT);
                    const tcaS = propagate(cat.tle,    catTsinceBase + tcaOffMin);
                    if (isFinite(tcaP.x) && isFinite(tcaS.x)) {
                        const mx = tcaP.x - tcaS.x;
                        const my = tcaP.y - tcaS.y;
                        const mz = tcaP.z - tcaS.z;
                        const m  = Math.sqrt(mx * mx + my * my + mz * mz) || 1;
                        missVec  = { x: mx, y: my, z: mz };
                        missUnit = { x: mx / m, y: my / m, z: mz / m };
                    }
                }
            }

            // Sparkline window: ±SPARK_HALF_WINDOW samples around
            // bestI, clipped to [0, nSteps-1]. NaNs survive so the
            // renderer's time axis stays consistent.
            let spark = null;
            if (withSpark) {
                const lo  = Math.max(0, bestI - SPARK_HALF_WINDOW);
                const hi  = Math.min(nSteps - 1, bestI + SPARK_HALF_WINDOW);
                const km  = new Array(hi - lo + 1);
                for (let i = lo; i <= hi; i++) km[i - lo] = dists[i];
                spark = {
                    km,
                    step_min:     stepMin,
                    center_index: bestI - lo,
                };
            }

            const tcaMs = epochMs + tcaOffMin * 60 * 1000;

            conjunctions.push({
                name:        cat.tle.name,
                norad_id:    cat.tle.norad_id,
                group:       cat.group,
                dist_km:     Math.round(missKm * 100) / 100,
                hours_ahead: Math.round(tcaOffMin / 60 * 100) / 100,
                tca_jd:      jd + tcaOffMin / MIN_PER_DAY,
                tca_ms:      tcaMs,
                dv_kms:      dvKms != null ? Math.round(dvKms * 1000) / 1000 : null,
                v_rel:       vRel,
                miss_unit:   missUnit,
                miss_vec:    missVec,
                spark,
            });
        }

        conjunctions.sort((a, b) => a.dist_km - b.dist_km);
        return conjunctions;
    }

}

// ── Helpers (module-level) ──────────────────────────────────────────────────

const _hiddenColor = new THREE.Color(0x000000);

/** Convert a TLE's (epoch_yr, epoch_day) fractional-year field into a JD.
 *  Exported for modules that want to propagate independently of the
 *  tracker but using the same epoch arithmetic. */
export function tleEpochToJd(tle) {
    if (Number.isFinite(Number(tle?.epoch_jd))) return Number(tle.epoch_jd);
    if (Number.isFinite(Number(tle?.epoch_ms))) return Number(tle.epoch_ms) / 86400000 + 2440587.5;
    const epochMs = Date.parse(tle?.epoch);
    if (Number.isFinite(epochMs)) return epochMs / 86400000 + 2440587.5;
    const epochYr = tle.epoch_yr ?? 2026;
    const yr = Math.floor(epochYr);
    const dayFrac = (epochYr - yr) * (yr % 4 === 0 ? 366 : 365);
    const jdJan1 = 367 * yr - Math.floor(7 * (yr + Math.floor(10 / 12)) / 4) + Math.floor(275 / 9) + 1721013.5;
    return jdJan1 + dayFrac;
}
