/**
 * neo-rocks.js — 3D bodies for the near-Earth object layer
 * ═══════════════════════════════════════════════════════════════════════════
 * Procedural, seeded asteroid / comet-nucleus meshes that stand in for point
 * sprites whenever an object is resolved on screen. (The instanced meteoroid
 * "boulders" that used to live here were removed 2026-10, NEO_LAYER_PLAN.md
 * §5 P3: shower grains are millimetre dust and are drawn as streaks.)
 *
 * ── Shapes ────────────────────────────────────────────────────────────────
 * A rock is an icosphere displaced by (a) a low-frequency lumpy field — a sum
 * of eight seeded cosine bumps, which is smooth and cheap and has no lattice
 * artefacts — (b) a handful of bowl craters with a raised rim, and (c) a
 * family profile:
 *     potato     the default; mild triaxial squash
 *     elongated  Eros / Apophis-like, ~2:1
 *     contact    two lobes and a neck — Itokawa, Toutatis, Arrokoth
 *     top        the "spinning top" with an equatorial ridge — Bennu, Ryugu,
 *                Didymos (a rubble pile spun up by YORP)
 *     spheroid   nearly round
 * Known bodies get their real family via NOTABLE_SHAPES and their real spin
 * period via ROTATION_PERIOD_H; everything else is seeded from its
 * designation so a given object always looks the same.
 *
 * ── Lighting ──────────────────────────────────────────────────────────────
 * The orrery's Sun is a physically-decaying PointLight that leaves anything
 * at 1 AU dim, so the rocks light THEMSELVES from the Sun direction — taken
 * from `u_sunPos`, which DEFAULTS to the world origin because that is where
 * the orrery draws the Sun, and which neo-watch.html sets instead because its
 * stage is EARTH-centred. Same lighting rule, different stage; the default
 * reproduces the orrery's original `normalize(-vW)` exactly. The scattering
 * law, the opposition surge, the display compression and the eclipse test all
 * come from js/airless-body.js — ONE copy shared with the far-field impostor
 * and with every moon on the page, so a LOD handoff changes the geometry and
 * nothing else. Level is the object's own albedo times the illumination
 * reaching it; the H–G phase function is NOT applied on top of the BRDF (it is
 * disc-integrated — see that header). Plus a rim so a dark limb still reads
 * against black, and a per-vertex regolith speckle. The shader still handles
 * `instanceMatrix`, so it can drive an InstancedMesh.
 *
 * ── Scale ─────────────────────────────────────────────────────────────────
 * `drawnRockRadius(diamKm)` is a LOG map from real diameter to scene units:
 * a 30 m rock and Eros differ by 500× in size, and on a log-scale orrery
 * where Earth is 0.12 units that has to compress. Disclosed in the panel
 * note. Sizes are never used for any physics.
 *
 * SIZE PLAN PHASE 1 (2026-10-11, NEO_LAYER_PLAN.md §5): the map used to be
 * 0.010 + 0.011·log10(1 + 10d) — a 0.010 FLOOR that drew a 30 m rock a
 * third the size of the drawn Moon (0.032) and a 10 km one as big as it,
 * i.e. 10²–10⁴× inflated against the drawn Earth IN WORLD UNITS, which
 * perspective then magnified into moon-sized balls whenever the camera came
 * near Earth. The floor is gone and the gain is set so a 10 km body is
 * 0.1× the drawn Moon (ROCK_SIZE.gain · log10(101) ≈ 0.0032). Still
 * inflated (≈34× at 10 km, ≈500× at 100 m — disclosed), but no longer
 * comparable to a planet or moon.
 */

import * as THREE from 'three';
import { TONE_DECODE_GLSL } from './tone-decode.js';
import { AIRLESS_GLSL, AIRLESS_DISPLAY, OPPOSITION } from './airless-body.js';
import { UMBRAL_TRANSMISSION, UMBRAL_TINT, SUN_RADIUS_KM } from './eclipse-geometry.js';

export const ROTATION_PERIOD_H = Object.freeze({
    '99942': 30.6, '101955': 4.30, '162173': 7.63, '65803': 2.26, '2024 YR4': 0.33, '3200': 3.60,
    '433': 5.27, '25143': 12.1, '29075': 2.12, '4179': 176, '1566': 2.27, '2062': 40.8, '1862': 3.07,
    '1221': 7.3, '163693': 3.4, '367943': 9.5, '1P': 52.8, '109P': 69, '2P': 11.1, '55P': 15, '21P': 9.5,
});
export const NOTABLE_SHAPES = Object.freeze({
    '101955': 'top', '162173': 'top', '65803': 'top',
    '99942': 'elongated', '433': 'elongated', '2024 YR4': 'elongated', '1566': 'spheroid',
    '25143': 'contact', '4179': 'contact',
});
export const SHAPES = Object.freeze(['potato', 'elongated', 'contact', 'top', 'spheroid']);

/** FNV-1a → 32-bit. */
export function hash32(str) {
    let h = 2166136261;
    for (let i = 0; i < str.length; i++) { h ^= str.charCodeAt(i); h = Math.imul(h, 16777619); }
    return h >>> 0;
}
/** mulberry32 PRNG. */
export function rng(seed) {
    let a = seed >>> 0;
    return () => {
        a = (a + 0x6D2B79F5) >>> 0;
        let t = a;
        t = Math.imul(t ^ (t >>> 15), t | 1);
        t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
        return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
}

/** Real diameter (km) → drawn radius (scene units), log-compressed. */
export const ROCK_SIZE = Object.freeze({
    gain: 0.0016,      // scene units per decade of (1 + 10·D/km)
    floor: 0.00005,    // a defined, never-zero radius for D → 0
});
export function drawnRockRadius(diamKm) {
    const d = Number.isFinite(diamKm) && diamKm > 0 ? diamKm : 0.1;
    return Math.max(ROCK_SIZE.floor, ROCK_SIZE.gain * Math.log10(1 + 10 * d));
}

/** Shape family for an object: the known one, else seeded. */
export function shapeFor(des, seed) {
    if (des != null && NOTABLE_SHAPES[des]) return NOTABLE_SHAPES[des];
    const r = rng(seed ^ 0x9e3779b9)();
    if (r < 0.12) return 'contact';
    if (r < 0.32) return 'elongated';
    if (r < 0.42) return 'top';
    if (r < 0.52) return 'spheroid';
    return 'potato';
}

/** Merge duplicated vertices of a non-indexed geometry so normals come out smooth. */
function mergeVertices(geo, precision = 1e-4) {
    const pos = geo.attributes.position;
    const key = new Map();
    const out = [];
    const index = new Uint32Array(pos.count);
    const q = 1 / precision;
    for (let i = 0; i < pos.count; i++) {
        const x = pos.getX(i), y = pos.getY(i), z = pos.getZ(i);
        const k = `${Math.round(x * q)}|${Math.round(y * q)}|${Math.round(z * q)}`;
        let id = key.get(k);
        if (id === undefined) { id = out.length / 3; key.set(k, id); out.push(x, y, z); }
        index[i] = id;
    }
    const merged = new THREE.BufferGeometry();
    merged.setAttribute('position', new THREE.Float32BufferAttribute(out, 3));
    merged.setIndex(new THREE.BufferAttribute(index, 1));
    return merged;
}

/**
 * Build a rock geometry of unit nominal radius.
 * @param {{ seed:number, shape?:string, detail?:number }} opts  detail is three's LINEAR subdivision: 7 ⇒ 1280 faces / 642 vertices
 */
export function rockGeometry({ seed, shape = 'potato', detail = 7 }) {
    const rand = rng(seed);
    const geo = mergeVertices(new THREE.IcosahedronGeometry(1, detail));
    const pos = geo.attributes.position;
    const n = pos.count;

    // (a) lumpy field: eight seeded cosine bumps.
    const bumps = [];
    for (let i = 0; i < 8; i++) {
        const th = rand() * Math.PI * 2, ph = Math.acos(rand() * 2 - 1);
        bumps.push({ kx: Math.sin(ph) * Math.cos(th), ky: Math.sin(ph) * Math.sin(th), kz: Math.cos(ph),
            f: 1.2 + rand() * 2.8, phase: rand() * Math.PI * 2, amp: (0.05 + rand() * 0.07) / (1 + i * 0.25) });
    }
    // (b) craters: bowl with a rim.
    const craters = [];
    const nCr = 4 + Math.floor(rand() * 7);
    for (let i = 0; i < nCr; i++) {
        const th = rand() * Math.PI * 2, ph = Math.acos(rand() * 2 - 1);
        craters.push({ x: Math.sin(ph) * Math.cos(th), y: Math.sin(ph) * Math.sin(th), z: Math.cos(ph),
            rho: 0.12 + rand() * 0.35, depth: 0.03 + rand() * 0.07 });
    }
    const squash = { x: 1 + (rand() - 0.5) * 0.25, y: 1 + (rand() - 0.5) * 0.25, z: 1 + (rand() - 0.5) * 0.25 };
    const speck = new Float32Array(n);
    const sRand = rng(seed ^ 0x51ed270b);

    for (let i = 0; i < n; i++) {
        let x = pos.getX(i), y = pos.getY(i), z = pos.getZ(i);
        let r = 1;
        for (const b of bumps) r += b.amp * Math.cos(b.f * (b.kx * x + b.ky * y + b.kz * z) + b.phase);
        for (const c of craters) {
            const ang = Math.acos(Math.max(-1, Math.min(1, x * c.x + y * c.y + z * c.z)));
            if (ang < c.rho) {
                const u = ang / c.rho;                       // 0 centre → 1 rim
                r -= c.depth * (1 - u * u) * (1 - u * u);    // bowl
                r += c.depth * 0.45 * Math.exp(-Math.pow((u - 0.92) / 0.09, 2));   // rim
            }
        }
        // (c) family profile.
        let sx = squash.x, sy = squash.y, sz = squash.z;
        if (shape === 'elongated') { sx *= 1.95; sy *= 0.82; sz *= 0.78; }
        else if (shape === 'spheroid') { sx = sy = sz = 1; r = 1 + (r - 1) * 0.4; }
        else if (shape === 'top') {
            // Equatorial ridge + diamond profile (Bennu / Ryugu).
            r += 0.16 * Math.exp(-Math.pow(y / 0.14, 2)) - 0.10 * Math.abs(y) * Math.abs(y);
            sy *= 0.92;
        } else if (shape === 'contact') {
            r += 0.32 * Math.exp(-Math.pow((x - 0.55) / 0.42, 2)) + 0.26 * Math.exp(-Math.pow((x + 0.55) / 0.40, 2))
               - 0.22 * Math.exp(-Math.pow(x / 0.22, 2));
            sx *= 1.55; sy *= 0.78; sz *= 0.78;
        }
        pos.setXYZ(i, x * r * sx, y * r * sy, z * r * sz);
        speck[i] = sRand();
    }
    geo.setAttribute('aSpeck', new THREE.BufferAttribute(speck, 1));
    geo.computeVertexNormals();
    geo.computeBoundingSphere();
    // Normalise so the bounding radius is 1 — sizing is then exact in drawnRockRadius units.
    const R = geo.boundingSphere.radius || 1;
    for (let i = 0; i < n; i++) pos.setXYZ(i, pos.getX(i) / R, pos.getY(i) / R, pos.getZ(i) / R);
    pos.needsUpdate = true;
    geo.computeBoundingSphere();
    return geo;
}

const ROCK_VS = /* glsl */`
    attribute float aSpeck;
    varying vec3  vN;
    varying vec3  vW;
    varying float vSpeck;
    void main() {
        mat4 M = modelMatrix;
        #ifdef USE_INSTANCING
            M = modelMatrix * instanceMatrix;
        #endif
        vec4 wp = M * vec4(position, 1.0);
        vW = wp.xyz;
        vN = normalize(mat3(M) * normal);
        vSpeck = aSpeck;
        gl_Position = projectionMatrix * viewMatrix * wp;
    }
`;
const ROCK_FS = /* glsl */`${TONE_DECODE_GLSL}${AIRLESS_GLSL}
    uniform vec3  u_base;
    uniform float u_glow;        // comet nucleus: faint self-lit coma haze
    // Where the Sun is, in world space. The orrery draws the Sun AT the origin,
    // so the default (0,0,0) reproduces the original normalize(-vW) exactly.
    // neo-watch.html draws EARTH at the origin and passes the Sun's direction
    // scaled far out instead: same lighting rule, different stage.
    // NOTE no backticks in this comment. It lives inside a template literal,
    // and one would end the shader mid-string (CLAUDE.md, solar-system scars).
    uniform vec3  u_sunPos;
    uniform float u_albedo;      // geometric albedo — measured, or the class mean
    uniform float u_illum;       // (1 AU / r)²: the sunlight reaching this body
    uniform float u_gain;        // display normalisation, shared with every airless body
    uniform float u_stretch;     // DISCLOSED display compression
    uniform float u_B0;
    uniform float u_hOpp;
    uniform float u_shine;       // Earth-reflected light, as a fraction of direct
    uniform vec3  u_shineDir;    // unit, toward Earth, SCENE axes
    uniform vec3  u_sunFromBodyKm;   // REAL km, SCENE axes — the eclipse test
    uniform vec3  u_occFromBodyKm;
    uniform float u_occRadiusKm;
    uniform float u_sunRadiusKm;
    uniform float u_bodyRadiusKm;
    uniform float u_umbralT;
    uniform vec3  u_umbralTint;
    varying vec3  vN;
    varying vec3  vW;
    varying float vSpeck;
    void main() {
        vec3 n = normalize(vN);
        vec3 toSun = normalize(u_sunPos - vW);        // orrery: the origin
        vec3 toCam = normalize(cameraPosition - vW);
        // LOMMEL–SEELIGER and the opposition surge, from js/airless-body.js —
        // the SAME law the far-field impostor and every moon on this page use,
        // so crossing a LOD line or looking at a different kind of body never
        // changes the physics. The H–G phase function is deliberately NOT
        // applied here: it is disc-integrated and this shader is drawing the
        // terminator itself (see the airless-body header).
        float mu0 = max(dot(n, toSun), 0.0);
        float mu  = max(dot(n, toCam), 1e-3);
        float alpha = acos(clamp(dot(toSun, toCam), -1.0, 1.0));
        float brdf = lommelSeeliger(mu0, mu) * oppositionSurge(alpha, u_B0, u_hOpp);
        // Earth's shadow, at THIS point on the surface, in real kilometres.
        vec3 offs = n * u_bodyRadiusKm;
        float lit = (u_occRadiusKm > 0.0)
            ? solarLitAt(u_sunFromBodyKm - offs, u_occFromBodyKm - offs, u_occRadiusKm, u_sunRadiusKm)
            : 1.0;
        vec3 sunTint = mix(u_umbralTint, vec3(1.0), clamp(lit * 3.0, 0.0, 1.0));
        float direct = max(lit, (1.0 - lit) * u_umbralT);
        float shine = u_shine * lommelSeeliger(max(dot(n, normalize(u_shineDir)), 0.0), mu);

        float lit_tone = airlessTone(u_albedo * u_illum * (brdf * direct + shine), u_gain, u_stretch);
        float rim  = pow(1.0 - max(dot(n, toCam), 0.0), 3.0) * (0.06 + u_glow * 0.5);
        vec3 col = u_base * lit_tone * (0.82 + 0.36 * vSpeck) * sunTint + rim * vec3(0.7, 0.85, 1.0);
        col += u_glow * vec3(0.55, 0.75, 1.0) * 0.25;
        gl_FragColor = vec4(col, 1.0);
        gl_FragColor.rgb = toneDecode(gl_FragColor.rgb);   // sRGB colour picks → linear
        #include <tonemapping_fragment>
        #include <colorspace_fragment>
    }
`;

/**
 * @param {number} colorHex   the taxonomy's tint
 * @param {number} glow       cometary coma haze, 0..1
 * @param {{albedo?:number, illum?:number, gain?:number, stretch?:number,
 *          bodyRadiusKm?:number, sunPos?:object}} [phot]
 *        photometry: geometric albedo, the illumination reaching the body, and
 *        the display normalisation every airless body on the page shares.
 *        Defaults reproduce a 0.14-albedo body at 1 AU.
 *        `sunPos` is WHERE THE SUN IS in world space (a THREE.Vector3). It
 *        defaults to the origin because that is where the orrery draws it, so
 *        omitting it reproduces the original `normalize(-vW)` exactly —
 *        neo-watch.html is EARTH-centred and must pass it, or every rock on
 *        that stage is lit from Earth.
 */
export function rockMaterial(colorHex, glow = 0, phot = {}) {
    return new THREE.ShaderMaterial({
        vertexShader: ROCK_VS, fragmentShader: ROCK_FS,
        uniforms: {
            u_base: { value: new THREE.Color(colorHex) }, u_glow: { value: glow },
            u_sunPos:  { value: phot.sunPos ? phot.sunPos.clone() : new THREE.Vector3(0, 0, 0) },
            u_albedo:  { value: phot.albedo ?? 0.14 },
            u_illum:   { value: phot.illum ?? 1 },
            u_gain:    { value: phot.gain ?? AIRLESS_DISPLAY.gain },
            u_stretch: { value: phot.stretch ?? AIRLESS_DISPLAY.stretch },
            u_B0:      { value: OPPOSITION.B0 },
            u_hOpp:    { value: OPPOSITION.h },
            u_shine:    { value: 0 },
            u_shineDir: { value: new THREE.Vector3(0, 0, 1) },
            u_sunFromBodyKm: { value: new THREE.Vector3(1.496e8, 0, 0) },
            u_occFromBodyKm: { value: new THREE.Vector3(0, 0, 0) },
            u_occRadiusKm:   { value: 0 },
            u_sunRadiusKm:   { value: SUN_RADIUS_KM },
            u_bodyRadiusKm:  { value: phot.bodyRadiusKm ?? 1 },
            u_umbralT:       { value: UMBRAL_TRANSMISSION },
            u_umbralTint:    { value: new THREE.Color(UMBRAL_TINT.r, UMBRAL_TINT.g, UMBRAL_TINT.b) },
        },
    });
}

/** Spin axis (unit) and phase for an object — seeded, stable. */
export function spinFor(des, seed) {
    const r = rng(seed ^ 0x2545f491);
    const th = r() * Math.PI * 2, ph = Math.acos(r() * 2 - 1);
    const axis = new THREE.Vector3(Math.sin(ph) * Math.cos(th), Math.sin(ph) * Math.sin(th), Math.cos(ph)).normalize();
    const periodH = ROTATION_PERIOD_H[des] ?? (2.2 + r() * 9.5);
    return { axis, periodH, phase: r() * Math.PI * 2 };
}

