/**
 * nav.js — Shared navigation component with rich dropdowns + tier gating
 *
 * Generates a full navigation bar with:
 *   - Logo + brand (which IS the home link — there is no separate "Home"
 *     item; it was redundant with the brand and cost bar width the ladder
 *     could not spare)
 *   - Five section dropdowns from js/site-sections.js — Space Weather,
 *     Earth & Orbit, Local Space, Deep Space, Research — plus a flat link to
 *     the full catalog. Menu CONTENTS live in NAV_ITEMS below; the top level
 *     lives in js/site-sections.js.
 *   - Tier-gated items (public, free, advanced) where 'advanced' ≡ PRO
 *     (Advanced + Institution + Enterprise). See auth.isPro().
 *   - Auth state (Sign In / Dashboard / Admin badge)
 *   - Compact utility text-links in the auth area (Dashboard · Account ·
 *     Pricing) plus an inline PRO promo for non-pro users.
 *   - Mobile burger with full menu expansion + accordion dropdowns
 *   - Robust hover with delay for desktop, touch-aware for hybrid devices
 *   - Keyboard support (Escape, Tab focus management)
 *
 * SPLIT TOP-LEVEL CONTROLS
 * ────────────────────────
 * Each section renders as TWO controls that read as one chip:
 *
 *     <a class="nav-drop-btn" href="/local-space.html">Local Space</a>
 *     <button class="nav-drop-toggle" aria-expanded>▾</button>
 *
 * The label navigates to the section's hub page; the caret opens the menu.
 * Before this the top-level items were bare <button>s that only toggled, so
 * "Space Weather" led nowhere and the menu had to carry the whole section —
 * which is how it grew to 18 links and ran off the bottom of the screen.
 *
 * A link that also opens a menu on click is the pattern that breaks on touch
 * (you can never reach the menu, or you can never follow the link). Splitting
 * the two gives both a real target — two 44px hit areas in burger mode — and,
 * just as importantly, leaves the scarred hover/touch detection below
 * completely untouched: the toggle behaves exactly as the old button did.
 */

// Side-effect import: OAuth/OTP misland sentinel. Runs first so a token that
// landed on the wrong page (Supabase Site-URL fallback) is detected + forwarded
// to /auth-callback.html before anything else can consume or clear the hash.
// See js/oauth-sentinel.js.
import './oauth-sentinel.js';

// Side-effect import: cross-page guided tour controller. Hooks the hero CTA
// on the home page and renders a progress banner on each tour stop.
import './explore-tour.js';
import { tierLevel as _cfgTierLevel, PAID_PLAN_IDS } from './tier-config.js';
// Side-effect import: boots the telemetry singleton (window.onerror,
// unhandledrejection, Web-Vitals observers). Every page that mounts
// the nav gets autocapture for free; pages without the nav (rare,
// embedded simulators) opt-in by importing js/telemetry.js directly.
import './telemetry.js';
// Side-effect import: site-wide visitor-flow instrumentation (enter/exit
// per pageview on the consent-exempt operational pipeline). Riding nav.js
// gives every page that mounts the nav full-population flow/bounce/
// engagement measurement for free — the consent-gated analytics pipeline
// only ever sees the ~2% of visitors who accept the cookie banner.
import './page-flow.js';
import { glyph } from './glyphs.js';
// The top-level structure — id, label and hub href per section. This module is
// the single source shared with js/simulations-catalog.js and the hub-page
// builder, so the bar, the catalog page and the hubs cannot disagree about
// what the sections are or what they are called.
import { SITE_SECTIONS } from './site-sections.js';

// Root-absolute so the shared nav renders identically from any directory
// depth — pages under /satellite-operator/ etc. would otherwise 404 the
// logo and every nav link (relative paths resolve against the subdir).
// The brand mark is SVG (icons/logo-mark.svg), not the 266 KB
// ParkersPhysics_logo2.jpg it replaced. That JPEG was being downloaded on
// every one of the ~55 pages that mount the nav and then drawn at 30px —
// roughly 1 % of its pixels. The vector is ~1 KB, sharp on HiDPI, and needs
// no circular crop because it is drawn to fit rather than being a square
// photo. The JPEG stays in the repo: it is still the og:image for social
// cards, where a raster IS required.
const LOGO_IMG = '/icons/logo-mark.svg';

/**
 * Render a nav item's icon.
 *
 * Falls back to emitting the raw value when it is not a known glyph id, so a
 * literal character or emoji left anywhere in NAV_DROPDOWNS still renders
 * instead of vanishing. tests/glyphs.mjs is what stops that fallback from
 * becoming a silent hiding place for typos.
 */
function navIcon(icon) {
    if (!icon) return '';
    return glyph(icon, { size: 20 }) || icon;
}

// ── Navigation Structure ─────────────────────────────────────────────────────

/**
 * Per-section menu contents.
 *
 * THE TOP LEVEL LIVES IN js/site-sections.js, not here. This object owns only
 * the CURATED item list for each section — the id, label and hub href come
 * from there, so the menu, the hub page and simulations.html cannot disagree
 * about what a section is called or where it lives.
 *
 * CURATED IS THE POINT — AND THERE IS A HARD CAP
 * ──────────────────────────────────────────────
 * A dropdown panel hangs off a 50px bar and is `position: absolute` inside a
 * `nav` with `overflow: visible`. Nothing scrolls it and nothing clips it, so
 * whatever does not fit the viewport is simply UNREACHABLE — the same failure
 * the mobile accordion had with `max-height: 600px`, on the vertical axis.
 *
 * That was live: "Space Weather" had grown to 18 links and 1110px, and on a
 * 1366×768 laptop its bottom SEVEN links (Jupiter, Saturn, Uranus, Neptune,
 * Space Missions, Mission Planner, Galaxy) could not be reached at all.
 *
 * So: **at most ~10 links and ~3 section headers per menu**, which lands under
 * ~700px and clears the 768px-tall laptop that is the floor. `.nav-drop-menu`
 * now also carries a `max-height` + `overflow-y: auto` backstop so a future
 * overrun degrades to a scroll instead of vanishing, but the backstop is the
 * seatbelt, not the design. tests/nav-responsive.spec.js measures every panel
 * against the viewport and fails on one link below the fold.
 *
 * Anything that does not make the cut is NOT lost — it is on the section's hub
 * page, which is what the top-level label now links to, and in the full
 * catalog at simulations.html. Deciding what to leave out is a real editorial
 * choice; making the menu longer is not an option.
 */
const NAV_ITEMS = {
    'space-weather': [
        { section: 'Live conditions' },
        { href: 'space-weather.html', label: 'Live Console',    sub: 'Composable dashboard · solar & geomagnetic', tier: 'public', icon: 'space-weather', id: 'weather' },
        { href: 'sun.html',           label: 'Sun Watch',       sub: 'Live 3D Sun · flares · CMEs · coronal holes', tier: 'public', icon: 'sun' },
        { href: 'auroracle.html',     label: 'AurOracle',       sub: 'Predict the aurora · 7-night + 30-day',      tier: 'public', icon: 'aurora', badge: 'NEW', id: 'auroracle' },
        { section: 'Forecasting' },
        { href: 'cme-forecast.html',   label: 'CME Forecast',         sub: 'Locked arrivals · uncertainty + live skill',   tier: 'public', icon: 'flux-rope', badge: 'NEW', id: 'cme-forecast' },
        { href: 'flux-rope-live.html', label: 'Compounding Watch',    sub: 'Real-time CME trains · interaction physics',   tier: 'public', icon: 'flux-rope', badge: 'NEW', id: 'flux-rope-live' },
        { href: 'flux-rope.html',      label: 'Flux Rope Simulator',  sub: 'CME Bz forecasting · ensemble Sun→Earth',      tier: 'public', icon: 'flux-rope', badge: 'NEW', id: 'flux-rope' },
        { href: 'far-side-watch.html', label: 'Far-Side Watch',       sub: 'Regions rotating in · days-to-weeks horizon',  tier: 'public', icon: 'far-side', badge: 'NEW', id: 'far-side-watch' },
        { section: 'Geospace response' },
        { href: 'ring-current.html',   label: 'Ring Current',   sub: 'Live Dst digital twin · L1-driven forecast',  tier: 'public', icon: 'magnet', badge: 'NEW', id: 'ring-current' },
        { href: 'shielding-lab.html',  label: 'Shielding Lab',  sub: 'M–I coupling · SAPS + penetration E-fields',  tier: 'public', icon: 'shield', badge: 'NEW', id: 'shielding-lab' },
        { href: 'tiga.html',           label: 'TIGA · Geomagnetic', sub: 'Core → field → nowcast with a posterior', tier: 'public', icon: 'dynamo', badge: 'NEW', id: 'tiga' },
    ],

    'earth-orbit': [
        { section: 'Earth systems' },
        { href: 'earth.html',            label: 'EarthView',        sub: 'Predictive weather + magnetosphere',      tier: 'public', icon: 'earth' },
        { href: 'pollution.html',        label: 'Pollution Lab',    sub: 'Live AQI · hotspot ML · climate forcing', tier: 'public', icon: 'atmosphere', badge: 'NEW', id: 'pollution' },
        { href: 'upper-atmosphere.html', label: 'Upper Atmosphere', sub: 'Thermosphere + exosphere simulator',      tier: 'public', icon: 'atmosphere', id: 'upper-atmosphere' },
        { section: 'Orbital operations' },
        { href: 'operations.html',     label: 'Operations',     sub: 'Fleet & debris analysis console',       tier: 'public', icon: 'operations', badge: 'PRO PREVIEW', id: 'operations' },
        { href: 'satellites.html',     label: 'Satellites',     sub: 'Real-time orbital tracking',            tier: 'public', icon: 'satellite' },
        { href: 'launch-planner.html', label: 'Launch Planner', sub: 'SpaceX/Blue Origin launches + weather', tier: 'public', icon: 'rocket', id: 'launch-planner' },
        { href: 'neo-watch.html',      label: 'Near-Earth Watch', sub: 'Live NEO population around Earth · JPL', tier: 'public', icon: 'target', badge: 'NEW', id: 'neo-watch' },
        { section: 'Build & fly' },
        { href: 'satellite-designer.html', label: 'Satellite Designer',  sub: 'Build a craft · fly drag vs thrust',     tier: 'public', icon: 'satellite', badge: 'NEW', id: 'satellite-designer' },
        { href: 'spaceship-designer.html', label: 'Space Ship Designer', sub: 'Build a rocket · fly it to orbit in 3D', tier: 'public', icon: 'rocket', badge: 'NEW', id: 'spaceship-designer' },
    ],

    'local-space': [
        { section: 'Worlds' },
        { href: 'moon.html',   label: 'The Moon',        sub: 'Radiation, interior, and a real relief surface', tier: 'public', icon: 'moon' },
        { href: 'mars.html',   label: 'Real-Time Mars',  sub: 'Perseverance + MEDA on a NASA terrain globe',    tier: 'public', icon: 'planet', badge: 'NEW', id: 'mars' },
        { section: 'Planetary systems' },
        { href: 'solar-system.html',   label: 'Solar System',   sub: '31 moons · live Galilean N-body',                tier: 'public', icon: 'solar-system', id: 'solar' },
        { href: 'jupiter-system.html', label: 'Jupiter System', sub: 'Galilean moons · 4:2:1 Laplace resonance',       tier: 'public', icon: 'planet', id: 'jupiter-system' },
        { href: 'saturn-system.html',  label: 'Saturn System',  sub: 'Moon-sculpted rings · live density waves',       tier: 'public', icon: 'planet', badge: 'NEW', id: 'saturn-system' },
        { href: 'uranus-system.html',  label: 'Uranus System',  sub: 'Tipped 98° · ε-ring shepherds · crowded moons',  tier: 'public', icon: 'planet-ice', badge: 'NEW', id: 'uranus-system' },
        { href: 'neptune-system.html', label: 'Neptune System', sub: 'Retrograde Triton · rings & arcs · J₂ N-body',   tier: 'public', icon: 'planet-ice', badge: 'NEW', id: 'neptune-system' },
        { section: 'Maps & missions' },
        { href: 'missions.html',     label: 'Space Missions', sub: 'Inner solar system fleet roster', tier: 'public', icon: 'probe', id: 'missions' },
        { href: 'galactic-map.html', label: 'Galaxy Map',     sub: '3D Milky Way star map',           tier: 'free',   icon: 'galaxy' },
        // 2026-10-05: SkyView took Lunar Colony's slot (colony.html stays on the
        // Local Space hub and in the catalogue) — this menu is at its 10-link cap
        // (js/site-sections.js). It sits beside the Galaxy Map because it draws
        // that map's objects in the visitor's own sky.
        { href: 'skyview.html',      label: 'SkyView',        sub: 'Your sky now · top 10 to see',    tier: 'public', icon: 'sky-dome', badge: 'NEW', id: 'skyview' },
    ],

    'deep-space': [
        { section: 'Stars' },
        { href: 'sirius.html',     label: 'Sirius Binary', sub: 'A1V + white dwarf system',   tier: 'public', icon: 'star-binary' },
        { href: 'betelgeuse.html', label: 'Betelgeuse',    sub: 'Red supergiant · M1-2 Ia',   tier: 'public', icon: 'star-red' },
        { href: 'vega.html',       label: 'Vega',          sub: 'Rapid rotator · A0V',        tier: 'public', icon: 'star-bright' },
        { href: 'achernar.html',   label: 'Achernar',      sub: 'Oblate Be star · B6Vep',     tier: 'public', icon: 'star-oblate' },
        { href: 'wr102.html',      label: 'WR-102',        sub: 'Wolf-Rayet · hottest known', tier: 'free',   icon: 'star-wr' },
        { section: 'Black holes' },
        { href: 'ton618.html',                label: 'TON 618',                sub: 'Research observatory · 6.6×10¹⁰ M☉', tier: 'public', icon: 'black-hole', id: 'ton618' },
        { href: 'blackhole-observatory.html', label: 'Black Hole Observatory', sub: 'Three UMBH systems · one canvas',     tier: 'public', icon: 'observatory', badge: 'NEW', id: 'blackhole-observatory' },
        { href: 'sagittarius.html',           label: 'Sagittarius A*',         sub: 'Galactic center · live',              tier: 'public', icon: 'black-hole-core', id: 'sagittarius' },
        // 2026-09-20: Star Collider Lab took this slot from Black Hole Accretion
        // (black-hole-fluid.html), which stays on the Deep Space hub and in the
        // catalogue — the menu is at its 10-link cap (js/site-sections.js).
        { href: 'star-collider.html',         label: 'Star Collider Lab',      sub: 'NS · BH · WD mergers · SPH engine',   tier: 'public', icon: 'collider', badge: 'NEW', id: 'star-collider' },
        { section: 'Cosmic web' },
        { href: 'bootes-void.html',           label: 'Boötes Void',            sub: 'Supervoid dynamics · the counterfactual', tier: 'public', icon: 'void', badge: 'NEW', id: 'bootes-void' },
    ],

    // Research keeps the 2026-07-25 "run vs read" split the author asked for —
    // it is now two labelled sections inside one menu instead of two top-level
    // items. The Hindcast Lab section is the interactive replay for each
    // validation-database event (they land in HINDCAST_BACKLOG.md order);
    // Field Notes is the writing. Each event's replay page still links its own
    // paper in-page, so the event→paper path survives without duplicating it
    // in the menu.
    //
    // ACTIVE-ID NOTE: the Field Notes hub's id is 'field-notes', NOT 'blog'.
    // The active-item match below is a prefix match in both directions, so an
    // id of 'blog' would light up every 'blog-*' post at once.
    research: [
        { section: 'Hindcast Lab' },
        { href: 'gannon-superstorm.html', label: 'Gannon Superstorm',  sub: 'May 2024 G5 · 72 h replay vs the Ap ceiling', tier: 'public', icon: 'storm', id: 'gannon-superstorm' },
        { href: 'st-patrick-storm.html',  label: "St. Patrick's Storm", sub: 'Mar 2015 G4 · the community benchmark',      tier: 'public', icon: 'storm-two-step', badge: 'NEW', id: 'st-patrick-storm' },
        { section: 'Field Notes' },
        { href: 'blog.html',                          label: 'All Field Notes',           sub: 'Post-mortems, hindcasts, methods', tier: 'public', icon: 'notebook', id: 'field-notes' },
        { href: 'blog-why-aurora-forecasts-miss.html', label: 'NOAA said G1. Earth got G3.', sub: 'July 4 2026 · the Bz gap',      tier: 'public', icon: 'chart-down', badge: 'NEW', id: 'blog-why-aurora-forecasts-miss' },
        { href: 'blog-gannon-hindcast.html',           label: 'The Index That Lied',        sub: 'Gannon G5 · EN/ES/FR',           tier: 'public', icon: 'paper', id: 'blog-gannon-hindcast' },
        { href: 'blog-stpatrick-hindcast.html',        label: 'The Storm Every Model Takes', sub: "St. Patrick's 2015 · EN/ES/FR", tier: 'public', icon: 'paper', id: 'blog-stpatrick-hindcast' },
        { section: 'Engine & methods' },
        { href: 'rust.html', label: 'Rust/WASM Engine', sub: 'WebAssembly compute module', tier: 'free', icon: 'engine' },
    ],
};

// The top level: one dropdown per site section, in js/site-sections.js order.
// `href` is the section's hub page — the label is a real link now, not just a
// menu toggle. See the markup notes in initNav().
const NAV_DROPDOWNS = SITE_SECTIONS.map(section => ({
    id: section.id,
    label: section.label,
    href: section.href,
    items: NAV_ITEMS[section.id] || [],
}));

// ── Auth helpers ──────────────────────────────────────────────────────────────

const AUTH_KEY = 'pp_auth';

function _getAuth() {
    let auth = null;
    try { auth = JSON.parse(localStorage.getItem(AUTH_KEY) || 'null'); } catch (_) {}
    if (!auth) { try { auth = JSON.parse(sessionStorage.getItem(AUTH_KEY) || 'null'); } catch (_) {} }
    if (!auth?.signedIn) return null;
    // Superadmin "view as user" override (js/view-as.js). Anti-escalation:
    // applyTo() returns the input unchanged unless the real role is
    // 'superadmin' — anyone else who plants the sessionStorage key is
    // ignored. Server-side calls keep using the real session JWT.
    try {
        const raw = sessionStorage.getItem('pp-view-as');
        if (raw && auth.role === 'superadmin') {
            const o = JSON.parse(raw);
            if (o && o.role) {
                return { ...auth, role: o.role, plan: o.plan ?? auth.plan, _viewAs: true, _realRole: 'superadmin' };
            }
        }
    } catch (_) {}
    return auth;
}

// Tier level determines which menu items + features a user can see.
// Educator sits alongside Basic (level 2) — same data feeds, plus embed
// permission. Institution + Enterprise are Advanced-equivalent (level 3).
// The mapping itself lives in js/tier-config.js (single source of truth);
// this wrapper keeps the existing 0 fallback for blank-plan accounts.
function _tierLevel(plan, role) {
    const lvl = _cfgTierLevel(plan, role);
    return lvl > 0 ? lvl : 0;
}

function _tierRequired(tier) {
    if (tier === 'advanced') return 3;
    if (tier === 'intro') return 2;
    if (tier === 'free') return 1;
    return 0;
}

// ── Global-listener guard ──────────────────────────────────────────────────
// initNav() is called once on import and again on every `auth-changed`
// event (so the admin badge / sign-in state stays fresh). Without this
// guard each re-entry would stack ANOTHER copy of the document/window
// event listeners — the earliest ones then reference stale burger/menu
// DOM nodes (nav.innerHTML = html blows them away on every build), which
// on mobile produced the "can't re-toggle the burger" bug: the original
// click handler was wired to a now-detached element.
//
// We bind once, then always resolve burger/menu via document.getElementById
// so we're operating on the live DOM regardless of how many re-renders
// have happened.
let _globalListenersBound = false;

// Width at or below which the bar collapses to the burger. MUST stay in sync
// with the `@media (max-width: 1280px)` block in js/nav-styles.css — the CSS
// decides what the user sees, this decides whether hover logic may run, and a
// mismatch means hover handlers firing on an accordion (or not firing on a
// bar). tests/nav-responsive.spec.js pins the two together.
const MOBILE_NAV_MAX = 1280;

// Timestamp of the last touchstart, used to ignore the COMPATIBILITY mouse
// events browsers synthesize after a tap. See _canHover().
let _lastTouchAt = 0;

function _getBurger() { return document.getElementById('nav-burger'); }
function _getMenu()   { return document.getElementById('nav-menu');  }

/**
 * May the hover-to-open dropdown behaviour run right now?
 *
 * THREE gates, and all three earned their place:
 *
 *  1. Not in burger mode. Below MOBILE_NAV_MAX the dropdowns are accordions
 *     inside a panel; hover has no meaning there.
 *  2. The device actually hovers. `(hover: hover) and (pointer: fine)` is
 *     false on phones and tablets, so the whole hover path is dead code on
 *     touch — which is the only way to be sure it cannot interfere.
 *  3. The last input was not a touch.
 *
 * Gate 3 alone used to be the whole check, and it did not work. After a tap,
 * browsers synthesize a compatibility `mousemove`, which set the flag back to
 * 'false' BEFORE the click landed. The sequence measured on a real tap was:
 * touchstart (flag→true) → mouseover → mouseenter (correctly skipped) →
 * mousemove (flag→false) → click → openDrop() → mouseleave → scheduleClose().
 * So every tap on a dropdown opened it and then closed it ~250ms later, and
 * the mobile menu's dropdowns could not be opened at all. Hence the 800ms
 * quiet period in the touchstart/mousemove listeners below: a mousemove that
 * arrives on the heels of a touch is the browser talking, not the user.
 */
function _canHover() {
    if (window.innerWidth <= MOBILE_NAV_MAX) return false;
    if (!window.matchMedia('(hover: hover) and (pointer: fine)').matches) return false;
    return document.body.dataset.ppLastWasTouch !== 'true';
}

function _closeAll() {
    const menu = _getMenu();
    const burger = _getBurger();
    menu?.classList.remove('open');
    burger?.classList.remove('open');
    burger?.setAttribute('aria-expanded', 'false');
    document.body.style.overflow = '';
    document.querySelectorAll('nav .nav-drop.open').forEach(d => {
        d.classList.remove('open');
        d.querySelector('.nav-drop-toggle')?.setAttribute('aria-expanded', 'false');
    });
}

// ── Nav Builder ──────────────────────────────────────────────────────────────

export function initNav(activeId = '') {
    const nav = document.querySelector('nav');
    if (!nav) return;

    // Lazy-load the cookie-consent banner — module ensures single-mount.
    if (!window._ppConsentLoaded) {
        window._ppConsentLoaded = true;
        import('./cookie-consent.js').catch(() => { window._ppConsentLoaded = false; });
    }

    // Lazy-load the "View as user" widget (superadmin-only; self-gates).
    // Real-role check happens inside view-as.js — non-superadmins get nothing.
    if (!window._ppViewAsLoaded) {
        window._ppViewAsLoaded = true;
        import('./view-as.js').then(m => m.mount?.()).catch(() => { window._ppViewAsLoaded = false; });
    }

    const auth = _getAuth();
    const userTier = _tierLevel(auth?.plan, auth?.role);
    const isSignedIn = !!auth;
    const isAdmin = auth?.role === 'admin' || auth?.role === 'superadmin';

    // Educator tier carries a "Powered by Parkers Physics" attribution
    // requirement. Mount the badge once; it self-renders on auth-changed
    // so a plan switch toggles visibility without a reload. Cheap to
    // import even when no badge is shown — the module is ~1.5kb.
    import('./attribution-badge.js')
        .then(m => m.mountAttributionBadge?.())
        .catch(() => { /* nav must not break if the badge module fails */ });

    // First-party analytics: auto-tracks page views, time-on-page, scroll
    // depth, and (opt-in) clicks. Side-effect import — singleton inside.
    //
    // Shared identify bootstrap: identify() was previously only wired into
    // the auth pages (signin/signup/auth-callback/settings/welcome), so a
    // returning user landing straight on an app page never tagged their
    // analytics_events rows with a user_id. The admin "unique users" KPIs
    // filter out null user_id, so they read 0 despite real traffic. nav.js
    // loads on every page and re-runs on `auth-changed`, so this is the
    // single place that reliably knows "who is signed in, on every page".
    // Guarded on the user id so re-renders don't spam identify()/heartbeat;
    // a sign-out (auth → null) resets the guard so a later sign-in
    // re-identifies.
    import('./analytics.js')
        .then(m => {
            const uid = auth?.id;
            if (uid && window._ppAnalyticsIdentified !== uid) {
                window._ppAnalyticsIdentified = uid;
                m.analytics?.identify?.(uid, { plan: auth.plan, role: auth.role });
            } else if (!uid) {
                window._ppAnalyticsIdentified = null;
            }
        })
        .catch(() => { /* analytics must not break nav */ });

    // Re-render nav when profile fetches real role (fixes admin button
    // not showing because nav rendered before fetchProfile() resolved)
    if (!nav._authListener) {
        nav._authListener = true;
        window.addEventListener('auth-changed', () => initNav(activeId));
    }

    // The brand IS the home link, and carries aria-current on the home page.
    // There used to be a separate "Home" nav-item beside it; it pointed at the
    // same URL and cost ~60px of a bar that had 16px of headroom at 1281px.
    let html = `
        <a href="/index.html" class="nav-brand" aria-label="Parkers Physics home"${activeId === 'home' ? ' aria-current="page"' : ''}>
            <img src="${LOGO_IMG}" class="nav-logo-img" alt="Parkers Physics">
            Parkers Physics
        </a>
        <button type="button" class="nav-burger" id="nav-burger" aria-label="Menu" aria-expanded="false">
            <span class="burger-line"></span>
            <span class="burger-line"></span>
            <span class="burger-line"></span>
        </button>
        <div class="nav-menu" id="nav-menu">
    `;

    // Dropdown menus — one per section, from js/site-sections.js.
    for (const dd of NAV_DROPDOWNS) {
        // The hub page itself is active (activeId is the section id, which is
        // what each generated hub passes to initNav). Exact match, not the
        // prefix match used for items: 'space-weather' is both a section id
        // and a page basename, and a prefix match would light the section up
        // from unrelated ids that happen to share a stem.
        const sectionActive = activeId === dd.id;
        const anyActive = sectionActive || dd.items.some(i => {
            if (i.section) return false;
            const itemId = i.id || i.href.replace('.html', '');
            return itemId === activeId || itemId.startsWith(activeId) || activeId.startsWith(itemId);
        });

        html += `<div class="nav-drop" data-drop="${dd.id}">`;
        // Two controls, one chip. See the SPLIT TOP-LEVEL CONTROLS note in the
        // file header: the label is a real link to the section hub, the caret
        // is the menu disclosure. Keeping them separate is what lets the touch
        // path stay identical to the old bare-button behaviour.
        html += `<a href="/${dd.href}" class="nav-drop-btn${anyActive ? ' active' : ''}"${sectionActive ? ' aria-current="page"' : ''}>${dd.label}</a>`;
        html += `<button type="button" class="nav-drop-toggle" aria-haspopup="true" aria-expanded="false" aria-controls="navdrop-${dd.id}" aria-label="${dd.label} menu"><span class="nav-caret">&#9662;</span></button>`;
        // `.nav-drop-inner` exists for the MOBILE accordion: the panel
        // animates `grid-template-rows: 0fr → 1fr`, which needs exactly one
        // grid child to size against. That replaced a `max-height: 600px`
        // hack that silently clipped the Space Weather menu — 1015px of
        // content, so its last 7 links were unreachable on every phone.
        // role="none" keeps the wrapper out of the a11y tree so the links
        // stay direct menuitem children of role="menu".
        html += `<div class="nav-drop-menu" id="navdrop-${dd.id}" role="menu"><div class="nav-drop-inner" role="none">`;

        for (const item of dd.items) {
            if (item.section) {
                html += `<div class="nav-drop-section">${item.section}</div>`;
                continue;
            }

            const required = _tierRequired(item.tier);
            const hasAccess = userTier >= required || item.tier === 'public';

            if (!hasAccess && item.tier === 'advanced') {
                html += `<a href="/pricing.html" class="nav-drop-link" style="opacity:0.5" role="menuitem" title="Available on Advanced plan">
                    <span class="ndl-icon">${navIcon(item.icon)}</span>
                    <span class="ndl-body">
                        <span class="ndl-title">${item.label} <span class="nav-badge-pro">PRO</span></span>
                        <span class="ndl-sub">${item.sub}</span>
                    </span>
                </a>`;
            } else if (!hasAccess) {
                html += `<a href="/signin.html" class="nav-drop-link" style="opacity:0.4" role="menuitem" title="Sign up for free to access">
                    <span class="ndl-icon">${navIcon(item.icon)}</span>
                    <span class="ndl-body">
                        <span class="ndl-title">${item.label} <span style="font-size:.6rem;color:#665">Sign up</span></span>
                        <span class="ndl-sub">${item.sub}</span>
                    </span>
                </a>`;
            } else {
                const _hid = item.id || item.href.replace('.html','');
                const _isAct = _hid === activeId || _hid.startsWith(activeId) || activeId.startsWith(_hid);
                html += `<a href="/${item.href}" class="nav-drop-link${_isAct ? ' active' : ''}" role="menuitem">
                    <span class="ndl-icon">${navIcon(item.icon)}</span>
                    <span class="ndl-body">
                        <span class="ndl-title">${item.label}${item.badge ? (
                            item.badge === 'NEW'
                                ? ` <sup class="nav-badge-new">${item.badge}</sup>`
                                : ` <span class="nav-badge-pro" style="background:rgba(0,200,200,.12);color:#0cc;border-color:rgba(0,200,200,.25)">${item.badge}</span>`
                        ) : ''}</span>
                        <span class="ndl-sub">${item.sub}</span>
                    </span>
                </a>`;
            }
        }

        html += `</div></div></div>`;   // .nav-drop-inner / .nav-drop-menu / .nav-drop
    }

    // Catalog link — the complete index of every simulation we ship.
    //
    // Deliberately a FLAT LINK and not a sixth dropdown. The five dropdowns
    // above are curated: each is capped at ~10 links so the panel fits the
    // screen, so between them they omit roughly a third of the catalog.
    // simulations.html is the other thing — the full grid, all 55, generated
    // from js/simulations-catalog.js. Nesting the whole catalog inside a menu
    // would just be a worse version of the page, and a menu that could not
    // fit on a laptop is precisely the bug this restructure fixed.
    //
    // Last in the row on purpose: it is the fallback for "I know we have one
    // of these somewhere", which is a different intent from browsing a
    // section, and it reads as the end of the list rather than a peer of it.
    //
    // tests/simulations-catalog.mjs pins this link, so a nav refactor cannot
    // orphan the catalog page without failing the gate.
    html += `<a href="/simulations.html" class="nav-item${activeId === 'simulations' ? ' active' : ''}">Simulations</a>`;

    // Spacer + auth
    html += '<span class="nav-spacer"></span>';

    // Utility text-links (Dashboard · Account · Pricing) + PRO promo.
    // Signed-out users only get Pricing (Dashboard/Account require auth).
    // The PRO promo nudges Free/Basic users toward the simulations
    // unlocked by Advanced: Satellites, Launch Planner, Upper Atmosphere.
    const isPro = userTier >= 3;
    html += `<div class="nav-utility-links">`;
    if (isSignedIn) {
        html += `<a href="/dashboard.html" class="nav-util-link">Dashboard</a>`;
        html += `<a href="/account.html" class="nav-util-link">Account</a>`;
    }
    html += `<a href="/pricing.html" class="nav-util-link">Pricing</a>`;
    if (!isPro) {
        html += `<a href="/pricing.html" class="nav-pro-promo" title="Unlock Satellites, Launch Planner & Upper Atmosphere with PRO">
            <span class="nav-pro-spark">✨</span><span class="nav-pro-text">PRO unlocks Satellites · Launch Planner · Upper Atmosphere</span><span class="nav-pro-arrow" aria-hidden="true">→</span>
        </a>`;
    }
    html += `</div>`;

    html += '<span class="nav-auth-sep"></span>';

    if (isSignedIn) {
        // Notification bell (any paid tier or admin). PAID_PLAN_IDS is the
        // canonical set from js/tier-config.js.
        const canAlert = PAID_PLAN_IDS.has(auth?.plan) || isAdmin;
        if (canAlert) {
            html += `<div class="nav-bell-wrap" id="nav-bell-wrap">
                <button class="nav-bell" id="nav-bell-btn" title="Alerts" aria-label="Notifications">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/>
                    </svg>
                    <span class="nav-bell-badge" id="nav-bell-badge" style="display:none">0</span>
                </button>
                <div class="nav-bell-dropdown" id="nav-bell-dropdown" style="display:none">
                    <div class="nav-bell-header">
                        <span style="font-weight:700;font-size:.82rem;color:#ccc">Alerts</span>
                        <button id="nav-bell-read-all" style="background:none;border:none;color:var(--accent,#0cf);cursor:pointer;font-size:.68rem;font-family:inherit">Mark all read</button>
                    </div>
                    <div class="nav-bell-list" id="nav-bell-list">
                        <div style="padding:20px;text-align:center;color:#556;font-size:.78rem">No alerts yet</div>
                    </div>
                    <a href="/dashboard.html" class="nav-bell-footer">View all alerts</a>
                </div>
            </div>`;
        }
        if (auth?.role === 'tester') {
            html += `<span class="nav-item" style="background:rgba(0,200,200,.12);color:#0cc;border-color:rgba(0,200,200,.25);font-weight:700;font-size:.7rem;cursor:default">TESTER</span>`;
        }
        if (isAdmin) {
            html += `<a href="/admin.html" class="nav-item nav-admin-link">${auth.role === 'superadmin' ? 'SUPER' : 'ADMIN'}</a>`;
        }
        html += `<button class="nav-item nav-signout" id="nav-signout-btn">Sign Out</button>`;
    } else {
        html += `<a href="/signin.html" class="nav-item nav-login">Sign In</a>`;
        html += `<a href="/signup.html" class="nav-item nav-signup">Sign Up Free</a>`;
    }

    html += '</div>';

    // ── Preserve the open menu across a re-render ────────────────────────
    //
    // initNav() re-runs on `auth-changed`, which lands ~2-3s after load once
    // the Supabase session resolves — comfortably after a mobile visitor has
    // tapped the burger. `nav.innerHTML = html` then replaces the menu, so
    // the .open class went with it: the panel vanished mid-use, the burger
    // reverted to aria-expanded="false", and — the real damage —
    // `document.body.style.overflow` stayed 'hidden' because only _closeAll()
    // ever clears it. Nothing reopened the menu, so nothing ever cleared the
    // lock: the page was left permanently unscrollable on touch.
    //
    // Snapshot before, restore after, keyed by dropdown id rather than index
    // so tier gating cannot shift the mapping.
    const _prevMenu = document.getElementById('nav-menu');
    const _wasOpen = !!_prevMenu?.classList.contains('open');
    const _openDropIds = _wasOpen
        ? [...nav.querySelectorAll('.nav-drop.open')].map(d => d.dataset.drop)
        : [];

    nav.innerHTML = html;

    if (_wasOpen) {
        const menuEl = document.getElementById('nav-menu');
        const burgerEl = document.getElementById('nav-burger');
        menuEl?.classList.add('open');
        burgerEl?.classList.add('open');
        burgerEl?.setAttribute('aria-expanded', 'true');
        document.body.style.overflow = 'hidden';
        for (const id of _openDropIds) {
            const drop = nav.querySelector(`.nav-drop[data-drop="${id}"]`);
            if (!drop) continue;
            drop.classList.add('open');
            drop.querySelector('.nav-drop-toggle')?.setAttribute('aria-expanded', 'true');
        }
    }

    // ── Event handlers ────────────────────────────────────────────────────

    // ── Per-render, bound to the FRESH burger/menu DOM nodes ──────────────
    // These two listeners live on elements that were just created by
    // `nav.innerHTML = html`, so each initNav re-entry gets them anew
    // without any stale references. The globally-bound listeners below
    // always look up the live DOM by id.
    const burger = document.getElementById('nav-burger');
    const menu   = document.getElementById('nav-menu');

    burger?.addEventListener('click', (e) => {
        // stopPropagation keeps the "close on outside click" handler
        // below from firing on the same event bubble path.
        e.stopPropagation();
        const willOpen = !menu.classList.contains('open');
        if (willOpen) {
            menu.classList.add('open');
            burger.classList.add('open');
            burger.setAttribute('aria-expanded', 'true');
            document.body.style.overflow = 'hidden';
        } else {
            _closeAll();
        }
    });

    menu?.addEventListener('click', e => {
        // `.nav-drop-btn` is in this list because it is a LINK now (to the
        // section hub), not the menu toggle it used to be. Without it, tapping
        // a section label in burger mode navigated away and left the panel
        // open over the page that had just loaded — the exact symptom the
        // MOBILE_NAV_MAX note below describes, reintroduced by a new element.
        // The caret (`.nav-drop-toggle`) is deliberately NOT here: it opens
        // the accordion, so closing the whole panel on it would make the
        // section menus unreachable on touch.
        if (e.target.closest('.nav-drop-link') || e.target.closest('.nav-item')
            || e.target.closest('.nav-drop-btn')) {
            // Only close on mobile — on desktop, dropdown link clicks
            // navigate normally and the menu goes away with the page.
            // MOBILE_NAV_MAX, not a second hardcoded breakpoint: this used to
            // say 1024 and silently disagreed with the CSS the moment the
            // burger threshold moved, leaving the panel open over the page a
            // visitor had just navigated to.
            if (window.innerWidth <= MOBILE_NAV_MAX) _closeAll();
        }
    });

    // ── Global listeners — bound ONCE across all initNav re-entries ───────
    if (!_globalListenersBound) {
        _globalListenersBound = true;

        // Track whether last interaction was touch (for hybrid devices).
        // Attached to document (not nav) so the flag survives re-renders.
        document.addEventListener('touchstart', () => {
            _lastTouchAt = Date.now();
            document.body.dataset.ppLastWasTouch = 'true';
        }, { passive: true });
        document.addEventListener('mousemove', () => {
            // Ignore the compatibility mousemove a browser fires just after a
            // tap — treating it as "the user picked up a mouse" is what broke
            // dropdowns on touch. See _canHover() for the measured sequence.
            if (Date.now() - _lastTouchAt < 800) return;
            document.body.dataset.ppLastWasTouch = 'false';
        }, { passive: true });

        // Close on outside click.
        document.addEventListener('click', e => {
            if (!e.target.closest('nav')) _closeAll();
        });

        // Escape closes dropdowns and mobile menu.
        document.addEventListener('keydown', e => {
            if (e.key !== 'Escape') return;
            _closeAll();
            const openBtn = document.querySelector('nav .nav-drop.open .nav-drop-toggle');
            if (openBtn) openBtn.focus();
            else _getBurger()?.focus();
        });
    }

    // ── Dropdown hover (desktop) + click (touch/mobile) ──────────────────
    nav.querySelectorAll('.nav-drop').forEach(drop => {
        const btn = drop.querySelector('.nav-drop-toggle');
        const dropMenu = drop.querySelector('.nav-drop-menu');
        let closeTimer = null;

        function openDrop() {
            clearTimeout(closeTimer);
            // Close sibling dropdowns
            nav.querySelectorAll('.nav-drop.open').forEach(d => {
                if (d !== drop) {
                    d.classList.remove('open');
                    d.querySelector('.nav-drop-toggle')?.setAttribute('aria-expanded', 'false');
                }
            });
            drop.classList.add('open');
            btn?.setAttribute('aria-expanded', 'true');
        }

        function scheduleClose() {
            clearTimeout(closeTimer);
            closeTimer = setTimeout(() => {
                drop.classList.remove('open');
                btn?.setAttribute('aria-expanded', 'false');
            }, 250);
        }

        // Desktop: hover with 250ms grace period. _canHover() is what keeps
        // this entire path off touch devices and out of the burger menu.
        drop.addEventListener('mouseenter', () => {
            if (_canHover()) openDrop();
        });
        drop.addEventListener('mouseleave', () => {
            if (_canHover()) scheduleClose();
        });

        // Keep open when hovering the dropdown menu itself
        if (dropMenu) {
            dropMenu.addEventListener('mouseenter', () => {
                if (_canHover()) clearTimeout(closeTimer);
            });
            dropMenu.addEventListener('mouseleave', () => {
                if (_canHover()) scheduleClose();
            });
        }

        // Click/tap toggle — works on all devices
        btn?.addEventListener('click', e => {
            e.stopPropagation();
            e.preventDefault();
            if (drop.classList.contains('open')) {
                drop.classList.remove('open');
                btn.setAttribute('aria-expanded', 'false');
            } else {
                openDrop();
            }
        });
    });

    // Sign out — use auth module to clear Supabase session + local storage
    document.getElementById('nav-signout-btn')?.addEventListener('click', async () => {
        try {
            const { auth } = await import('./auth.js');
            await auth.ready();
            auth.signOut('/index.html');
        } catch (_) {
            // Fallback if auth module fails to load
            try { localStorage.removeItem(AUTH_KEY); } catch (_e) {}
            try { sessionStorage.removeItem(AUTH_KEY); } catch (_e) {}
            window.location.href = '/index.html';
        }
    });

    // ── Notification bell ────────────────────────────────────────────────
    const bellBtn      = document.getElementById('nav-bell-btn');
    const bellDropdown = document.getElementById('nav-bell-dropdown');
    const bellBadge    = document.getElementById('nav-bell-badge');
    const bellList     = document.getElementById('nav-bell-list');

    if (bellBtn && bellDropdown) {
        // Toggle dropdown on click
        bellBtn.addEventListener('click', e => {
            e.stopPropagation();
            const open = bellDropdown.style.display === 'none';
            bellDropdown.style.display = open ? 'block' : 'none';
        });

        // Close on outside click
        document.addEventListener('click', e => {
            if (!e.target.closest('#nav-bell-wrap')) {
                bellDropdown.style.display = 'none';
            }
        });

        // Mark all read
        document.getElementById('nav-bell-read-all')?.addEventListener('click', () => {
            window.dispatchEvent(new CustomEvent('alert-mark-all-read'));
        });

        // Listen for alert updates
        window.addEventListener('user-alert', e => {
            const { recent, unread } = e.detail;
            // Update badge
            if (bellBadge) {
                bellBadge.textContent = unread > 99 ? '99+' : unread;
                bellBadge.style.display = unread > 0 ? '' : 'none';
            }
            // Update list (show last 8)
            if (bellList && recent) {
                if (!recent.length) {
                    bellList.innerHTML = '<div style="padding:20px;text-align:center;color:#556;font-size:.78rem">No alerts yet</div>';
                    return;
                }
                bellList.innerHTML = recent.slice(0, 8).map(a => {
                    const age = _relTime(a.created_at);
                    const sevCol = a.severity === 'critical' ? '#ff4444' : a.severity === 'warning' ? '#ffaa00' : '#44cc88';
                    const readCls = a.read ? ' style="opacity:.5"' : '';
                    return `<div class="nav-bell-item"${readCls}>
                        <span class="nav-bell-dot" style="background:${sevCol}"></span>
                        <div class="nav-bell-content">
                            <div class="nav-bell-title">${_escHtml(a.title)}</div>
                            <div class="nav-bell-body">${_escHtml(a.body?.slice(0, 100) ?? '')}</div>
                            <div class="nav-bell-time">${age}</div>
                        </div>
                    </div>`;
                }).join('');
            }
        });
    }
}

// ── Helpers ──────────────────────────────────────────────────────────────────

function _relTime(isoStr) {
    const ms = Date.now() - new Date(isoStr).getTime();
    if (ms < 60_000) return 'Just now';
    if (ms < 3600_000) return `${Math.floor(ms / 60_000)}m ago`;
    if (ms < 86400_000) return `${Math.floor(ms / 3600_000)}h ago`;
    return `${Math.floor(ms / 86400_000)}d ago`;
}

function _escHtml(s) {
    return s == null ? '' : String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}
