/**
 * ring-current-feed.js — data layer of the Ring Current Simulation
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * Assembles the real-time driver series for js/ring-current-model.js and
 * emits fully-computed model state. No THREE / rendering here; parse helpers
 * are pure and exported so node tests can exercise them.
 *
 * ── Sources & cadence (see RING_CURRENT_SIMULATION_PLAN.md §3) ──────────────
 *   full-day RTSW wind+mag  NOAA browser-direct   on start + T3 re-sync
 *   latest-sample append    /api/solar-wind/latest T1 (Supabase cache, 30 s CDN)
 *   observed Kyoto Dst      NOAA browser-direct   T3
 *   Kp (plasmapause)        NOAA browser-direct   T2
 *   GOES Hp (GEO check)     NOAA browser-direct   T3 (best-effort)
 *
 * IMF (bt/bz/bx/by) lives in rtsw_mag_1m.json, NOT in the plasma wind feed —
 * same split js/swpc-feed.js and api/cron/refresh-solar-wind.js handle.
 *
 * Degraded mode: if browser-direct NOAA is unreachable the feed falls back to
 * /api/solar-wind/latest?series=1 (60-min window) + /api/noaa/dst — the model
 * window shrinks but the page stays live. state.window reports which.
 *
 * ── Usage ───────────────────────────────────────────────────────────────────
 *   const feed = new RingCurrentFeed();
 *   feed.addEventListener('state', e => render(e.detail));
 *   feed.start();
 */

import { NOAA, INTERVALS } from './config.js';
import {
    integrateDst, integrateDstEnsemble, propagateToEarth, couplingVBs,
    dynamicPressure, dpsEnergyJ, ringPeakL, asymmetry, plasmapauseL,
    stormClass, toDstStar, obmQ, obmTau, skill, findThresholdCrossing, kpToAp,
    oxygenFraction, subsolarPoint, dipoleTiltRad, chargeExchangeLifetimeHours,
    shueStandoffRe, shueAlpha,
    SOLAR, sunDepartureMs, parkerSpiralDeg, sourceRotationDeg,
    carringtonL0, attributeWindSource, holeWindAssociation, holeArrivalForecast,
    cmeTransit,
} from './ring-current-model.js';

// rtsw_mag_1m is not in config.NOAA — defined locally, same as js/swpc-feed.js.
const NOAA_MAG_URL   = 'https://services.swpc.noaa.gov/json/rtsw/rtsw_mag_1m.json';
// GOES primary magnetometer at GEO (6.6 R_E) — the in-situ cross-check the
// plan's Phase 3 asks for. Browser-direct (CORS-enabled), same sanctioned
// NOAA pattern as the RTSW feeds. Best-effort: page works without it.
const NOAA_GOES_MAG_URL = 'https://services.swpc.noaa.gov/json/goes/primary/magnetometers-1-day.json';
const API_LATEST     = '/api/solar-wind/latest';
const API_DST        = '/api/noaa/dst';

// ── Pure parse helpers (node-testable) ───────────────────────────────────────

/** NOAA fill sentinels → null; numbers otherwise. */
export function noaaNum(raw) {
    if (raw == null || raw === '') return null;
    const n = Number(raw);
    if (!Number.isFinite(n)) return null;
    if (n <= -9990 || n > 1e20) return null;
    return n;
}

/** "YYYY-MM-DD HH:MM:SS(.ms)" (no tz) → epoch ms, or null. */
export function noaaTimeMs(tag) {
    if (!tag) return null;
    const ms = Date.parse(String(tag).replace(' ', 'T').replace(/Z?$/, 'Z'));
    return Number.isFinite(ms) ? ms : null;
}

const minuteKey = ms => Math.floor(ms / 60_000) * 60_000;

/**
 * Merge RTSW plasma rows and mag rows into one ascending 1-min driver series
 * [{t, v, n, temp, bz, bt}]. Rows join on their UTC minute; plasma-only
 * minutes keep bz = null (the model holds the last valid driver across gaps).
 */
export function mergeDriverSeries(windRows, magRows) {
    const byMin = new Map();
    for (const r of Array.isArray(windRows) ? windRows : []) {
        const t = noaaTimeMs(r?.time_tag);
        if (t == null) continue;
        const v = noaaNum(r.proton_speed ?? r.speed);
        if (v == null || v <= 0) continue;
        byMin.set(minuteKey(t), {
            t: minuteKey(t),
            v,
            n:    noaaNum(r.proton_density ?? r.density),
            temp: noaaNum(r.proton_temperature ?? r.temperature),
            bz: null, bt: null, bx: null, by: null,
        });
    }
    for (const r of Array.isArray(magRows) ? magRows : []) {
        const t = noaaTimeMs(r?.time_tag);
        if (t == null) continue;
        const row = byMin.get(minuteKey(t));
        if (!row) continue;
        row.bz = noaaNum(r.bz_gsm ?? r.bz ?? r.bz_gse);
        row.bt = noaaNum(r.bt);
        row.bx = noaaNum(r.bx_gsm ?? r.bx);
        row.by = noaaNum(r.by_gsm ?? r.by);   // Newell coupling needs By
    }
    return [...byMin.values()].sort((a, b) => a.t - b.t);
}

/**
 * kyoto-dst.json → ascending [{t, dst}]. NOAA ships either object rows or a
 * 2-D array with a header row — handle both (mirrors api/noaa/dst.js).
 */
export function parseKyotoDst(raw) {
    if (!Array.isArray(raw) || raw.length === 0) return [];
    const fill = v => {
        const n = noaaNum(v);
        return n == null || Math.abs(n) > 1000 ? null : n;
    };
    let rows;
    if (typeof raw[0] === 'object' && !Array.isArray(raw[0])) {
        rows = raw.map(r => ({ t: noaaTimeMs(r?.time_tag), dst: fill(r?.dst ?? r?.dst_index) }));
    } else {
        const head = raw[0].map(String);
        const ti = head.indexOf('time_tag'), di = head.indexOf('dst');
        rows = raw.slice(1).map(r => ({ t: noaaTimeMs(r[ti]), dst: fill(r[di]) }));
    }
    return rows.filter(r => r.t != null && r.dst != null).sort((a, b) => a.t - b.t);
}

/** planetary_k_index_1m.json → latest finite Kp, or null. */
export function parseLatestKp(raw) {
    if (!Array.isArray(raw)) return null;
    for (let i = raw.length - 1; i >= 0; i--) {
        const kp = noaaNum(raw[i]?.estimated_kp ?? raw[i]?.kp_index ?? raw[i]?.kp);
        if (kp != null && kp >= 0 && kp <= 9) return kp;
    }
    return null;
}

/**
 * GOES magnetometers-1-day.json → ascending [{t, hp, sat}]. Hp is the field
 * component parallel to Earth's rotation axis at GEO — the component the ring
 * current depresses. Rows flagged `arcjet_flag` (thruster firings contaminate
 * the magnetometer) and fill values are dropped. Field names tolerate NOAA's
 * historical case drift (Hp / hp), like every other parser in this file.
 */
/**
 * Latest reading from a GOES integral-flux feed (xrays / integral-protons /
 * integral-electrons 1-day JSON): rows carry { time_tag, flux, energy };
 * pick the newest finite flux whose energy field matches. Returns
 * { t, flux } or null. Powers the Situation panel's NOAA R/S scales and
 * the GEO charging tier — parsing kept pure for the node tests.
 */
export function parseLatestFlux(raw, energyRe) {
    if (!Array.isArray(raw)) return null;
    let best = null;
    for (const r of raw) {
        if (!energyRe.test(String(r?.energy ?? ''))) continue;
        const t = noaaTimeMs(r?.time_tag);
        const flux = noaaNum(r?.flux);
        if (t == null || flux == null || flux < 0) continue;
        if (!best || t > best.t) best = { t, flux };
    }
    return best;
}

export function parseGoesMag(raw) {
    if (!Array.isArray(raw)) return [];
    const out = [];
    for (const r of raw) {
        if (r?.arcjet_flag === true || r?.arcjet_flag === 'true') continue;
        const t = noaaTimeMs(r?.time_tag);
        const hp = noaaNum(r?.Hp ?? r?.hp);
        if (t == null || hp == null || Math.abs(hp) > 600) continue;   // |Hp| > 600 nT: fill/garbage at GEO
        const sat = Number(r?.satellite);
        out.push({ t, hp, sat: Number.isFinite(sat) ? sat : null });
    }
    return out.sort((a, b) => a.t - b.t);
}

/**
 * In-situ cross-check of the model against the GOES field at GEO.
 *
 * A growing ring current depresses Hp below its daily baseline; quiet times
 * sit near it. This is an INDEPENDENT NOAA measurement — never an input to
 * the model — so agreement is evidence, not circularity. It is deliberately
 * qualitative: Hp at GEO also carries magnetopause-compression and tail
 * currents and swings with the satellite's local time, so disagreement is
 * reported as 'mixed', not as an error.
 *
 * @param {Array<{t,hp,sat}>} series  ≥ 2 h of samples required (else null)
 * @param {number|null} dstModel      current model Dst (nT)
 * @param {number} nowMs
 * @returns {{hp, dHp, medianHp, sat, ageMin, verdict} | null}
 */
export function goesCrossCheck(series, dstModel, nowMs) {
    if (!Array.isArray(series) || series.length < 120) return null;
    const last = series[series.length - 1];
    const sorted = series.map(s => s.hp).sort((a, b) => a - b);
    const medianHp = sorted[Math.floor(sorted.length / 2)];
    const dHp = last.hp - medianHp;
    const ageMin = Math.round((nowMs - last.t) / 60_000);

    const depressed = dHp <= -12;
    const nearBase  = Math.abs(dHp) < 12;
    const storming  = Number.isFinite(dstModel) && dstModel <= -30;
    let verdict;
    if (storming && depressed)       verdict = 'consistent-storm';   // both see a depressed field
    else if (!storming && nearBase)  verdict = 'consistent-quiet';   // both quiet
    else                             verdict = 'mixed';              // local-time / compression effects
    return { hp: last.hp, dHp, medianHp, sat: last.sat, ageMin, verdict };
}

/** Linear interpolation of the observed Dst series at time t (ms). */
export function observedDstAt(series, t) {
    if (!Array.isArray(series) || !series.length) return null;
    if (t <= series[0].t) return series[0].dst;
    for (let i = 1; i < series.length; i++) {
        if (series[i].t >= t) {
            const a = series[i - 1], b = series[i];
            const f = (t - a.t) / Math.max(1, b.t - a.t);
            return a.dst + f * (b.dst - a.dst);
        }
    }
    return series[series.length - 1].dst;
}

/**
 * Run the full model pipeline from raw ingredients. Pure — exported for
 * node tests and for hindcast reuse.
 *
 * @returns {object|null} state (see emit shape below) or null if inputs
 *          are insufficient to anchor the model.
 */
export function computeState(driverSeries, observedDst, kp, nowMs, f107 = null) {
    if (!driverSeries?.length || !observedDst?.length) return null;

    // Earth-arrival time base: the trailing samples haven't arrived yet —
    // they ARE the forecast window.
    const propagated = propagateToEarth(driverSeries)
        .map(s => ({ t: s.tArrive, tL1: s.t, v: s.v, n: s.n, bz: s.bz, bt: s.bt, temp: s.temp }));

    const dst0 = observedDstAt(observedDst, propagated[0].t);
    if (!Number.isFinite(dst0)) return null;

    // Anchor ONCE at window start, then free-run (skill would be fake
    // otherwise). The ensemble adds the (a, τ) parameter-sensitivity band
    // operators need for conjunction work (see RING_CURRENT_USER_RESEARCH.md).
    const { central: track, band } = integrateDstEnsemble(propagated, dst0);
    if (!track.length) return null;

    const arrived  = track.filter(p => p.t <= nowMs);
    const forecast = track.filter(p => p.t > nowMs);
    const nowPt    = arrived.length ? arrived[arrived.length - 1] : track[0];

    const obsWindow = observedDst.filter(o => o.t >= propagated[0].t - 30 * 60_000);
    const modelSkill = skill(arrived, obsWindow);

    // The Sun→Earth bridge: parcels measured at L1 that have NOT yet arrived.
    // These are real matter in transit — the physical content of the forecast
    // window, rendered as the incoming stream on the 3D twin.
    const parcels = propagated
        .filter(p => p.t > nowMs)
        .map(p => ({ tArrive: p.t, tL1: p.tL1, v: p.v, n: p.n, bz: p.bz, bt: p.bt, temp: p.temp }));
    let strongest = null;
    for (const p of parcels) {
        const pv = couplingVBs(p.v, p.bz);
        if (pv != null && (!strongest || pv > strongest.vbs)) {
            strongest = { vbs: pv, bz: p.bz, v: p.v, etaMin: Math.round((p.tArrive - nowMs) / 60_000) };
        }
    }

    const obsNow  = observedDst[observedDst.length - 1];
    const asym    = asymmetry(nowPt.vbs);

    return {
        updated: nowMs,
        window:  { startMs: propagated[0].t, endMs: track[track.length - 1].t },
        drivers: {
            v:  latestValid(driverSeries, 'v'),
            n:  latestValid(driverSeries, 'n'),
            bz: latestValid(driverSeries, 'bz'),
            bt: latestValid(driverSeries, 'bt'),
            by: latestValid(driverSeries, 'by'),
            vbs:  nowPt.vbs,
            pdyn: nowPt.pdyn,
        },
        now: {
            dstModel:     nowPt.dst,
            dstStarModel: nowPt.dstStar,
            dstObserved:  obsNow?.dst ?? null,
            dstObservedAt: obsNow?.t ?? null,
            energyJ:      dpsEnergyJ(nowPt.dstStar),
            injectionQ:   nowPt.q,
            tauHours:     nowPt.tau,
            decayRate:    nowPt.tau > 0 ? -nowPt.dstStar / nowPt.tau : 0,
            storm:        stormClass(obsNow?.dst ?? nowPt.dst),
            stormModel:   stormClass(nowPt.dst),
            peakL:        ringPeakL(nowPt.dstStar),
            asymmetry:    asym,
            oxygenFraction: oxygenFraction(nowPt.dstStar),
            // Charge-exchange lifetimes of a reference 50 keV ion at the
            // current peak shell — the live "how fast is the ring dying"
            // number (O⁺ ≪ H⁺ = the two-phase recovery).
            ceLifetimeH50: chargeExchangeLifetimeHours(50, ringPeakL(nowPt.dstStar), 'ion'),
            ceLifetimeO50: chargeExchangeLifetimeHours(50, ringPeakL(nowPt.dstStar), 'oxygen'),
            // Live Sun–Earth geometry (what the 3D twin's Earth/dipole track).
            subsolar:       subsolarPoint(nowMs),
            dipoleTiltDeg:  dipoleTiltRad(nowMs) * 180 / Math.PI,
            // Shue (1998) magnetopause — the live boundary condition the
            // twin's corridor, wind sheet, and sheath river all follow.
            magnetopause: {
                r0:    shueStandoffRe(nowPt.pdyn, latestValid(driverSeries, 'bz')),
                alpha: shueAlpha(nowPt.pdyn, latestValid(driverSeries, 'bz')),
            },
            plasmapauseL: plasmapauseL(kp),
            kp,
            apNow:        kpToAp(kp),
            f107,
            // Emission→reception ledger: ballistic back-mapping of the wind
            // Earth is receiving NOW to its solar departure. Photons take
            // 8.3 min; this plasma took days — and the lag disperses with
            // speed, so one solar moment arrives smeared over ~1.5 days
            // (the paper question the HUD + L1 gate label surface).
            sunLag: (() => {
                const v = latestValid(driverSeries, 'v');
                const dep = sunDepartureMs(nowMs, v);
                return {
                    departureMs:  dep,
                    days:         dep != null ? (nowMs - dep) / 86.4e6 : null,
                    lightMin:     SOLAR.LIGHT_LAG_MIN,
                    spiralDeg:    parkerSpiralDeg(v),
                    sourceRotDeg: sourceRotationDeg(v),
                };
            })(),
        },
        // Predictive alert: first forecast crossing of the next storm-class
        // threshold — genuine lead time (the driver is already measured at L1).
        alert: (() => {
            const x = findThresholdCrossing(nowPt.dst, forecast);
            return x ? { ...x, etaMin: Math.round((x.t - nowMs) / 60_000) } : null;
        })(),
        series: {
            model:    arrived.map(p => ({ t: p.t, dst: p.dst, dstStar: p.dstStar })),
            forecast: forecast.map(p => ({ t: p.t, dst: p.dst, dstStar: p.dstStar })),
            observed: obsWindow,
            // Parameter-sensitivity band, forecast window + trailing 3 h.
            band: band.filter(b => b.t > nowMs - 3 * 3.6e6),
        },
        skill: modelSkill,
        transit: { parcels, strongest },
        forecastLeadMin: forecast.length
            ? Math.round((forecast[forecast.length - 1].t - nowMs) / 60_000)
            : 0,
    };
}

/**
 * /api/omni/imf columnar payload → replay ingredients for historical event
 * hindcasts (e.g. the May 2024 Gannon G5). SYM-H is the 1-min-resolution
 * equivalent of Dst, so it slots directly into the observed series.
 * Pure — node-tested; the page's replay mode is just
 * computeState(drivers, observed, kp, endMs) over this output.
 *
 * @returns {{drivers: Array<{t,v,n,bz}>, observed: Array<{t,dst}>} | null}
 */
export function omniToReplay(payload) {
    const d = payload?.data;
    if (!Array.isArray(d?.t) || !d.t.length) return null;
    const drivers = [], observed = [];
    for (let i = 0; i < d.t.length; i++) {
        const t = Date.parse(d.t[i]);
        if (!Number.isFinite(t)) continue;
        const v = Number(d.v?.[i]), n = Number(d.np?.[i]), bz = Number(d.bz_gsm?.[i]);
        if (Number.isFinite(v) && v > 100 && v < 3000) {
            drivers.push({
                t, v,
                n:  Number.isFinite(n)  ? n  : null,
                bz: Number.isFinite(bz) ? bz : null,
            });
        }
        const sym = Number(d.sym_h?.[i]);
        if (Number.isFinite(sym) && Math.abs(sym) < 1000) observed.push({ t, dst: sym });
    }
    return drivers.length && observed.length ? { drivers, observed } : null;
}

/**
 * Historical-event hindcast state (e.g. Gannon May 2024). Unlike live
 * computeState this does NOT ballistically propagate: OMNI HRO drivers are
 * already time-shifted to the bow shock nose, so re-propagating would
 * double-shift by ~40–60 min. Anchors once on the first observed value,
 * free-runs the ensemble, scores against the full observed series.
 */
export function computeReplayState(drivers, observed, label = 'replay') {
    if (!drivers?.length || !observed?.length) return null;
    const dst0 = observedDstAt(observed, drivers[0].t);
    const { central: track, band } = integrateDstEnsemble(drivers, dst0);
    if (!track.length) return null;
    let peak = track[0];
    for (const p of track) if (p.dst < peak.dst) peak = p;
    let obsPeak = observed[0];
    for (const o of observed) if (o.dst < obsPeak.dst) obsPeak = o;
    return {
        label,
        updated: track[track.length - 1].t,
        window:  { startMs: track[0].t, endMs: track[track.length - 1].t },
        series: {
            model:    track.map(p => ({ t: p.t, dst: p.dst, dstStar: p.dstStar })),
            forecast: [],
            observed,
            band,
        },
        skill: skill(track, observed),
        peak: { model: { t: peak.t, dst: peak.dst }, observed: { t: obsPeak.t, dst: obsPeak.dst } },
    };
}

function latestValid(series, field) {
    for (let i = series.length - 1; i >= 0; i--) {
        const x = series[i][field];
        if (Number.isFinite(x)) return x;
    }
    return null;
}

// ── Live feed ────────────────────────────────────────────────────────────────

async function getJson(url, timeoutMs = 15_000) {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), timeoutMs);
    try {
        const res = await fetch(url, { signal: ctrl.signal, headers: { Accept: 'application/json' } });
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        return await res.json();
    } finally {
        clearTimeout(timer);
    }
}

export class RingCurrentFeed extends EventTarget {
    constructor() {
        super();
        this._drivers  = [];      // merged 1-min series (L1 time base)
        this._observed = [];      // [{t, dst}]
        this._kp       = null;
        this._f107     = null;    // daily F10.7 (sfu) for the density panel
        this._goes     = [];      // GOES Hp series (GEO in-situ cross-check)
        this._holes    = [];      // HEK coronal holes (wind source attribution)
        this._cmes     = [];      // DONKI cone analyses (in-flight CME layer)
        this._timers   = {};
        this._mode     = 'full';  // 'full' | 'degraded'
        this._started  = false;
        this._errors   = [];
        this._worker   = null;    // module worker running computeState
        this._workerBroken = false;
        this._reqId    = 0;       // latest-wins token for worker replies
    }

    async start() {
        if (this._started) return;
        this._started = true;
        this._startWorker();

        await this._fullSync();

        this._timers.t1 = setInterval(() => this._tick(() => this._appendLatest()), INTERVALS.T1);
        // Guaranteed update loop: recompute + emit every 30 s regardless of
        // fetch outcomes — the forecast window, transit set, and model "now"
        // all advance with wall time even when upstreams are quiet/failing.
        this._timers.emit = setInterval(() => {
            if (typeof document === 'undefined' || !document.hidden) this._emit();
        }, 30_000);
        this._timers.t2 = setInterval(() => this._tick(() => this._refreshKp()),    INTERVALS.T2);
        this._timers.t3 = setInterval(() => this._tick(() => this._fullSync()),     INTERVALS.T3);

        // API hygiene: no polling while the tab is hidden; catch up on return.
        if (typeof document !== 'undefined') {
            document.addEventListener('visibilitychange', () => {
                if (!document.hidden) this._tick(() => this._fullSync());
            });
        }
    }

    stop() {
        for (const t of Object.values(this._timers)) clearInterval(t);
        this._timers = {};
        this._started = false;
        this._worker?.terminate();
        this._worker = null;
    }

    /**
     * The 30 s model tick (ballistic propagation + 5-member OBM ensemble
     * over 24 h of 1-min drivers) runs in js/ring-current-worker.js so the
     * UI thread never stalls. The worker imports THIS module's computeState,
     * so the physics cannot drift between threads. Any failure — no Worker
     * API, module-worker unsupported, runtime error — flips to inline
     * compute permanently (same function, same result, just on-thread).
     */
    _startWorker() {
        if (this._worker || this._workerBroken) return;
        try {
            if (typeof Worker === 'undefined') throw new Error('no Worker API');
            this._worker = new Worker(
                new URL('./ring-current-worker.js', import.meta.url), { type: 'module' });
            this._worker.onmessage = (e) => {
                const m = e.data;
                if (m?.id !== this._reqId) return;      // stale — newer request in flight
                if (!m.ok) { this._workerFail(new Error(m.error)); return; }
                this._dispatch(m.state);
            };
            this._worker.onerror = (e) => this._workerFail(e?.error ?? new Error(e?.message || 'worker error'));
        } catch (e) {
            this._workerFail(e);
        }
    }

    _workerFail(e) {
        this._noteError(e);
        this._worker?.terminate();
        this._worker = null;
        this._workerBroken = true;
        this._emit();   // re-emit inline so the pending tick isn't lost
    }

    async _tick(fn) {
        if (typeof document !== 'undefined' && document.hidden) return;
        try { await fn(); } catch (e) { this._noteError(e); }
    }

    _noteError(e) {
        this._errors.push({ t: Date.now(), message: String(e?.message || e) });
        if (this._errors.length > 20) this._errors.shift();
    }

    /** Full re-sync: 24 h RTSW wind+mag + Kyoto Dst (+Kp on first run). */
    async _fullSync() {
        let windRows = null, magRows = null;
        try {
            [windRows, magRows] = await Promise.all([
                getJson(NOAA.wind),
                getJson(NOAA_MAG_URL).catch(e => { this._noteError(e); return []; }),
            ]);
        } catch (e) {
            this._noteError(e);
        }

        if (Array.isArray(windRows) && windRows.length) {
            this._drivers = mergeDriverSeries(windRows, magRows);
            this._mode = 'full';
        } else {
            // Degraded: 60-min window from the Supabase cache.
            try {
                const alt = await getJson(`${API_LATEST}?series=1`);
                const series = alt?.data?.series || [];
                this._drivers = series.map(r => ({
                    t: Date.parse(r.timestamp),
                    v: r.speed_km_s, n: r.density_cc, bz: r.bz_nT, bt: r.bt_nT, temp: null,
                })).filter(r => Number.isFinite(r.t) && Number.isFinite(r.v))
                  .sort((a, b) => a.t - b.t);
                this._mode = 'degraded';
            } catch (e) {
                this._noteError(e);
            }
        }

        try {
            this._observed = parseKyotoDst(await getJson(NOAA.dst));
        } catch (e) {
            this._noteError(e);
            // Degraded: recent readings via the edge proxy.
            try {
                const alt = await getJson(API_DST);
                this._observed = (alt?.data?.recent || []).map(r => ({
                    t: Date.parse(r.timestamp), dst: r.dst_nT,
                })).filter(r => Number.isFinite(r.t) && Number.isFinite(r.dst));
            } catch (e2) { this._noteError(e2); }
        }

        if (this._kp == null) await this._refreshKp().catch(e => this._noteError(e));

        // F10.7 (daily cadence — T3 refresh is generous) via our own
        // normalized edge endpoint; drives the thermosphere density panel.
        try {
            const rf = await getJson('/api/noaa/radio-flux');
            const sfu = rf?.data?.current?.flux_sfu;
            if (Number.isFinite(sfu) && sfu > 40 && sfu < 500) this._f107 = sfu;
        } catch (e) { this._noteError(e); }

        // GOES magnetometer (GEO cross-check). Best-effort: a failure keeps
        // the previous series; the check panel just goes stale/dashes.
        try {
            const goes = parseGoesMag(await getJson(NOAA_GOES_MAG_URL));
            if (goes.length) this._goes = goes;
        } catch (e) { this._noteError(e); }

        // HEK coronal-hole catalog (30-min upstream cache) — the real solar
        // imagery the back-mapped wind source is matched against. Best-
        // effort: on failure the ledger still carries coordinates, just no
        // structure attribution.
        try {
            const ch = await getJson('/api/hek/coronal-holes');
            if (Array.isArray(ch?.data?.holes)) this._holes = ch.data.holes;
        } catch (e) { this._noteError(e); }

        // DONKI CME cone analyses (NASA key stays server-side) — the raw
        // material for the IN-FLIGHT layer: matter genuinely between the
        // Sun and L1 right now, with hours-to-days of real lead time.
        // Best-effort; _dispatch turns these into live transit states.
        try {
            const cm = await getJson('/api/donki/cme?days=5');
            if (Array.isArray(cm?.data?.cmes)) this._cmes = cm.data.cmes;
        } catch (e) { this._noteError(e); }

        this._emit();
    }

    /** T1 append: one cached row from the Supabase-backed edge endpoint. */
    async _appendLatest() {
        const body = await getJson(API_LATEST);
        const cur = body?.data?.current;
        const t = Date.parse(body?.data?.updated || '');
        if (!cur || !Number.isFinite(t) || !Number.isFinite(cur.speed_km_s)) return;
        const key = minuteKey(t);
        const row = {
            t: key, v: cur.speed_km_s, n: cur.density_cc ?? null,
            bz: cur.bz_nT ?? null, bt: cur.bt_nT ?? null,
            bx: cur.bx_nT ?? null, by: cur.by_nT ?? null,
            temp: cur.temperature_K ?? null,
        };
        const last = this._drivers[this._drivers.length - 1];
        if (last && last.t === key) this._drivers[this._drivers.length - 1] = row;
        else if (!last || key > last.t) this._drivers.push(row);
        this._emit();
    }

    async _refreshKp() {
        this._kp = parseLatestKp(await getJson(NOAA.kp1m));
    }

    _emit() {
        if (this._worker && !this._workerBroken) {
            this._worker.postMessage({
                id: ++this._reqId, type: 'state',
                drivers: this._drivers, observed: this._observed,
                kp: this._kp, nowMs: Date.now(), f107: this._f107,
            });
            return;   // _dispatch fires on the worker's reply (latest-wins)
        }
        this._dispatch(computeState(this._drivers, this._observed, this._kp, Date.now(), this._f107));
    }

    _dispatch(state) {
        const goes = goesCrossCheck(this._goes, state?.now?.dstModel ?? null, Date.now());
        const compute = this._worker && !this._workerBroken ? 'worker' : 'inline';
        // Source mapping (main thread — needs this._holes, which the worker
        // doesn't carry): the wind arriving now was on the Earth-facing
        // central meridian at departure, so its source Carrington longitude
        // is L0(departure); its Stonyhurst position TODAY is how far the
        // Sun has since carried it toward the west limb. Then match against
        // the HEK coronal-hole catalog.
        const sl = state?.now?.sunLag;
        if (sl && Number.isFinite(sl.departureMs)) {
            const nowMs = state.updated ?? Date.now();
            const dep = carringtonL0(sl.departureMs);
            const cur = carringtonL0(nowMs);
            sl.carringtonLon    = dep.L0;
            sl.stonyhurstNowDeg = ((dep.L0 - cur.L0) % 360 + 360) % 360;
            sl.l0NowDeg         = cur.L0;
            sl.b0NowDeg         = cur.B0;
            sl.source = attributeWindSource(this._holes, dep.L0, state?.drivers?.v);
            // Each hole decorated with its own measured arrival record
            // (inverse back-mapping over the 24 h driver series): the twin
            // scales each hole's emission activity by what Earth actually
            // received from that hole's longitude. Holes east of the
            // meridian carry assoc: null — their wind hasn't arrived yet.
            sl.holes = holeWindAssociation(this._holes, this._drivers);
            // Recurrence outlook: each hole's next Earth-arrival window
            // (crossing from solar rotation, transit ballistic, speed from
            // the hole's own record — the 27-day persistence technique).
            sl.recurrence = holeArrivalForecast(sl.holes, nowMs).slice(0, 4);
        }
        // In-flight CMEs: Earth-relevant cone analyses currently between
        // the Sun and Earth (fraction < 1.05 keeps just-arrived fronts on
        // screen through their impact). 'Earth-relevant' is looser than
        // strictly earth_directed: cones whose angular miss ≤ half-angle
        // + 20° can still deliver a flank/glancing blow.
        const nowMs2 = state?.updated ?? Date.now();
        const cmes = [];
        for (const c of this._cmes ?? []) {
            const launch = Date.parse(c?.time ?? '');
            const tr = cmeTransit(launch, c?.speed_km_s, nowMs2);
            if (!tr) continue;
            // Preferred ETA: the WSA-ENLIL modeled arrival when DONKI has
            // one (NOAA-grade), else our ballistic estimate. Both are kept
            // — their disagreement is the live cross-check, and the daily
            // cron scores each against the actual shock detection.
            const enlilMs = Date.parse(c?.enlil?.shock_arrival ?? '');
            const hasEnlil = Number.isFinite(enlilMs);
            const etaMs = hasEnlil ? enlilMs : tr.etaMs;
            // Retire once safely past the PREFERRED arrival.
            if (nowMs2 > etaMs + 6 * 3.6e6 && tr.fraction > 1.05) continue;
            const miss = Math.hypot(c.latitude_deg ?? 0, c.longitude_deg ?? 0);
            const relevant = c.earth_directed || c.enlil?.earth_gb ||
                (Number.isFinite(c.half_angle_deg) && miss <= c.half_angle_deg + 20);
            if (!relevant) continue;
            cmes.push({
                ...c, launchMs: launch, transit: tr,
                etaMs,
                basis: hasEnlil ? 'enlil' : 'ballistic',
                enlilEtaMs: hasEnlil ? enlilMs : null,
                ballisticEtaMs: tr.etaMs,
                crossCheckHours: hasEnlil ? (tr.etaMs - enlilMs) / 3.6e6 : null,
                glancing: !c.earth_directed,
            });
        }
        cmes.sort((a, b) => a.etaMs - b.etaMs);
        if (state) state.cmes = cmes.slice(0, 4);
        this.dispatchEvent(new CustomEvent('state', {
            detail: state ? { ...state, goes, compute, mode: this._mode, errors: this._errors.slice(-3) }
                          : { goes, compute, mode: this._mode, errors: this._errors.slice(-3), updated: Date.now() },
        }));
    }
}
