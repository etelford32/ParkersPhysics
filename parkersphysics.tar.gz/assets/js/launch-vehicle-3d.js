/**
 * launch-vehicle-3d.js — High-fidelity procedural 3D launch vehicle canvas.
 *
 * Renders a generic stack — currently the Space Shuttle Transportation System
 * (orbiter + external tank + 2 SRBs + pad) — built entirely from THREE
 * primitives so we don't depend on any external GLB/OBJ asset. Intended as a
 * placeholder until we secure permission to use operator-supplied vehicle
 * models.
 *
 * Approximately to-scale (1 unit ≈ 1 m):
 *   External Tank   46.9 m × 8.4 m diameter
 *   SRB             45.5 m × 3.7 m diameter (×2)
 *   Orbiter         37.2 m × 23.8 m wingspan, 17.3 m tail height
 *
 * Visual features beyond the stack itself (2026-11 overhaul):
 *   · Floodlit night pad: xenon SPOT key (soft PCF shadows), sodium fill,
 *     cool rim, sky/ground hemisphere; volumetric floodlight beams
 *   · Night-sky dome + magnitude-distributed stars + terrain/treeline and a
 *     floodlight-panel reflection environment (js/launch-scene-fx.js)
 *   · Engine flame as a point light; shader plumes (js/launch-plume.js)
 *   · Lit, sorted smoke / ground-cloud / deluge-steam sprites
 *     (js/launch-smoke.js over the PURE js/launch-smoke-sim.js)
 *   · Object-space surface detail: Starship weld rings + hex tiles, ET foam
 *   · HDR post: bloom → ACES OutputPass → vignette + dither
 *   · IntersectionObserver pauses the loop when off-screen
 *   · Camera presets (front · side · top · 3-quarter) with smooth tween
 *
 * Public API:
 *   initVehicleCanvas(canvas, opts) →
 *     { dispose, setView, setAutoRotate, setPlume, setPad }
 *
 * `setVehicle()` is reserved for v2 — only the shuttle is implemented today.
 */

import * as THREE from 'three';
import { buildStarship } from './launch-vehicle-starship.js';
import { buildFalcon9 } from './launch-vehicle-falcon9.js';
import { buildPad as buildPadInfra, tickBeacons } from './launch-pad-3d.js';
import { createMissionClock } from './launch-mission-clock.js';
import { ENGINES } from './launch-engines.js';
import { buildThrustOverlay, tickThrustOverlay } from './launch-thrust-overlay.js';
import { buildPlume as buildPlumeShared, tickPlume } from './launch-plume.js';
import { buildEngineBell, buildTankDomeFittings } from './launch-engine-bell.js';
import { HORIZON, buildSky, buildStars, buildTerrain, buildEnvironment,
         createPost, detectQuality, buildLightBeam } from './launch-scene-fx.js';
import { createSmokeSim, stepSmoke, clearSmoke, planEmissions,
         createEmissionCarry, SMOKE_PROFILES } from './launch-smoke-sim.js';
import { createSmokeRenderer } from './launch-smoke.js';
import { addSurfaceDetail, setSurfaceDetailEnabled } from './launch-surface-detail.js';
import { pickDefaultView, framingFor } from './launch-camera-layout.js';

// ── Constants ────────────────────────────────────────────────────────────────

const COLORS = {
    foam:        0xb95f24,   // ET unpainted post-STS-3 foam
    foamDark:    0x8a4516,
    foamLight:   0xd47b3a,
    srbWhite:    0xece8de,
    srbAft:      0x9c9c92,
    srbRing:     0xb6b3a8,
    orbiterWhite:0xf4f1e8,
    tile:        0x141418,
    tileBack:    0x1f1f24,
    cockpit:     0x121723,
    cockpitGlow: 0x88aaff,
    metalDark:   0x4a4a52,
    metalBright: 0x8c8c92,
    nozzle:      0x2c2c30,
    nozzleHot:   0x6a4f30,
    plumeCore:   0xfff5d8,
    plumeMid:    0xffaa44,
    plumeOuter:  0x6a3a18,
    pad:         0x1a1a22,
    tower:       0xcc5022,   // pad gantry orange
    horizon:     0x1a1428,
    deepSpace:   0x02010a,
};

const DIM = {
    ET_LEN:        46.9,
    ET_R:           4.2,
    SRB_LEN:       45.5,
    SRB_R:          1.85,
    ORBITER_LEN:   37.2,
    ORBITER_FUSE_R: 2.4,
    WING_HALF:     11.9,    // wing half-span
    TAIL_H:         5.5,    // vertical-stab height
};

// ── Material factory ─────────────────────────────────────────────────────────

function mkMat(color, opts = {}) {
    return new THREE.MeshStandardMaterial({
        color,
        roughness: opts.roughness ?? 0.62,
        metalness: opts.metalness ?? 0.04,
        emissive:  opts.emissive  ?? 0x000000,
        emissiveIntensity: opts.emissiveIntensity ?? 0.0,
        flatShading: opts.flatShading ?? false,
    });
}

function mkPhys(color, opts = {}) {
    return new THREE.MeshPhysicalMaterial({
        color,
        roughness: opts.roughness ?? 0.4,
        metalness: opts.metalness ?? 0.0,
        clearcoat: opts.clearcoat ?? 0.3,
        clearcoatRoughness: opts.clearcoatRoughness ?? 0.3,
    });
}

// ── External Tank ────────────────────────────────────────────────────────────
// LH2 (lower) tank + intertank ribbed band + LO2 (upper) tank + ogive nose.
// Built as a single Lathe profile so the cross-section is naturally smooth.

function buildExternalTank() {
    const g = new THREE.Group();
    g.name = 'ExternalTank';

    const L = DIM.ET_LEN;
    const R = DIM.ET_R;

    // Profile from base (y=0) to nose (y=L). Slight diameter changes mark the
    // LH2 / intertank / LO2 boundaries; the ogive nose curves from R to 0.
    const pts = [
        new THREE.Vector2(0,           0),
        new THREE.Vector2(R * 0.92,    0),
        new THREE.Vector2(R,           L * 0.02),     // base dome curve
        new THREE.Vector2(R,           L * 0.55),     // top of LH2 tank
        new THREE.Vector2(R * 1.005,   L * 0.57),     // intertank flange
        new THREE.Vector2(R * 1.005,   L * 0.65),
        new THREE.Vector2(R,           L * 0.67),     // bottom of LO2 tank
        new THREE.Vector2(R,           L * 0.86),     // top of LO2 tank cylinder
        new THREE.Vector2(R * 0.95,    L * 0.89),     // ogive transition
        new THREE.Vector2(R * 0.78,    L * 0.93),
        new THREE.Vector2(R * 0.5,     L * 0.97),
        new THREE.Vector2(R * 0.22,    L * 0.99),
        new THREE.Vector2(0,           L),
    ];

    const tank = new THREE.Mesh(
        new THREE.LatheGeometry(pts, 64),
        addSurfaceDetail(mkMat(COLORS.foam, { roughness: 0.92 }), { kind: 'foam' })
    );
    tank.castShadow = true;
    tank.receiveShadow = true;
    g.add(tank);

    // Intertank ribs — vertical stringers around the band region. Cheap
    // detail that sells the ET silhouette.
    const ribGeo = new THREE.BoxGeometry(0.18, L * 0.085, 0.18);
    const ribMat = mkMat(COLORS.foamDark, { roughness: 0.95 });
    for (let i = 0; i < 24; i++) {
        const a = (i / 24) * Math.PI * 2;
        const rib = new THREE.Mesh(ribGeo, ribMat);
        rib.position.set(Math.cos(a) * R * 1.012, L * 0.605, Math.sin(a) * R * 1.012);
        rib.rotation.y = -a;
        rib.castShadow = true;
        g.add(rib);
    }

    // Cable tray — runs full length of the ET on the orbiter side (+Z).
    const trayGeo = new THREE.BoxGeometry(0.7, L * 0.95, 0.22);
    const tray = new THREE.Mesh(trayGeo, mkMat(COLORS.foamDark, { roughness: 0.85 }));
    tray.position.set(0, L * 0.5, R * 1.01);
    tray.castShadow = true;
    g.add(tray);

    // LO2 feedline — runs along the orbiter side, from the intertank up to
    // the LO2 dome. A thin pipe with two elbow boxes selling the routing.
    const feedGeo = new THREE.CylinderGeometry(0.18, 0.18, L * 0.32, 16);
    const feedMat = mkMat(COLORS.foamLight, { roughness: 0.7 });
    const feed = new THREE.Mesh(feedGeo, feedMat);
    feed.position.set(0.6, L * 0.78, R * 1.04);
    feed.castShadow = true;
    g.add(feed);

    // LH2 aft-dome fittings — small central sump, anti-vortex baffle, and
    // the big 17" LH2 feedline outlet that exits on the orbiter side (+Z).
    // The ET's main lathe profile already builds the dome shell; we add
    // just the hardware that hangs off its underside. A smaller pressur-
    // ization-vent stub sits opposite the feedline outlet (−Z side).
    //
    // surfaceY = 0.02 so fittings sit just below the dome lip rather than
    // z-fighting with the lathe at exactly y=0.
    const aftDome = buildTankDomeFittings({
        domeRadius: R * 0.9,
        sumpR:      0.08,                       // small central LH2 outlet
        sumpH:      0.10,
        baffle:     true,
        asymmetricFeed: {
            angle:   Math.PI / 2,               // +Z: orbiter side
            radial:  0.55,                      // 55% of dome radius from axis
            sizeMul: 1.8,                       // 17" feedline is conspicuously fat
        },
        pressurizationPort: {
            angle:   -Math.PI / 2,              // -Z: opposite the feedline
            radial:  0.6,
        },
        surfaceY: () => 0.02,
    });
    g.add(aftDome);

    return g;
}

// ── Solid Rocket Booster ─────────────────────────────────────────────────────
// 5-segment casing + ogive nose cone + aft skirt with attach struts. Joint
// rings highlight the segment seams the way they do on the real article.

function buildSRB() {
    const g = new THREE.Group();
    g.name = 'SRB';

    const L = DIM.SRB_LEN;
    const R = DIM.SRB_R;

    // Casing — single lathe with a slight aft skirt flare and ogive nose.
    const pts = [
        new THREE.Vector2(0,           0),
        new THREE.Vector2(R * 1.18,    0),
        new THREE.Vector2(R * 1.18,    L * 0.025),
        new THREE.Vector2(R,           L * 0.05),
        new THREE.Vector2(R,           L * 0.85),
        new THREE.Vector2(R * 0.92,    L * 0.89),
        new THREE.Vector2(R * 0.7,     L * 0.93),
        new THREE.Vector2(R * 0.4,     L * 0.97),
        new THREE.Vector2(0,           L),
    ];
    const casing = new THREE.Mesh(
        new THREE.LatheGeometry(pts, 36),
        mkMat(COLORS.srbWhite, { roughness: 0.55 })
    );
    casing.castShadow = true;
    casing.receiveShadow = true;
    g.add(casing);

    // Segment joint rings (4 rings dividing the cylindrical body into 5 segs).
    const ringMat = mkMat(COLORS.srbRing, { roughness: 0.5, metalness: 0.2 });
    for (let i = 1; i <= 4; i++) {
        const ring = new THREE.Mesh(
            new THREE.TorusGeometry(R * 1.005, 0.075, 10, 36),
            ringMat
        );
        ring.rotation.x = Math.PI / 2;
        ring.position.y = L * (0.05 + i * 0.16);
        ring.castShadow = true;
        g.add(ring);
    }

    // Aft skirt detail: 3 attach struts protruding from the base (truncated
    // boxes). Visual only — they're meant to read as the hold-down posts.
    const strutMat = mkMat(COLORS.metalDark, { roughness: 0.4, metalness: 0.6 });
    for (let i = 0; i < 3; i++) {
        const a = (i / 3) * Math.PI * 2 + Math.PI / 6;
        const strut = new THREE.Mesh(
            new THREE.BoxGeometry(0.6, 0.8, 0.6),
            strutMat
        );
        strut.position.set(Math.cos(a) * R * 1.18, 0.4, Math.sin(a) * R * 1.18);
        strut.castShadow = true;
        g.add(strut);
    }

    // Forward frustum + parachute compartment — short cylindrical section
    // just below the nose cone, slightly wider than the casing, painted
    // gray to differentiate from the white casing. Real SRB has this band
    // recovering the recovery-system parachutes.
    const frustum = new THREE.Mesh(
        new THREE.CylinderGeometry(R * 1.02, R * 1.02, 1.6, 32, 1, true),
        mkMat(COLORS.srbAft, { roughness: 0.55 })
    );
    frustum.position.y = L * 0.86;
    g.add(frustum);

    // SRB nozzle — exposed bell at the very base. RSRM uses an ablative-
    // cooled conical nozzle (no regen-cooling tubes) but does have a flex-
    // bearing gimbal for thrust vectoring. Shared builder handles both.
    const nozzle = buildEngineBell({
        type:     'rsrm',
        throatR:  R * 0.55,
        exitR:    R * 0.95,
        length:   1.6,
        detail:   'high',     // SRBs are big and prominent on the silhouette
    });
    g.add(nozzle);

    return g;
}

// ── Orbiter ──────────────────────────────────────────────────────────────────
// Lathe fuselage with non-trivial profile, double-delta wings extruded from a
// 2D shape, swept vertical stabilizer, OMS pods, body flap, and a 3-bell SSME
// cluster at the aft. Black thermal-tile underside is a curved overlay shell.

function buildOrbiter() {
    const g = new THREE.Group();
    g.name = 'Orbiter';

    const L = DIM.ORBITER_LEN;
    const R = DIM.ORBITER_FUSE_R;

    // Fuselage profile — half-cylinder then taper to nose. Origin centered
    // along Y (tail at -L/2, nose at +L/2). Slight nose droop is added later
    // by displacing the nose forward (+Z) a touch.
    const fusePts = [
        new THREE.Vector2(0,             -L * 0.50),
        new THREE.Vector2(R * 1.05,      -L * 0.46),
        new THREE.Vector2(R * 1.10,      -L * 0.40),
        new THREE.Vector2(R * 1.05,      -L * 0.20),
        new THREE.Vector2(R * 1.00,       0.0),
        new THREE.Vector2(R * 0.96,       L * 0.20),
        new THREE.Vector2(R * 0.85,       L * 0.32),
        new THREE.Vector2(R * 0.62,       L * 0.40),
        new THREE.Vector2(R * 0.32,       L * 0.46),
        new THREE.Vector2(R * 0.10,       L * 0.49),
        new THREE.Vector2(0,              L * 0.50),
    ];
    const fuselage = new THREE.Mesh(
        new THREE.LatheGeometry(fusePts, 32),
        mkPhys(COLORS.orbiterWhite, { roughness: 0.55, clearcoat: 0.25 })
    );
    fuselage.castShadow = true;
    fuselage.receiveShadow = true;
    g.add(fuselage);

    // Black thermal-tile belly — half-shell on the −Z side (the side facing
    // the ET when stacked, and the side that takes the brunt of reentry
    // heating when flying belly-first). Open arc spans ~140° of the
    // underside, centered on theta = 3π/2 (the −Z direction in CylinderGeometry).
    const bellyArc = 1.55 * Math.PI / 2;
    const bellyMat = mkMat(COLORS.tile, { roughness: 0.95 });
    for (let yFrac = -0.45; yFrac <= 0.45 - 0.001; yFrac += 0.18) {
        const seg = new THREE.Mesh(
            new THREE.CylinderGeometry(R * 1.06, R * 1.06, L * 0.18, 48, 1, true,
                                       3 * Math.PI / 2 - bellyArc / 2, bellyArc),
            bellyMat
        );
        seg.position.y = (yFrac + 0.09) * L;
        seg.castShadow = true;
        g.add(seg);
    }

    // Cockpit hump + windows. Hump: clipped sphere on the +Z (back) side near
    // the nose. Sphere is rotated so its dome curves +Z (up out of fuselage)
    // with the flat opening at -Z; we sit it just above the fuselage spine
    // (z = R*0.85, fuselage radius at this Y is ~R*0.85 along the lathe
    // taper) so the opening hides flush against the spine instead of cutting
    // a seam through the body 1 m below the surface.
    const cockpitR = R * 0.95;
    const cockpit = new THREE.Mesh(
        new THREE.SphereGeometry(cockpitR, 32, 18, 0, Math.PI * 2, 0, Math.PI * 0.55),
        mkMat(COLORS.orbiterWhite, { roughness: 0.5 })
    );
    const cockpitY = L * 0.31;
    cockpit.position.set(0, cockpitY, R * 0.85);
    cockpit.rotation.x = Math.PI / 2;
    cockpit.castShadow = true;
    g.add(cockpit);

    const winMat = new THREE.MeshPhysicalMaterial({
        color: COLORS.cockpit,
        roughness: 0.05,
        metalness: 0.0,
        transmission: 0.0,
        emissive: COLORS.cockpitGlow,
        emissiveIntensity: 0.18,
        clearcoat: 1.0,
        clearcoatRoughness: 0.05,
    });
    // 6 forward windows in two rows of three. Each window sits on the
    // dome's forward-facing surface — z derived from the sphere equation so
    // the panes follow the dome's curve regardless of where we mounted the
    // hump.
    const winGeo = new THREE.BoxGeometry(0.8, 0.55, 0.2);
    for (let row = 0; row < 2; row++) {
        for (let col = -1; col <= 1; col++) {
            const w = new THREE.Mesh(winGeo, winMat);
            const yOff = cockpitY + 0.55 + row * 0.6;
            const xOff = col * 0.95;
            const yFromDome = yOff - cockpitY;
            const zOnDome   = Math.sqrt(
                Math.max(0, cockpitR * cockpitR - yFromDome * yFromDome - xOff * xOff)
            );
            const zPos = R * 0.85 + zOnDome - 0.08;
            w.position.set(xOff, yOff, zPos);
            w.rotation.x = -0.32;          // slight forward rake
            g.add(w);
        }
    }

    // Wings — double-delta planform. Defined as a 2D shape in (X-outboard, Y-fwd)
    // and extruded a small depth for thickness.
    const wingShape = new THREE.Shape();
    wingShape.moveTo(0,    6.0);     // glove leading edge near root
    wingShape.lineTo(2.4,  3.5);     // glove break
    wingShape.lineTo(DIM.WING_HALF, -7.5);   // main-wing leading edge to tip
    wingShape.lineTo(DIM.WING_HALF, -9.0);   // tip chord
    wingShape.lineTo(8.0,           -10.5);
    wingShape.lineTo(0,             -10.5);  // trailing-edge root
    wingShape.lineTo(0,              6.0);

    const wingGeo = new THREE.ExtrudeGeometry(wingShape, {
        depth: 0.6,
        bevelEnabled: true,
        bevelThickness: 0.18,
        bevelSize: 0.18,
        bevelSegments: 2,
    });
    const wingMat = mkPhys(COLORS.orbiterWhite, { roughness: 0.55, clearcoat: 0.15 });
    for (const xSign of [-1, 1]) {
        const wing = new THREE.Mesh(wingGeo, wingMat);
        // Shape lives in XY (x=outboard, y=fwd-aft) extruded in Z (thickness).
        // That already matches our world axes — no rotation needed; just
        // mirror around the orbiter centerline for the port wing.
        wing.scale.x = xSign;
        // Sink the wing slightly below the centerline so it visually sits
        // at the orbiter belly rather than threading through the spine.
        wing.position.set(0, 0, -R * 0.35);
        wing.castShadow = true;
        wing.receiveShadow = true;
        g.add(wing);

        // Black wing leading-edge "RCC" stripe — thin tube traced along the
        // glove + main-wing leading edges for visual contrast.
        const lePts = [
            new THREE.Vector3(0,                                     6.0,  -R * 0.35),
            new THREE.Vector3(2.4 * xSign,                           3.5,  -R * 0.35),
            new THREE.Vector3(DIM.WING_HALF * xSign,                -7.5,  -R * 0.35),
        ];
        const leGeo = new THREE.TubeGeometry(new THREE.CatmullRomCurve3(lePts), 16, 0.14, 6, false);
        const leMesh = new THREE.Mesh(leGeo, mkMat(COLORS.tile, { roughness: 0.7 }));
        leMesh.castShadow = true;
        g.add(leMesh);
    }

    // Vertical stabilizer — swept fin in the YZ plane, root at orbiter top.
    const tailShape = new THREE.Shape();
    tailShape.moveTo(0,            0);
    tailShape.lineTo(2.5,          DIM.TAIL_H);
    tailShape.lineTo(4.5,          DIM.TAIL_H);
    tailShape.lineTo(6.0,          0.5);
    tailShape.lineTo(6.0,          0);
    tailShape.lineTo(0,            0);
    const tailGeo = new THREE.ExtrudeGeometry(tailShape, {
        depth: 0.35,
        bevelEnabled: true, bevelThickness: 0.08, bevelSize: 0.08, bevelSegments: 1,
    });
    const tail = new THREE.Mesh(tailGeo, wingMat);
    // Map shape (chord-x, height-y, thickness-z) → world (chord=Y, height=Z, thickness=X)
    // so the fin's plane sits in YZ, extending outward in +Z from the orbiter spine.
    tail.rotation.set(Math.PI / 2, 0, Math.PI / 2);
    tail.position.set(0, -L * 0.45, R * 0.85);
    tail.castShadow = true;
    g.add(tail);

    // OMS pods — twin elongated bumps at the aft top, flanking the SSMEs.
    // Each pod gets a small black aft thruster cap so the silhouette reads
    // as the real OMS/RCS bays rather than a smooth blob.
    for (const xSign of [-1, 1]) {
        const oms = new THREE.Mesh(
            new THREE.CapsuleGeometry(0.85, 3.4, 8, 16),
            mkMat(COLORS.orbiterWhite, { roughness: 0.5 })
        );
        oms.rotation.x = Math.PI / 2;
        oms.position.set(xSign * 1.7, -L * 0.40, R * 0.5);
        oms.castShadow = true;
        g.add(oms);

        const omsCap = new THREE.Mesh(
            new THREE.CylinderGeometry(0.55, 0.7, 0.5, 14),
            mkMat(COLORS.tile, { roughness: 0.85 })
        );
        omsCap.rotation.x = Math.PI / 2;
        omsCap.position.set(xSign * 1.7, -L * 0.46 + 0.3, R * 0.5);
        omsCap.castShadow = true;
        g.add(omsCap);
    }

    // Aft thermal-blanket band — distinctive dark band wrapping the orbiter
    // aft just forward of the SSME cluster. Sells the silhouette as the
    // real STS rather than a generic white-fuselage.
    const aftBand = new THREE.Mesh(
        new THREE.CylinderGeometry(R * 1.025, R * 1.025, 1.6, 48, 1, true),
        mkMat(COLORS.tile, { roughness: 0.9 })
    );
    aftBand.position.y = -L * 0.43;
    aftBand.castShadow = true;
    g.add(aftBand);

    // Body flap — fence-like control surface hanging BELOW the SSMEs on the
    // belly side. Position it just outside the fuselage radius (z=-R-0.05)
    // so it actually reads as a flap, not as a slab buried in the spine.
    const bodyFlap = new THREE.Mesh(
        new THREE.BoxGeometry(R * 1.6, 0.4, 1.7),
        mkMat(COLORS.tile, { roughness: 0.85 })
    );
    bodyFlap.position.set(0, -L * 0.46 - 1.2, -R * 0.4);
    bodyFlap.rotation.x = -0.18;     // slight nose-up angle, neutral trim
    bodyFlap.castShadow = true;
    g.add(bodyFlap);

    // Forward RCS module — black thruster ports on the orbiter nose belly
    // (real shuttle has 14 thrusters in the FRCS). Render as 4 small dark
    // squares for the silhouette.
    for (const dx of [-0.55, -0.18, 0.18, 0.55]) {
        const port = new THREE.Mesh(
            new THREE.BoxGeometry(0.22, 0.12, 0.22),
            mkMat(COLORS.tile, { roughness: 0.95 })
        );
        port.position.set(dx, L * 0.43, -R * 0.78);
        g.add(port);
    }

    // SSMEs — 3 bell-shaped engines, 1 high-center + 2 lower flanking.
    const ssmePositions = [
        [ 0,    -L * 0.46 + 0.6,  -0.3],
        [-1.2,  -L * 0.46 - 0.4,  -0.3],
        [ 1.2,  -L * 0.46 - 0.4,  -0.3],
    ];
    for (const [dx, dy, dz] of ssmePositions) {
        const ssme = buildSSME();
        ssme.position.set(dx, dy, dz);
        ssme.userData.kind = 'ssme';
        g.add(ssme);
    }

    return g;
}

// ── SSME (Space Shuttle Main Engine) ─────────────────────────────────────────
// Full detail RS-25: Rao-profile bell, 24 regen-cooling tubes wrapping the
// outside, gimbal mount with hydraulic actuators, and the powerhead /
// turbopump block above the throat. Shared builder in launch-engine-bell.js.

function buildSSME() {
    return buildEngineBell({ type: 'rs25', detail: 'high' });
}

// ── Engine plume ────────────────────────────────────────────────────────────
// Wraps the shared plume builder with shuttle-flavored colors. See
// js/launch-plume.js for the shock-diamond + bell-flare implementation.

function buildPlume() {
    return buildPlumeShared({
        coreRadius:  0.4, coreLen:  18,
        midRadius:   0.8, midLen:   26,
        outerRadius: 1.4, outerLen: 36,
        coreColor:  COLORS.plumeCore,
        midColor:   COLORS.plumeMid,
        outerColor: COLORS.plumeOuter,
        name: 'Plume',
    });
}

// The pad-anchored additive trail cylinder and the ten additive steam
// spheres that used to live here were replaced (2026-11) by the lit, sorted
// smoke sprites in js/launch-smoke.js, driven by js/launch-smoke-sim.js.

// ── Stack assembly ───────────────────────────────────────────────────────────

function buildShuttleStack() {
    const stack = new THREE.Group();
    stack.name = 'STS_stack';

    const et = buildExternalTank();
    stack.add(et);

    const srbOffset = DIM.ET_R + DIM.SRB_R + 0.4;
    for (const xSign of [-1, 1]) {
        const srb = buildSRB();
        srb.position.x = xSign * srbOffset;
        srb.userData.kind = 'srb';
        stack.add(srb);
    }

    // Orbiter — long axis = +Y. Local: belly = -Z, cockpit/back = +Z,
    // wingspan = X. Mounted on +Z side of ET so the belly (-Z) faces the ET
    // and the cockpit (+Z) faces the camera-side viewer. No Y-rotation
    // needed — the local frame already matches the desired world frame.
    const orbiter = buildOrbiter();
    // Raise the orbiter so the SSME bell exits clear the MLP deck (deck top
    // sits at world y=4.2, root.position.y=4.2, so the SSME exit at stack
    // y_local needs to clear y=0). With the previous +0.5 m mount offset
    // the lower bells were sinking ~0.3 m into the deck because the deck
    // flame trench is narrower in Z than the orbiter's engine cluster.
    const orbiterY = DIM.ORBITER_LEN * 0.5 + 1.5;
    orbiter.position.set(0, orbiterY, DIM.ET_R + DIM.ORBITER_FUSE_R + 0.4);
    stack.add(orbiter);

    // Attach hardware bridging the 0.4 m gap between the ET and the orbiter
    // belly + the SRBs. The real shuttle has a forward bipod attaching the
    // orbiter to the ET intertank and two aft struts at the orbiter aft;
    // each SRB has a forward attach strut + aft sway brace. We render
    // simplified cylindrical struts so the orbiter and SRBs visibly mate
    // with the ET instead of floating beside it.
    const strutMat   = mkMat(COLORS.metalDark, { roughness: 0.45, metalness: 0.7 });
    const strutGapZ  = DIM.ET_R + 0.05;                        // strut tail at ET surface
    const strutLenZ  = (DIM.ET_R + DIM.ORBITER_FUSE_R + 0.4) - DIM.ET_R - DIM.ORBITER_FUSE_R; // 0.4
    function addOrbiterAttach(yLocal) {
        const strut = new THREE.Mesh(
            new THREE.CylinderGeometry(0.18, 0.18, 0.55, 12),
            strutMat
        );
        strut.rotation.x = Math.PI / 2;                        // along Z
        strut.position.set(0, yLocal, DIM.ET_R + 0.27);
        strut.castShadow = true;
        stack.add(strut);
    }
    addOrbiterAttach(orbiterY +  6.5);   // forward bipod (ET intertank area)
    addOrbiterAttach(orbiterY - 12);     // aft attach upper
    addOrbiterAttach(orbiterY - 15.5);   // aft attach lower

    // SRB forward + aft attach brackets — small cylindrical fittings between
    // each SRB casing and the ET. Forward attach mid-tank, aft attach near
    // the LH2 base. Mirrored on both SRBs.
    const srbStrutLen = (srbOffset) - DIM.ET_R - DIM.SRB_R; // = 0.4
    function addSRBAttach(xSign, yLocal) {
        const strut = new THREE.Mesh(
            new THREE.CylinderGeometry(0.16, 0.16, srbStrutLen + 0.15, 10),
            strutMat
        );
        strut.rotation.z = Math.PI / 2;                        // along X
        const midX = xSign * (DIM.ET_R + (srbStrutLen / 2));
        strut.position.set(midX, yLocal, 0);
        strut.castShadow = true;
        stack.add(strut);
    }
    for (const s of [-1, 1]) {
        addSRBAttach(s, DIM.ET_LEN * 0.55);   // forward attach (mid-stack)
        addSRBAttach(s, DIM.ET_LEN * 0.10);   // aft attach (lower LH2)
    }

    // Plume — one under each SRB, one under the SSME cluster. Positioned at
    // the bell exits in stack-local space so the cones emerge from the right
    // place on the rocket. Stored on userData so the tick loop can flicker
    // all three together.
    const plumes = [];
    for (const xSign of [-1, 1]) {
        const p = buildPlume();
        p.position.set(xSign * srbOffset, -1.7, 0);
        plumes.push(p);
        stack.add(p);
    }
    // SSME bells exit at orbiter-local y = -L*0.46 - 1.9 ≈ -19.0; with the
    // orbiter mounted at stack-y = L*0.5 + 1.5, that puts the cluster exit at
    // stack-y ≈ 1.0. Place the plume's base just below the bells so the cone
    // emerges from the nozzle exit, not somewhere inside the engine.
    const ssmeP = buildPlume();
    ssmeP.position.set(0, 1.0, DIM.ET_R + DIM.ORBITER_FUSE_R + 0.4);
    plumes.push(ssmeP);
    stack.add(ssmeP);

    stack.userData.plumes = plumes;

    return stack;
}

// Sky, stars, terrain, reflection environment and post-processing live in
// js/launch-scene-fx.js (2026-11). The old canvas-gradient background and
// dusk IBL were replaced by a night-sky dome + a floodlit-pad environment.

// ── Camera presets ───────────────────────────────────────────────────────────
// Each preset is a unit-length direction vector from the framing target
// outward to the camera, plus an optional target-Y bias and distance multiplier.
// Distance is computed from the vehicle's actual world-space bounding box
// (so a 56 m shuttle and a 125 m starship are both fit-to-frame), the
// camera FOV, and the canvas aspect — meaning the rocket actually centers
// in the viewport instead of relying on hardcoded fractions.
//
//   targetBias.y  → bbox.center.y + bias * bbox.size.y   (negative aims lower)
//   distMul       → multiply fit-distance for tighter / wider shots

const VIEW_PRESETS = {
    // Default shot. Intentionally NARROW — distMul 1.0 frames the vehicle to
    // fill the viewport (the fit already bakes in 5% padding, so the whole
    // stack stays visible; going below 1.0 starts clipping the nose/bells),
    // at a modest elevation so the pad/tower scaffold stays out of the lower
    // frame. This is the "easily see the vehicle at load" frame. The looser,
    // pulled-back context shot that used to be the default (distMul 1.10) now
    // lives under the `wide` preset (a button), so it no longer silently
    // "takes over" after the canvas finishes laying out.
    // dir = unit vector from target → camera. The previous eye-line (Y 0.22)
    // sat too low — at the rocket-fit distance it framed the pad/tower base
    // across the bottom of the viewport on load. Raise Y to 0.34 to look
    // slightly DOWN onto the stack (tower base drops below frame) and bump
    // distMul to 1.12 for a little extra margin so the whole stack clears the
    // edges after the canvas settles its aspect-ratio/min-height layout.
    threequarter: { dir: [ 0.55, 0.34,  0.82], biasY:  0.00, distMul: 1.12 },
    // Pulled-back establishing shot: shows the full stack plus the pad/tower
    // for context. This is the former default — kept as an explicit option.
    wide:         { dir: [ 0.62, 0.34,  0.85], biasY:  0.06, distMul: 1.65 },
    front:        { dir: [ 0.00, 0.16,  1.00], biasY:  0.00, distMul: 1.02 },
    side:         { dir: [ 1.00, 0.16,  0.00], biasY:  0.00, distMul: 1.02 },
    top:          { dir: [ 0.00, 1.00,  0.001], biasY:  0.00, distMul: 0.85 },
    // Engines preset — bias the look-at toward the booster base. distMul is
    // a fraction of the full-stack fit-distance; we floor it to a meters
    // value below to stop tall stacks from clipping inside the booster skirt.
    closeup:      { dir: [ 0.55, 0.20,  0.78], biasY: -0.48, distMul: 0.28, distMinM: 14, crop: true },
};

// Compute world-space bounding box of just the visible vehicle hardware,
// excluding the engine plume cones (off by default + huge when on) and the
// pad-anchored ascent trail (lives on the scene root).
function computeVehicleBBox(vehicleRoot) {
    vehicleRoot.updateMatrixWorld(true);
    const bbox = new THREE.Box3();
    vehicleRoot.traverse(o => {
        if (!o.isMesh) return;
        // Skip non-rocket helpers so they don't bloat the framing bbox:
        //   Plume         — invisible engine cone, off by default but huge
        //                   when on.
        //   ThrustOverlay — debug arrows that extend ~18 m DOWN from each
        //                   engine. Always added to v.root before bbox is
        //                   computed, and although invisible by default
        //                   their geometry is in the world-bounds traversal.
        //                   Without the skip the Shuttle SRB arrows pushed
        //                   bbox.min.y to ~-16 m, shifting target.y down
        //                   ~13 m and biasing the whole frame toward the
        //                   booster + launch tower.
        //   …Plume       — the match is a SUFFIX: Starship's cones are named
        //                   'StarshipPlume', and an exact 'Plume' test let
        //                   their ~40 m of geometry drag bbox.min.y below
        //                   the ground, which put the Engines close-up
        //                   camera UNDER the terrain looking up at the OLM.
        let p = o;
        while (p) {
            if (/Plume$/.test(p.name) || p.name === 'ThrustOverlay') return;
            p = p.parent;
        }
        bbox.expandByObject(o);
    });
    return bbox;
}

function frameForView(name, vehicle, fovDeg, aspect) {
    const preset = VIEW_PRESETS[name] || VIEW_PRESETS.threequarter;
    let bbox = vehicle.bbox;
    // Degenerate-bbox guard. An empty Box3 has min=+Inf / max=-Inf; left
    // unchecked it makes halfX/halfZ Infinity → dist Infinity → the camera
    // flies to (Inf,Inf,Inf) and the scene renders as a bare pad/tower with
    // no rocket. A near-zero box collapses dist to the floor and parks the
    // camera at ground level inside the launch-tower lattice. Either way the
    // symptom is "camera defaults to staring at the orange tower". Synthesize
    // a sane box from the vehicle's nominal height so framing is always
    // finite and rocket-centred even if the mesh bbox is missing/degenerate.
    const finiteBox = bbox && !bbox.isEmpty() &&
        Number.isFinite(bbox.min.y) && Number.isFinite(bbox.max.y) &&
        Number.isFinite(bbox.min.x) && Number.isFinite(bbox.max.x) &&
        Number.isFinite(bbox.min.z) && Number.isFinite(bbox.max.z) &&
        (bbox.max.y - bbox.min.y) > 1;
    if (!finiteBox) {
        const h     = Math.max(Number(vehicle.height) || 50, 10);
        const baseY = Number(vehicle.basePadY) || 0;
        const r     = Math.max(h * 0.12, 4);
        bbox = new THREE.Box3(
            new THREE.Vector3(-r, baseY,     -r),
            new THREE.Vector3( r, baseY + h,  r),
        );
    }
    const center = bbox.getCenter(new THREE.Vector3());
    const size   = bbox.getSize(new THREE.Vector3());

    // Look-at aimed at the bbox CENTER (x, y, z) so the visible silhouette is
    // screen-centred for every vehicle.
    //
    // This used to be hard-locked to the stack axis (x=0, z=0) on the theory
    // that aiming at the geometric centroid produced a "lopsided" frame for
    // asymmetric stacks. That reasoning was inverted: putting the look-at on
    // the centroid is exactly what centres the visible mass on screen, while
    // forcing it to the axis left genuinely asymmetric stacks shoved to one
    // side. The Shuttle is the clearest case (and the default vehicle) — its
    // orbiter sits ~8.5 m to +Z of the ET, so an axis-locked look-at framed
    // the empty +X side and pushed the whole stack off-centre the instant the
    // page loaded. Symmetric vehicles (Falcon 9, Starship) have center.x/z ≈ 0,
    // so this is a no-op for them; only off-axis stacks move, and they move
    // toward centre. (The old "lopsided" symptom actually came from the
    // ThrustOverlay bloating the bbox — fixed separately in computeVehicleBBox
    // — and from auto-rotate sweeping around an off-axis target; auto-rotate is
    // now off by default and the orbit camera is gone, so neither applies.)
    const target = new THREE.Vector3(
        center.x,
        center.y + preset.biasY * size.y,
        center.z,
    );

    // Analytic seed for the probe-fit bracket below. With the look-at on the
    // bbox centre, the radial half-extents from the target are simply
    // size.x/2 and size.z/2. This only seeds the iterative solver — the probe
    // refines the true fit distance — so it just needs to be in the right
    // ballpark, not exact.
    const halfX = size.x * 0.5;
    const halfZ = size.z * 0.5;
    const halfYV = Math.max(size.y, 1) * 0.5 * 1.05;
    const halfH  = Math.max(halfX, halfZ, 1) * 1.05;

    // Fit the larger of vertical extent and horizontal extent (modulated by
    // canvas aspect) to the viewport. 1.05 = 5 % padding so the silhouette
    // doesn't kiss the frame edge.
    const halfFovV = (fovDeg * Math.PI / 180) / 2;
    const halfFovH = Math.atan(Math.tan(halfFovV) * aspect);
    const distFitV = halfYV / Math.tan(halfFovV);
    const distFitH = halfH  / Math.tan(halfFovH);
    // Analytic seed only. This classic perpendicular fit systematically
    // UNDER-estimates the projected size from an elevated 3/4 angle: the far,
    // low corners of a tall stack swing wider on screen than a flat
    // head-on fit predicts, so distMul≈1 clipped the nose and engine skirt
    // off the top and bottom of the frame. We refine it below.
    let dist = Math.max(distFitV, distFitH);

    const dir = new THREE.Vector3(...preset.dir).normalize();

    // Angle/aspect-correct refinement.
    //
    // Place a probe camera along `dir`, oriented exactly like the live camera,
    // and project the eight bbox corners to NDC. Solve for the smallest
    // distance at which the most-extreme corner sits at FILL of the way to the
    // frame edge — i.e. the whole stack fits with constant padding. This is
    // correct for every vehicle, canvas aspect and view direction, unlike a
    // flat perpendicular fit (which under-shoots from an elevated 3/4 angle
    // and clipped the nose/skirt). Cropping presets (engines close-up) opt out
    // via `preset.crop` and keep the analytic distance so they stay tight on
    // the booster base instead of zooming out to fit the nose.
    if (!preset.crop) {
        const FILL = 0.92;     // most-extreme corner sits 92% of the way out
        const NEAR = 0.1;
        const probe = new THREE.PerspectiveCamera(fovDeg, aspect, NEAR, 1e6);
        // Orient the probe with the SAME yaw/pitch math the live camera uses
        // (see setLookAt + applyCamToThree), not lookAt(): they agree for
        // shallow angles but diverge near straight-down, where lookAt's roll
        // is undefined. Look direction is −dir (the camera sits along +dir
        // from the target and looks back at it).
        const yaw   = Math.atan2(dir.x, dir.z);
        const pitch = THREE.MathUtils.clamp(Math.asin(-dir.y),
                                            -Math.PI / 2 + 0.02, Math.PI / 2 - 0.02);
        probe.rotation.set(pitch, yaw, 0, 'YXZ');
        probe.updateProjectionMatrix();
        const c = new THREE.Vector3();
        // Largest |NDC| over the 8 corners at camera distance d. Returns
        // Infinity if any corner falls at/behind the near plane — that means
        // the camera is too close (or, for a top-down look at a tall stack,
        // sitting inside the vehicle's height), which must read as "too tight"
        // so the solver pushes the camera further out rather than blowing up
        // on the divide-by-≈0 in the perspective projection.
        const maxNdc = (d) => {
            probe.position.copy(target).addScaledVector(dir, d);
            probe.updateMatrixWorld(true);
            let m = 0;
            for (let xi = 0; xi < 2; xi++)
                for (let yi = 0; yi < 2; yi++)
                    for (let zi = 0; zi < 2; zi++) {
                        c.set(xi ? bbox.max.x : bbox.min.x,
                              yi ? bbox.max.y : bbox.min.y,
                              zi ? bbox.max.z : bbox.min.z)
                         .applyMatrix4(probe.matrixWorldInverse);
                        if (c.z > -NEAR) return Infinity;   // at/behind near plane
                        c.applyMatrix4(probe.projectionMatrix);   // → clip, then NDC
                        m = Math.max(m, Math.abs(c.x), Math.abs(c.y));
                    }
            return m;
        };
        // Bracket then bisect for the distance where maxNdc == FILL. maxNdc is
        // monotonically decreasing in d (move back → smaller on screen), so a
        // clean bracket exists. Seed from the analytic estimate.
        let hi = Math.max(dist, NEAR * 10), guard = 0;
        while (maxNdc(hi) > FILL && guard++ < 80) hi *= 1.4;     // grow until it fits
        let lo = hi, g2 = 0;
        while (maxNdc(lo) <= FILL && g2++ < 80) lo *= 0.7;       // shrink until it doesn't
        for (let i = 0; i < 30; i++) {
            const mid = (lo + hi) * 0.5;
            if (maxNdc(mid) <= FILL) hi = mid; else lo = mid;
        }
        dist = hi;
    }

    // distMul tunes the framed shot AFTER the exact fit: 1.0 = fills the
    // frame, >1 pulls back for context (the `wide` preset), <1 tightens.
    dist *= preset.distMul;

    // Floor so we don't punch through the near plane on tiny vehicles. The
    // per-preset distMinM lets the engines close-up stop short of clipping
    // into the booster skirt on tall stacks.
    dist = Math.max(dist, preset.distMinM ?? 8);

    const pos = target.clone().addScaledVector(dir, dist);
    return { pos: pos.toArray(), target: target.toArray(), dist };
}

// Cancellable tween. Returns a handle whose `cancelled = true` short-circuits
// further steps. `getTo` may be a function — re-evaluated each frame so a
// tween can chase a moving destination (used during liftoff so view-switching
// follows the rocket instead of landing on a stale ground-level frame).
function tween(from, getTo, ms, onUpdate, onDone) {
    const start = performance.now();
    const handle = { cancelled: false };
    const fromCopy = from.slice();
    const toFn = typeof getTo === 'function' ? getTo : () => getTo;
    function step(now) {
        if (handle.cancelled) return;
        const t = Math.min(1, (now - start) / ms);
        const e = t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2;   // easeInOutQuad
        const to = toFn();
        const v = fromCopy.map((f, i) => f + (to[i] - f) * e);
        onUpdate(v);
        if (t < 1) requestAnimationFrame(step);
        else if (onDone) onDone();
    }
    requestAnimationFrame(step);
    return handle;
}

// ── Vehicle registry ─────────────────────────────────────────────────────────
// Each vehicle id maps to a builder that returns:
//   { root, plumes, height, info }
// `info` is metadata for the side panel; framework forwards it via the
// `onVehicleChange` callback so the host page can update its stats card.

function buildShuttleVehicle() {
    const root = buildShuttleStack();
    // Internal stack origin already places ET/SRB bases at y=0. The LC-39A
    // pad's MLP top sits at world y = 4.2, so put the stack origin there
    // and the SRB skirts land flush on the deck.
    root.position.y = 4.2;
    const height = DIM.ET_LEN;     // ~47 m; slightly under 56 m stack but
                                   // close enough for camera framing.

    // Thrust at liftoff: 2 SRBs (12.5 MN each) + 3 SSMEs (1.86 MN each) =
    // 30.58 MN. SRBs are the dominant contributor; SSMEs run continuously
    // through ascent while SRBs separate at T+125 s.
    const liftoffKn = 2 * ENGINES.rsrm.sl_kn + 3 * ENGINES.rs_25.sl_kn;
    const massT = 2030;

    // Engine layout — 2 SRBs flanking ET (no gimbal), 3 SSMEs on orbiter
    // aft (gimbal). Coordinates match buildShuttleStack().
    const srbOffset = DIM.ET_R + DIM.SRB_R + 0.4;
    const orbiterZ  = DIM.ET_R + DIM.ORBITER_FUSE_R + 0.4;
    const engineLayout = {
        boosterEngines: [
            { x: -srbOffset, y: -1.7, z: 0, thrust_kn: ENGINES.rsrm.sl_kn,
              gimbal: false, ring: 'srb' },
            { x:  srbOffset, y: -1.7, z: 0, thrust_kn: ENGINES.rsrm.sl_kn,
              gimbal: false, ring: 'srb' },
        ],
        upperEngines: [
            { x:  0,   y: 1.5, z: orbiterZ, thrust_kn: ENGINES.rs_25.sl_kn,
              gimbal: true, ring: 'ssme' },
            { x: -1.2, y: 1.0, z: orbiterZ, thrust_kn: ENGINES.rs_25.sl_kn,
              gimbal: true, ring: 'ssme' },
            { x:  1.2, y: 1.0, z: orbiterZ, thrust_kn: ENGINES.rs_25.sl_kn,
              gimbal: true, ring: 'ssme' },
        ],
    };

    return {
        root,
        plumes: root.userData.plumes,
        height,
        padId: 'lc39a',
        engineLayout,
        info: {
            name:           'Space Shuttle (STS)',
            years:          '1981 — 2011',
            height_m:       '56.1',
            diameter_m:     '8.4 (ET)',
            booster_engines:'2 × RSRM Solid',
            ship_engines:   '3 × RS-25 (SSME)',
            liftoff_mass_t: '2,030',
            leo_payload_t:  '27.5',
            pad:            'KSC LC-39A',
            notes:          '135 missions, ISS construction, Hubble servicing.',
            thrust: {
                liftoff_kn:    liftoffKn,
                liftoff_mn:    liftoffKn / 1000,
                per_engine_kn: ENGINES.rsrm.sl_kn,
                engine_count:  5,
                booster_engine: ENGINES.rsrm.name,
                upper_engine:   ENGINES.rs_25.name,
                propellant:    'APCP (SRB) + LH2/LOX (SSME)',
                twr_initial:   liftoffKn / (massT * 9.80665),
                mass_t:        massT,
                ref_id:        'shuttle',
            },
        },
    };
}

function buildStarshipVehicle(variant = 'v2') {
    const built = buildStarship({ variant });
    // Starship sits on the OLM table at ~21 m above ground.
    built.root.position.y = 21.4;
    built.padId = 'mechazilla';
    if (built.info) built.info.pad = 'SpaceX Stage 0 (Mechazilla)';
    return built;
}

function buildFalcon9Vehicle(variant = 'block5') {
    const built = buildFalcon9({ variant });
    // Falcon 9 sits on a TEL (transporter-erector-launcher) at LC-39A /
    // SLC-40 — pad-deck top is at world y = 4.2 (matches MLP top).
    built.root.position.y = 4.2;
    built.padId = 'falcon_tel';
    if (built.info) built.info.pad = 'KSC LC-39A / CCSFS SLC-40';
    return built;
}

const VEHICLE_BUILDERS = {
    shuttle:   () => buildShuttleVehicle(),
    starship:  (variant) => buildStarshipVehicle(variant || 'v2'),
    falcon9:   (variant) => buildFalcon9Vehicle(variant || 'block5'),
};

// ── Main entry point ─────────────────────────────────────────────────────────

export function initVehicleCanvas(canvas, opts = {}) {
    if (!canvas) throw new Error('initVehicleCanvas: canvas element required');

    const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: true });
    // Pixel ratio LOCKED to 1.
    //
    // On Retina displays setPixelRatio(devicePixelRatio) doubles the canvas
    // drawing buffer (`canvas.width = clientWidth × 2`). That doubled value
    // is what CSS treats as the canvas's intrinsic content size — and any
    // ancestor grid track using plain '1fr' inherits it as a min-content
    // floor and blows past the viewport. minmax(0, 1fr) + contain: layout
    // size in CSS *should* isolate that, but Mac Firefox/Safari leak it
    // through certain ancestor chains in practice (the repeated "canvas
    // takes over" / "canvas overflows right" regression has been this on
    // every prior occurrence). Locking pixelRatio = 1 makes the drawing
    // buffer always equal the CSS display size, so the intrinsic content
    // size matches what the layout expects and the feedback loop is
    // categorically impossible. Slight loss of sharpness on HiDPI is
    // imperceptible for this content; stability is the higher priority.
    renderer.setPixelRatio(1);
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.0;
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    // Render quality: 'high' (MSAA HDR + bloom, full smoke budget), 'low'
    // (software rasteriser: bloom kept, no MSAA, ~40 % smoke), 'off' (WebGL1
    // or ?lpfx=off: direct render, no post). ?lpfx=high|low|off overrides.
    const quality = detectQuality(renderer, typeof location !== 'undefined' ? location.search : '');
    setSurfaceDetailEnabled(renderer.capabilities.isWebGL2);

    const scene = new THREE.Scene();
    // The sky dome (js/launch-scene-fx.js) is the backdrop; this colour only
    // shows for a frame if the dome has not drawn yet. HORIZON is shared by
    // the dome and the fog so distant terrain fogs into the sky behind it.
    scene.background = HORIZON.clone();
    scene.fog = new THREE.FogExp2(HORIZON.clone(), 0.0011);

    // Reflections: the night sky PLUS the floodlight banks a pad vehicle
    // actually mirrors (see buildEnvironment). Built once; freed in dispose().
    const env = buildEnvironment(renderer);
    scene.environment = env.texture;

    const sky = buildSky({ radius: 3000 });
    scene.add(sky.mesh);
    const stars = buildStars({ count: quality === 'high' ? 3600 : 2200, radius: 2600 });
    scene.add(stars.points);
    const terrain = buildTerrain();
    scene.add(terrain.group);

    // Default FOV is intentionally a touch wider than a stills lens (38°
    // ≈ 50 mm equivalent) so the rocket has a sense of presence without
    // looking like a telephoto-flat travel postcard. Cycle via setFOV().
    let cameraFov = 38;
    // Default aspect 16/10 (not 1) matches the host's CSS aspect-ratio, so if
    // the panel mounts collapsed and the very first frame ever paints before
    // the ResizeObserver delivers a real box, it's a sane wide frame rather
    // than a square one. The real aspect is applied the moment a non-zero
    // box exists (see resize()).
    const camera = new THREE.PerspectiveCamera(cameraFov, 16 / 10, 0.5, 8000);

    // ── Lighting ────────────────────────────────────────────────────────────
    // A floodlit night pad: cool xenon key from the camera side (it casts the
    // shadows), a warm sodium fill from the left, a cool rim from behind that
    // separates the silhouette from the sky, and a dim sky/ground hemisphere.
    // Intensities are linear and tuned against the ACES OutputPass.
    const hemi = new THREE.HemisphereLight(0x5a6c96, 0x2a2018, 0.55);
    scene.add(hemi);

    // The key is a SPOT, not a directional light: a floodlight bank throws a
    // POOL — the pad and vehicle bright, the scrub beyond falling off into
    // the night. A directional key lit the whole landscape to the horizon
    // at the same level as the pad, which read as an overcast afternoon.
    // decay 0 so the pool's level is set by `intensity`, its edge by the cone.
    const key = new THREE.SpotLight(0xeef2ff, 3.0, 0, Math.PI / 6, 0.55, 0);
    key.position.set(60, 90, 50);
    key.castShadow = true;
    key.shadow.mapSize.set(quality === 'high' ? 4096 : 2048, quality === 'high' ? 4096 : 2048);
    key.shadow.bias        = -0.00015;
    key.shadow.normalBias  = 0.05;
    key.shadow.radius      = 2.5;
    scene.add(key);

    const fill = new THREE.DirectionalLight(0xffb27a, 0.75);
    fill.position.set(-40, 25, 30);
    scene.add(fill);

    const rim = new THREE.DirectionalLight(0x9ab4ff, 1.1);
    rim.position.set(-20, 40, -80);
    scene.add(rim);

    // Engine flame light — a point light at the cluster exit whose intensity
    // follows throttle (with flicker). It is what turns the pad, the tower and
    // the underside of the ground cloud orange at ignition. No shadows (a
    // point-light cube shadow per frame is not worth it here).
    const flameLight = new THREE.PointLight(0xff9a50, 0, 0, 2);
    flameLight.castShadow = false;
    scene.add(flameLight);

    // ── Smoke / steam sprites (js/launch-smoke*.js) ───────────────────────
    const SMOKE_CAP = quality === 'high' ? 2600 : 1000;
    const smokeSim = createSmokeSim({ capacity: SMOKE_CAP, seed: 20261101 });
    const smokeView = createSmokeRenderer({ capacity: SMOKE_CAP });
    scene.add(smokeView.mesh);
    let smokeCarry = createEmissionCarry();
    const smokeBudget = quality === 'high' ? 1 : 0.4;
    const _nozzleWorld = new THREE.Vector3();
    const _downWorld = new THREE.Vector3();
    const _keyDir = new THREE.Vector3();
    const _flameCol = new THREE.Color();
    const SMOKE_LIGHT = {
        keyColor:  new THREE.Color(0xeef2ff).multiplyScalar(0.9),
        ambTop:    new THREE.Color(0.10, 0.12, 0.18),
        ambBottom: new THREE.Color(0.05, 0.045, 0.04),
        steam:     new THREE.Color(0.86, 0.88, 0.92),
    };
    // Per-propellant colour of what comes OUT: solid-motor Al₂O₃ is bright
    // white, kerolox exhaust a warm grey, methalox nearly clean (and its ground
    // cloud is mostly steam + pad dust).
    const SMOKE_TINTS = {
        shuttle:  { exhaust: new THREE.Color(0.90, 0.89, 0.86), ground: new THREE.Color(0.86, 0.85, 0.82), flame: 0xffa860 },
        falcon9:  { exhaust: new THREE.Color(0.62, 0.58, 0.54), ground: new THREE.Color(0.80, 0.79, 0.77), flame: 0xff9440 },
        starship: { exhaust: new THREE.Color(0.75, 0.78, 0.86), ground: new THREE.Color(0.74, 0.70, 0.64), flame: 0xff8a5a },
    };

    // Post: RenderPass → bloom → ACES OutputPass → vignette + dither.
    const post = createPost(renderer, scene, camera, { quality });

    // ── Mission clock (drives liftoff animation) ──────────────────────────
    const missionClock = createMissionClock();
    let missionActive = false;
    // Thrust-vector overlay state (toggleable; persists across vehicle swaps)
    let vectorsOn = false;
    // Save baseline scene parameters so we can restore after a flight.
    const baseFogColor   = scene.fog.color.clone();
    const baseFogDensity = scene.fog.density;

    // ── Pad (replaced per vehicle in setVehicle) ──────────────────────────
    let padState = { root: null, beacons: [] };

    function swapPad(padId, opts = {}) {
        if (padState.root) {
            scene.remove(padState.root);
            padState.root.traverse(o => {
                if (o.geometry) o.geometry.dispose();
                if (o.material) {
                    const mats = Array.isArray(o.material) ? o.material : [o.material];
                    mats.forEach(m => m.dispose());
                }
            });
        }
        const built = buildPadInfra(padId || 'generic', opts);
        // Lit beacons sit past the bloom threshold (the pad module's default
        // gain of 1 is tuned for the un-bloomed Space Ship Designer view).
        for (const b of built.beacons) b.gain = post.enabled ? 1.6 : 1;
        // Floodlight beams: every pad lamp throws a faint shaft toward the
        // vehicle's mid-height. Parented to the pad root so they fade and
        // dispose with it.
        if (opts.aimY != null) {
            built.root.updateMatrixWorld(true);
            const aim = new THREE.Vector3(0, opts.aimY, 0);
            const lamps = [];
            built.root.traverse(o => { if (o.name === 'Floodlight' && o.userData.lampLocal) lamps.push(o); });
            for (const fl of lamps) {
                const from = fl.localToWorld(new THREE.Vector3(...fl.userData.lampLocal));
                built.root.add(buildLightBeam(from, aim, { intensity: 0.045 }));
            }
        }
        scene.add(built.root);
        padState = built;
    }

    // ── God-mode flight camera ─────────────────────────────────────────────
    // OrbitControls is gone. This is a free-fly camera with FPS-style
    // mouse-look + WASD/QE keyboard, plus snap-to-preset on view buttons.
    //
    // Inputs:
    //   Left-click drag on canvas → mouse-look (yaw + pitch).
    //   W / S                     → forward / back along view direction.
    //   A / D                     → strafe left / right.
    //   Q / E                     → down / up in world Y.
    //   Shift                     → sprint (3× speed).
    //   Mouse wheel on canvas     → smooth dolly along view direction.
    //   Preset buttons / +/− / FOV / recenter → snap or tween to a frame.
    //
    // State held in `cam`:
    //   pos   (Vector3) — camera world position. camera.position is written
    //                     from this each frame.
    //   yaw   (rad)     — rotation around world Y. 0 = looking toward -Z.
    //   pitch (rad)     — rotation around camera X. +ve = looking up.
    //                     Clamped to ±(π/2 − 0.02) so we never gimbal-flip.
    //   keys  (object)  — current pressed state for movement keys.
    //
    // `controls` is kept as a compat shim with .target (Vector3) so the
    // existing liftoff / view-tween code can continue to write to it. The
    // target is the ORBIT ANCHOR: pointer-drag orbits the camera around it and
    // the wheel dollies toward/away from it (radius clamped to min/maxDistance
    // so you can't tunnel through the vehicle). WASD/QE still free-fly cam.pos
    // directly; (yaw, pitch) are kept in sync via setLookAt after each orbit.
    const cam = {
        pos:       new THREE.Vector3(0, 30, 80),
        yaw:       0,
        pitch:     0,
        keys:      Object.create(null),
        dragging:  false,
        lastX:     0,
        lastY:     0,
        moveSpeed: 80,       // m/s base
        sprintMul: 3,
        lookSpeed: 0.003,    // rad/px of orbit drag
        pitchMin: -Math.PI / 2 + 0.02,
        pitchMax:  Math.PI / 2 - 0.02,
    };

    // Latches true the moment the user actually manipulates the free-fly
    // camera (look-drag, wheel-dolly, WASD/QE move). While false, every
    // resize re-auto-frames the current preset; once true, resizes only
    // re-measure (aspect) and leave the user's framing alone. Reset to
    // false on vehicle swap and on explicit preset/recenter so auto-framing
    // resumes for the new shot.
    let userControlledCamera = false;

    const _fwd   = new THREE.Vector3();
    const _right = new THREE.Vector3();
    const _move  = new THREE.Vector3();
    const _orbitOffset = new THREE.Vector3();
    const _spherical   = new THREE.Spherical();

    function camForward(out) {
        return out.set(
            -Math.sin(cam.yaw) * Math.cos(cam.pitch),
             Math.sin(cam.pitch),
            -Math.cos(cam.yaw) * Math.cos(cam.pitch),
        );
    }
    function camRight(out) {
        return out.set(Math.cos(cam.yaw), 0, -Math.sin(cam.yaw)).normalize();
    }
    function setLookAt(targetVec) {
        const dir = new THREE.Vector3().subVectors(targetVec, cam.pos);
        if (dir.lengthSq() < 1e-6) return;
        dir.normalize();
        cam.yaw   = Math.atan2(-dir.x, -dir.z);
        cam.pitch = THREE.MathUtils.clamp(Math.asin(dir.y), cam.pitchMin, cam.pitchMax);
    }
    function applyCamToThree() {
        camera.position.copy(cam.pos);
        camera.rotation.set(cam.pitch, cam.yaw, 0, 'YXZ');
    }

    // Orbit the camera AROUND controls.target (the rocket) by a pixel delta,
    // preserving the current orbit radius. This is the model-viewer drag:
    // the rocket stays centered, the camera swings around it — as opposed to
    // free-look (rotate-in-place), which swings the aim off onto the tower.
    // phi (polar from +Y) is clamped off the poles so we never gimbal-flip.
    function orbitAroundTarget(dx, dy) {
        _orbitOffset.subVectors(cam.pos, controls.target);
        _spherical.setFromVector3(_orbitOffset);
        _spherical.theta -= dx * cam.lookSpeed;
        _spherical.phi   -= dy * cam.lookSpeed;
        const EPS = 0.02;
        _spherical.phi = Math.max(EPS, Math.min(Math.PI - EPS, _spherical.phi));
        _spherical.makeSafe();
        _orbitOffset.setFromSpherical(_spherical);
        cam.pos.copy(controls.target).add(_orbitOffset);
        setLookAt(controls.target);
    }

    // Dolly toward / away from the target by scaling the orbit radius, clamped
    // to [minDistance, maxDistance] so the camera can never fly THROUGH the
    // rocket and end up staring at the tower behind it. factor < 1 = zoom in.
    function dollyToTarget(factor) {
        _orbitOffset.subVectors(cam.pos, controls.target);
        const r = THREE.MathUtils.clamp(
            _orbitOffset.length() * factor,
            controls.minDistance, controls.maxDistance,
        );
        _orbitOffset.setLength(r);
        cam.pos.copy(controls.target).add(_orbitOffset);
        setLookAt(controls.target);
    }

    // Compat shim — old code reads/writes `controls.target` and calls
    // `controls.update()`. We give it a real Vector3 target (for liftoff
    // bookkeeping) and an update() that runs the god-camera tick.
    const controls = {
        target:        new THREE.Vector3(0, 0, 0),
        autoRotate:    false,
        autoRotateSpeed: 0,
        minDistance:   6,
        maxDistance:   2000,
        // Unused fields kept so legacy code doesn't crash if it sets them.
        minAzimuthAngle: -Infinity, maxAzimuthAngle: Infinity,
        minPolarAngle:   0,         maxPolarAngle:   Math.PI,
        enableDamping: false, dampingFactor: 0,
        enableZoom: false, enablePan: false, rotateSpeed: 0,
        _dt: 0,
        update() {
            const dt = this._dt;
            // Movement keys → cam.pos.
            camForward(_fwd);
            camRight(_right);
            _move.set(0, 0, 0);
            if (cam.keys.w) _move.add(_fwd);
            if (cam.keys.s) _move.sub(_fwd);
            if (cam.keys.a) _move.sub(_right);
            if (cam.keys.d) _move.add(_right);
            if (cam.keys.q) _move.y -= 1;
            if (cam.keys.e) _move.y += 1;
            if (_move.lengthSq() > 0 && dt > 0) {
                const sprint = cam.keys.shift ? cam.sprintMul : 1;
                _move.normalize().multiplyScalar(cam.moveSpeed * sprint * dt);
                cam.pos.add(_move);
            }
            applyCamToThree();
        },
        dispose() {
            canvas.removeEventListener('pointerdown', onPointerDown);
            canvas.removeEventListener('pointermove', onPointerMove);
            canvas.removeEventListener('pointerup',   onPointerUp);
            canvas.removeEventListener('pointercancel', onPointerUp);
            canvas.removeEventListener('wheel',       onWheel);
            canvas.removeEventListener('contextmenu', onContextMenu);
            canvas.removeEventListener('dblclick',    onDblClick);
            window.removeEventListener('keydown',     onKeyDown);
            window.removeEventListener('keyup',       onKeyUp);
            window.removeEventListener('blur',        onBlur);
        },
    };

    // ── Input handlers ─────────────────────────────────────────────────────
    // Every pointer is tracked by id, so mouse, pen and touch share one path:
    //   1 pointer, left button      → ORBIT around the target
    //   1 pointer, right / Shift    → PAN (target + camera move together)
    //   2 pointers (touch)          → PINCH to dolly + drag the midpoint to pan
    // A pinch that drops to one finger continues as an orbit from where that
    // finger is (re-seeded, so the camera does not jump by the pinch's travel).
    // The canvas carries `touch-action: none` in CSS — without it the browser
    // scrolls / zooms the page under a one-finger drag and no gesture arrives.
    const pointers = new Map();          // pointerId → { x, y }
    let gesture = null;                  // 'orbit' | 'pan' | 'pinch' | null
    let pinchDist = 0;
    let pinchMid = { x: 0, y: 0 };
    const _panRight = new THREE.Vector3();
    const _panUp    = new THREE.Vector3();

    function pinchState() {
        const [a, b] = [...pointers.values()];
        return {
            dist: Math.hypot(a.x - b.x, a.y - b.y) || 1,
            mid: { x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 },
        };
    }

    // Pan the camera AND its orbit target in the view plane by a pixel delta,
    // scaled so the ground under the cursor tracks the pointer at the target's
    // depth. The target is then held inside a box around the vehicle (one
    // stack-height of slack) so a pan can never lose the rocket entirely —
    // Recenter (⊙ / R / double-click) brings it back exactly.
    function panBy(dx, dy) {
        const dist = cam.pos.distanceTo(controls.target);
        const h = Math.max(1, canvas.clientHeight || 1);
        const wpp = 2 * dist * Math.tan((camera.fov * Math.PI / 180) / 2) / h;
        camera.updateMatrixWorld();
        _panRight.setFromMatrixColumn(camera.matrixWorld, 0);
        _panUp.setFromMatrixColumn(camera.matrixWorld, 1);
        const move = _panRight.multiplyScalar(-dx * wpp).add(_panUp.multiplyScalar(dy * wpp));
        const before = controls.target.clone();
        controls.target.add(move);
        clampTarget();
        cam.pos.add(controls.target.clone().sub(before));
        setLookAt(controls.target);
    }
    function clampTarget() {
        const h = Math.max(10, current.height || 50);
        const baseY = (current.root ? current.root.position.y : 0);
        const t = controls.target;
        t.x = THREE.MathUtils.clamp(t.x, -h, h);
        t.z = THREE.MathUtils.clamp(t.z, -h, h);
        t.y = THREE.MathUtils.clamp(t.y, Math.max(0.5, baseY - h * 0.2), baseY + h * 1.4);
    }

    // Double-TAP recenters on touch (browsers do not reliably synthesise
    // dblclick under touch-action:none). Timed on event.timeStamp — when the
    // browser generated the event — never performance.now() in the handler,
    // which on a slow frame read a genuine quick double-tap as ~900 ms apart
    // (the mars.html scar). A tap is ≤ 10 px of travel and ≤ 300 ms down.
    const TAP_MOVE_PX = 10, TAP_HOLD_MS = 300, DOUBLE_TAP_MS = 500;
    let tapStart = null;          // { x, y, t } of the current single press
    let lastTap = null;           // { x, y, t } of the previous completed tap

    function onPointerDown(e) {
        if (e.pointerType === 'mouse' && e.button !== 0 && e.button !== 2) return;
        tapStart = (pointers.size === 0 && e.pointerType !== 'mouse')
            ? { x: e.clientX, y: e.clientY, t: e.timeStamp } : null;
        pointers.set(e.pointerId, { x: e.clientX, y: e.clientY });
        try { canvas.setPointerCapture(e.pointerId); } catch (_) {}
        // preventScroll: focusing the canvas otherwise triggers the
        // browser's scroll-into-view, which on a wide page shifts the
        // whole document sideways when you click the canvas.
        canvas.focus({ preventScroll: true });
        if (pointers.size === 1) {
            gesture = (e.button === 2 || e.shiftKey) ? 'pan' : 'orbit';
            cam.lastX = e.clientX; cam.lastY = e.clientY;
        } else if (pointers.size === 2) {
            tapStart = null;
            gesture = 'pinch';
            const p = pinchState();
            pinchDist = p.dist; pinchMid = p.mid;
        }
        cam.dragging = pointers.size > 0;
    }
    function onPointerMove(e) {
        const p = pointers.get(e.pointerId);
        if (!p) return;
        p.x = e.clientX; p.y = e.clientY;
        if (gesture === 'pinch' && pointers.size >= 2) {
            const now = pinchState();
            const f = pinchDist / now.dist;
            if (Math.abs(f - 1) > 1e-4) dollyToTarget(f);
            panBy(now.mid.x - pinchMid.x, now.mid.y - pinchMid.y);
            pinchDist = now.dist; pinchMid = now.mid;
            userControlledCamera = true;
            return;
        }
        const dx = e.clientX - cam.lastX;
        const dy = e.clientY - cam.lastY;
        cam.lastX = e.clientX;
        cam.lastY = e.clientY;
        if (!dx && !dy) return;
        userControlledCamera = true;                 // a real drag
        if (gesture === 'pan') panBy(dx, dy);
        else if (gesture === 'orbit') orbitAroundTarget(dx, dy);
    }
    function onPointerUp(e) {
        if (!pointers.has(e.pointerId)) return;
        pointers.delete(e.pointerId);
        if (tapStart && pointers.size === 0 && e.type === 'pointerup') {
            const moved = Math.hypot(e.clientX - tapStart.x, e.clientY - tapStart.y);
            const held  = e.timeStamp - tapStart.t;
            if (moved <= TAP_MOVE_PX && held <= TAP_HOLD_MS) {
                const tap = { x: e.clientX, y: e.clientY, t: e.timeStamp };
                if (lastTap && tap.t - lastTap.t <= DOUBLE_TAP_MS &&
                    Math.hypot(tap.x - lastTap.x, tap.y - lastTap.y) <= 40) {
                    lastTap = null;
                    recenter();
                } else {
                    lastTap = tap;
                }
            } else {
                lastTap = null;
            }
        }
        if (pointers.size > 0) tapStart = null;
        try { canvas.releasePointerCapture(e.pointerId); } catch (_) {}
        if (pointers.size === 1) {
            // Pinch → one finger: continue as an orbit from that finger.
            const [rest] = pointers.values();
            gesture = 'orbit';
            cam.lastX = rest.x; cam.lastY = rest.y;
        } else if (pointers.size === 0) {
            gesture = null;
        }
        cam.dragging = pointers.size > 0;
    }
    function onContextMenu(e) {
        // Right-drag pans, so the context menu must not open over the canvas.
        // Doesn't affect anywhere else on the page.
        e.preventDefault();
    }
    function onDblClick(e) {
        e.preventDefault();
        recenter();
    }
    function onWheel(e) {
        // Zoom toward / away from the rocket. Scroll up (deltaY < 0) zooms in.
        // Radius-based + clamped so you can't tunnel through the vehicle into
        // the tower. preventDefault so the wheel drives the camera, not the
        // page scroll, while the cursor is on the canvas. A trackpad pinch
        // arrives as a ctrl+wheel with small deltas — scaled by magnitude so
        // it is smooth rather than a 12 % step per event.
        e.preventDefault();
        userControlledCamera = true;                 // wheel-dolly
        const mag = Math.min(1, Math.abs(e.deltaY) / (e.ctrlKey ? 25 : 100));
        const step = 1 + 0.12 * Math.max(0.15, mag);
        dollyToTarget(e.deltaY > 0 ? step : 1 / step);
    }
    function setKey(key, down) {
        const k = key.length === 1 ? key.toLowerCase() : key;
        if (k === 'Shift' || k === 'shift') { cam.keys.shift = down; return; }
        if ('wasdqe'.includes(k)) {
            cam.keys[k] = down;
            if (down) userControlledCamera = true;    // WASD/QE fly
        }
    }
    // One-shot keys (canvas focused): arrows orbit, +/− zoom, R recenter,
    // Home = back to this screen's default view.
    const ORBIT_KEY_DEG = 6;
    function onKeyDown(e) {
        // Only intercept keys when the canvas has focus, so typing in forms
        // anywhere else on the page is unaffected.
        if (document.activeElement !== canvas) return;
        if (e.ctrlKey || e.metaKey || e.altKey) return;
        const k = e.key;
        let handled = true;
        if (k === 'ArrowLeft')       orbitBy(-ORBIT_KEY_DEG, 0);
        else if (k === 'ArrowRight') orbitBy(ORBIT_KEY_DEG, 0);
        else if (k === 'ArrowUp')    orbitBy(0, ORBIT_KEY_DEG);     // camera rises (as a downward drag)
        else if (k === 'ArrowDown')  orbitBy(0, -ORBIT_KEY_DEG);
        else if (k === '+' || k === '=') setZoom(0.8);
        else if (k === '-' || k === '_') setZoom(1.25);
        else if (k === 'r' || k === 'R') recenter();
        else if (k === 'Home')       resetView();
        else handled = false;
        if (handled) { e.preventDefault(); return; }
        setKey(k, true);
        if ((k.length === 1 && 'wasdqeWASDQE'.includes(k)) || k === 'Shift') e.preventDefault();
    }
    function onKeyUp(e) {
        setKey(e.key, false);
    }
    function onBlur() {
        // Window lost focus — release all held keys so the camera doesn't
        // glide off forever when the user alt-tabs mid-press.
        for (const k of Object.keys(cam.keys)) cam.keys[k] = false;
        pointers.clear();
        gesture = null;
        cam.dragging = false;
    }

    // Orbit by DEGREES (buttons, arrow keys, auto-rotate) through the same
    // spherical step the drag uses.
    function orbitBy(dAzDeg, dElDeg) {
        userControlledCamera = true;
        const rad = Math.PI / 180;
        orbitAroundTarget(dAzDeg * rad / cam.lookSpeed, dElDeg * rad / cam.lookSpeed);
    }

    canvas.tabIndex = 0;                          // make focusable (focus ring: CSS :focus-visible)
    canvas.addEventListener('pointerdown',   onPointerDown);
    canvas.addEventListener('pointermove',   onPointerMove);
    canvas.addEventListener('pointerup',     onPointerUp);
    canvas.addEventListener('pointercancel', onPointerUp);
    canvas.addEventListener('wheel',         onWheel, { passive: false });
    canvas.addEventListener('contextmenu',   onContextMenu);
    canvas.addEventListener('dblclick',      onDblClick);
    window.addEventListener('keydown',       onKeyDown);
    window.addEventListener('keyup',         onKeyUp);
    window.addEventListener('blur',          onBlur);

    // ── Vehicle state (mutable — replaced by setVehicle) ───────────────────
    let current = {
        id: null, variant: null, root: null, plumes: [],
        height: 1, info: null,
        bbox: new THREE.Box3(),
        basePadY: 0,
        baseTargetY: 0,
        baseCamY: 0,
        lastAltitude: 0,
        trailWidthM: 9,
    };
    let currentViewName = 'threequarter';

    // ── Screen-aware framing (js/launch-camera-layout.js) ─────────────────
    // viewIsAuto: the preset follows the SCREEN (pickDefaultView) until the
    //   user picks one; a deliberate pick is never overridden by a resize,
    //   and Home / resetView() hands control back to the screen.
    // fovIsAuto: same rule for the lens (cycling the FOV claims it).
    // safeInsets: px the floating toolbars take off the top / bottom of the
    //   frame where the vehicle is drawn (measured by the host page). The fit
    //   uses the safe rectangle's FOV/aspect and the projection's principal
    //   point is moved to its centre (camera.setViewOffset), so the stack is
    //   framed in the clear area instead of under the buttons.
    let viewIsAuto = opts.autoView !== false;
    let fovIsAuto = opts.autoView !== false;
    let safeInsetsState = { top: 0, bottom: 0 };
    let autoRotateOn = !!opts.autoRotate;
    const AUTO_ROTATE_RAD_S = (2 * Math.PI) / 50;      // one turn in 50 s

    function canvasBox() {
        return { w: canvas.clientWidth || 0, h: canvas.clientHeight || 0 };
    }
    function fitParams() {
        const { w, h } = canvasBox();
        if (!w || !h) return { fitFovDeg: cameraFov, fitAspect: camera.aspect || 16 / 10, viewOffsetY: 0 };
        return framingFor({ width: w, height: h, fovDeg: cameraFov, insets: safeInsetsState });
    }
    function applyViewOffset() {
        const { w, h } = canvasBox();
        if (!w || !h) return;
        const f = fitParams();
        if (Math.abs(f.viewOffsetY) > 0.5) camera.setViewOffset(w, h, 0, f.viewOffsetY, w, h);
        else camera.clearViewOffset();
    }
    function notifyView() {
        if (typeof opts.onViewChange === 'function') {
            opts.onViewChange({ view: currentViewName, fov: cameraFov, auto: viewIsAuto });
        }
    }
    // Apply the screen's default preset / lens if they are still automatic.
    // Returns true when anything changed.
    function applyAutoPick() {
        const { w, h } = canvasBox();
        if (!w || !h) return false;
        const pick = pickDefaultView({ width: w, height: h });
        let changed = false;
        if (viewIsAuto && pick.view !== currentViewName) { currentViewName = pick.view; changed = true; }
        if (fovIsAuto && Math.abs(pick.fov - cameraFov) > 0.5) {
            cameraFov = pick.fov;
            camera.fov = cameraFov;
            camera.updateProjectionMatrix();
            changed = true;
        }
        if (changed) notifyView();
        return changed;
    }

    // ── View tween state ───────────────────────────────────────────────────
    // setView fires ONE tween (carrying both cam.pos and controls.target as
    // a 6-vec) so cancellation is a single handle. cameraFollowSuppressed
    // gates applyMissionState's per-frame Δy add during the tween, since
    // the tween itself bakes the live altitude offset into each step.
    let activeTween = null;
    let cameraFollowSuppressed = false;

    function cancelViewTween() {
        if (activeTween) { activeTween.cancelled = true; activeTween = null; }
        cameraFollowSuppressed = false;
    }

    function liveOffsetY() {
        return current.root ? (current.root.position.y - current.basePadY) : 0;
    }

    function disposeMeshes(obj) {
        obj.traverse(o => {
            if (o.geometry) o.geometry.dispose();
            if (o.material) {
                const mats = Array.isArray(o.material) ? o.material : [o.material];
                mats.forEach(m => m.dispose());
            }
        });
    }

    function fitShadowCameraToVehicle(vehicle) {
        // Aim the floodlight spot at the vehicle's mid-height from the camera
        // side, far enough out that its cone covers the whole stack plus the
        // pad apron (radius ≈ 1.15 h at the vehicle), so a 56 m shuttle and a
        // 150 m Starship + tower both sit inside the pool with soft edges.
        const h = vehicle.height;
        const baseY = vehicle.root.position.y;
        const aim = new THREE.Vector3(0, baseY + h * 0.45, 0);
        const dir = new THREE.Vector3(0.80, 0.62, 0.52).normalize();
        const dist = h * 3.2;
        key.position.copy(aim).addScaledVector(dir, dist);
        key.target.position.copy(aim);
        key.target.updateMatrixWorld();
        if (!key.target.parent) scene.add(key.target);
        const poolR = h * 1.15;
        key.angle = Math.atan(poolR / dist);
        key.penumbra = 0.6;
        key.shadow.camera.near = dist * 0.35;
        key.shadow.camera.far  = dist * 2.2;
        key.shadow.camera.updateProjectionMatrix();
    }

    // Per-vehicle effects set-up: smoke profile + tints, the engine-light
    // colour, where the exhaust meets the pad, and plume draw order.
    function configureVehicleFx(v) {
        const profile = SMOKE_PROFILES[v.id] ? v.id : 'falcon9';
        const tint = SMOKE_TINTS[profile];
        const D = parseFloat(v.info?.diameter_m) || 4;
        // Engine cluster centre + exit height in vehicle-local space, from the
        // same engineLayout the thrust-vector overlay draws.
        const eng = v.engineLayout?.boosterEngines?.length ? v.engineLayout.boosterEngines : null;
        let cx = 0, cz = 0, minY = 0;
        if (eng) {
            for (const e of eng) { cx += e.x; cz += e.z; }
            cx /= eng.length; cz /= eng.length;
            minY = Math.min(...eng.map(e => e.y));
        }
        // Where the plume hits: the deck under the vehicle (flame trench for
        // the MLP / TEL pads, the deluge plate under the Starship OLM).
        const onMount = v.padId === 'mechazilla';
        // Flame-trench outlets: both pads with an MLP / deck vent the cloud
        // out of the trench along ±Z; the OLM has no trench, so radial.
        const exits = onMount ? null : [[cx, 30, 0, 1], [cx, -30, 0, -1]];
        v.fx = {
            profile, D, exits,
            nozzleLocal: new THREE.Vector3(cx, minY - D * 0.15, cz),
            deckY: onMount ? 0.6 : (v.basePadY ?? 4.2),
            steamR: onMount ? D * 1.6 : D * 2.2,
        };
        smokeView.uniforms.uExhaust.value.copy(tint.exhaust);
        smokeView.uniforms.uGround.value.copy(tint.ground);
        flameLight.color.setHex(tint.flame);
        _flameCol.setHex(tint.flame);
        for (const p of v.plumes || []) p.traverse(o => { o.renderOrder = 2; });
        clearSmoke(smokeSim);
        smokeCarry = createEmissionCarry();
    }

    // World position of the engine cluster exit for the current pose.
    function nozzleWorld(out) {
        current.root.updateMatrixWorld(true);
        return out.copy(current.fx.nozzleLocal).applyMatrix4(current.root.matrixWorld);
    }

    function emitSmokeFor(s, dt) {
        const fx = current.fx;
        if (!fx) return;
        nozzleWorld(_nozzleWorld);
        _downWorld.set(0, -1, 0).transformDirection(current.root.matrixWorld);
        planEmissions(smokeSim, fx.profile, {
            T: s.T, dt, throttle: s.throttle, altitude: s.altitude, D: fx.D,
            nozzle: [_nozzleWorld.x, _nozzleWorld.y, _nozzleWorld.z],
            down: [_downWorld.x, _downWorld.y, _downWorld.z],
            deckY: fx.deckY, groundY: 0, exits: fx.exits, steamR: fx.steamR,
            budget: smokeBudget,
        }, smokeCarry);
    }

    function setVehicle(id, variant) {
        const builder = VEHICLE_BUILDERS[id];
        if (!builder) { console.warn(`Unknown vehicle: ${id}`); return; }

        // Cancel any in-flight animation + view-tween before swapping. A
        // stale tween from the prior vehicle would keep writing camera.pos
        // for ~800 ms, fighting the new vehicle's framing.
        cancelViewTween();
        cameraFollowSuppressed = false;
        if (missionActive) cancelLiftoff();

        // Tear down previous vehicle.
        if (current.root) {
            scene.remove(current.root);
            disposeMeshes(current.root);
        }

        const v = builder(variant);

        // Build a thrust-vector overlay matching this vehicle's engine
        // layout. Parented to the vehicle root so it inherits liftoff
        // pitch/roll transforms automatically.
        const thrustOverlay = buildThrustOverlay(v);
        thrustOverlay.visible = vectorsOn;            // honor user toggle across vehicle changes
        v.root.add(thrustOverlay);

        scene.add(v.root);

        current = {
            id, variant, ...v,
            bbox: computeVehicleBBox(v.root),
            basePadY: v.root.position.y,
            baseTargetY: 0,
            baseCamY: 0,
            lastAltitude: 0,
            thrustOverlay,
            // Per-pad trail width — wider for Stage 0's 33-engine cluster.
            trailWidthM: (v.padId === 'mechazilla') ? 14 : 9,
        };

        // Swap pad infrastructure to whichever site this vehicle flies from.
        // Pass the booster diameter so adaptive pads (Mechazilla) can size
        // their hole + clamp ring to the actual stack.
        const padOpts = {
            boosterDiameter: parseFloat(v.info?.diameter_m) || undefined,
            aimY: v.root.position.y + v.height * 0.45,
        };
        swapPad(v.padId, padOpts);
        configureVehicleFx(current);

        // A new vehicle starts framed from the canonical 3/4 angle, and
        // re-arms auto-framing so any post-swap resize keeps it centred
        // until the user grabs the camera again.
        // The preset survives a vehicle swap if the user chose it (Engines
        // stays Engines); an automatic one is re-picked for this screen.
        if (viewIsAuto) { currentViewName = 'threequarter'; applyAutoPick(); }
        userControlledCamera = false;
        const fit0 = fitParams();
        const view = frameForView(currentViewName, current, fit0.fitFovDeg, fit0.fitAspect);
        cam.pos.set(...view.pos);
        controls.target.set(...view.target);
        setLookAt(controls.target);
        applyCamToThree();
        fitShadowCameraToVehicle(current);

        // Capture baseline Y so the liftoff Δ-follow can re-baseline cleanly.
        current.baseTargetY = controls.target.y;
        current.baseCamY    = cam.pos.y;

        if (typeof opts.onVehicleChange === 'function') {
            opts.onVehicleChange({ id, variant, info: v.info });
        }
        notifyView();
    }

    // ── Liftoff animation ──────────────────────────────────────────────────
    // Apply the mission-clock snapshot to the scene each frame: vehicle
    // pose, plume throttle, exhaust trail, sky/fog tint, pad fade, and a
    // 1:1 camera follow that preserves the user's orbital framing.
    function applyMissionState(s) {
        // Hold-down release "twang" — at T=0 the real shuttle SRBs fire,
        // hold-down posts release, and the stack springs upward by ~15 cm
        // before settling into ascent. Add a damped sine kick that decays
        // over the first ~1 s so the launch reads with a satisfying jolt.
        const T = s.T;
        let twang = 0;
        if (T >= 0 && T < 1.2) {
            const decay = Math.exp(-T * 3.2);
            twang = 0.55 * decay * Math.sin(T * Math.PI * 5);
        }

        // Vehicle pose
        current.root.position.y = current.basePadY + s.altitude + twang;
        current.root.rotation.y = s.roll;
        current.root.rotation.x = -s.pitch;

        // High-frequency vibration during liftoff & first 12 s of ascent —
        // tiny lateral wobble suggesting acoustic loading without making
        // the rocket look broken.
        const vibAmp = (T > -0.5 && T < 12) ? 0.02 + 0.03 * Math.max(0, 1 - T / 12) : 0;
        if (vibAmp > 0) {
            current.root.position.x = Math.sin(T * 41) * vibAmp;
            current.root.position.z = Math.cos(T * 47) * vibAmp;
        } else {
            current.root.position.x = 0;
            current.root.position.z = 0;
        }

        // Camera follow: target rises with the vehicle, cam.pos rises by
        // the same Δ so the user's framing is preserved. Suppressed during
        // a view-tween so the tween's absolute writes don't race this
        // delta-add.
        if (!cameraFollowSuppressed) {
            const dy = s.altitude - current.lastAltitude;
            if (dy !== 0) {
                controls.target.y += dy;
                cam.pos.y         += dy;
            }
        }
        current.lastAltitude = s.altitude;

        // Exhaust trail, ground cloud and deluge steam are smoke SPRITES now,
        // emitted in tick() from the live nozzle position (see emitSmokeFor).

        // Sky / fog — the haze thins as the rocket climbs (the camera rides
        // with it). Colour stays HORIZON so terrain never detaches from the sky.
        scene.fog.density = baseFogDensity * (1 - 0.6 * s.skyMix);

        // Pad fade
        applyPadOpacity(s.padOpacity);
    }

    // Compute a small camera shake offset for the loudest acoustic window —
    // ignition + first few seconds of liftoff. Returned as a {x,y,z} delta
    // that the caller adds before render and removes after, so the offset
    // doesn't get fed back into OrbitControls' damping target.
    function shakeOffsetFor(T) {
        if (T < -0.5 || T > 5) return null;
        const env = T < 0
            ? Math.max(0, (T + 0.5) / 0.5) * 0.6   // ignition build
            : Math.max(0, 1 - T / 5);              // post-liftoff decay
        if (env <= 0) return null;
        const amp = 0.08 * env;
        return {
            x: Math.sin(T * 73 + 0.7) * amp,
            y: Math.sin(T * 83 + 1.3) * amp,
            z: Math.sin(T * 79 + 2.1) * amp,
        };
    }

    // Walks the pad's mesh tree applying an opacity. Idempotent.
    //
    // Each material's ORIGINAL transparent/opacity is remembered on first
    // touch and restored at o = 1. The old version forced `transparent =
    // false` on restore, which silently turned every deliberately-transparent
    // pad material opaque after the first launch — the gravel apron's alpha
    // fade, the additive lamp glows and the floodlight beams.
    function applyPadOpacity(o) {
        if (!padState.root) return;
        padState.root.traverse(node => {
            if (!node.isMesh || !node.material) return;
            const mats = Array.isArray(node.material) ? node.material : [node.material];
            for (const m of mats) {
                if (!m.userData.__padBase) {
                    m.userData.__padBase = { transparent: m.transparent, opacity: m.opacity };
                }
                const base = m.userData.__padBase;
                if (o < 1) {
                    if (!m.transparent) { m.transparent = true; m.needsUpdate = true; }
                    m.opacity = base.opacity * o;
                    if (m.uniforms?.uOpacity) m.uniforms.uOpacity.value = o;
                } else {
                    if (m.transparent !== base.transparent) { m.transparent = base.transparent; m.needsUpdate = true; }
                    m.opacity = base.opacity;
                    if (m.uniforms?.uOpacity) m.uniforms.uOpacity.value = 1;
                }
            }
        });
    }

    function liftoff() {
        if (missionActive) { cancelLiftoff(); return; }

        // Cancel any active view-tween — otherwise its absolute camera-pos
        // writes for the next several hundred ms would race the per-frame
        // ascent follow, producing a visible camera judder right at T-0.
        cancelViewTween();
        cameraFollowSuppressed = false;

        // Re-baseline vertical follow before the delta-tracking loop runs.
        // lastAltitude must equal the y-offset already in the camera, or
        // the first `dy = altitude - lastAltitude` snaps the camera by the
        // stale residual. Snap target.y / camera.y back to the framing
        // captured by setVehicle() and leave x/z alone so the user's
        // azimuth/orbit survives. controls.update() flushes any damping
        // residual so it can't race the manual y-writes next frame.
        current.lastAltitude = 0;
        controls.target.y    = current.baseTargetY;
        cam.pos.y            = current.baseCamY;

        missionClock.start();
        missionActive = true;
        // Force plume on so you can actually see the engines fire.
        for (const p of current.plumes) p.visible = true;
    }

    function cancelLiftoff() {
        if (!missionActive) return;
        missionActive = false;
        missionClock.reset();

        // Same reasoning as liftoff() — kill any in-flight view tween before
        // we restore the base framing, so the tween can't drag the camera
        // back into mid-air after we settle it back on the pad.
        cancelViewTween();
        cameraFollowSuppressed = false;

        // Reset vehicle pose — including the per-frame vibration offset
        // and twang in X/Z that the launch loop accumulated.
        current.root.position.set(0, current.basePadY, 0);
        current.root.rotation.set(0, 0, 0);

        // Restore baseline Y so subsequent launches start clean.
        controls.target.y    = current.baseTargetY;
        cam.pos.y            = current.baseCamY;
        current.lastAltitude = 0;

        // Restore scene state — the vehicle is back on the pad, so its smoke
        // goes too (a cloud hanging over a stack at T-3 would read as a fire).
        clearSmoke(smokeSim);
        smokeCarry = createEmissionCarry();
        scene.fog.color.copy(baseFogColor);
        scene.fog.density = baseFogDensity;
        applyPadOpacity(1);

        // Note: we leave plume + auto-rotate to whatever the user toggles.
        // The UI button-state listener flips its own label.
        if (typeof opts.onLiftoffEnd === 'function') opts.onLiftoffEnd();
    }

    // Snap the camera to the canonical frame for the current preset and the
    // *live* canvas aspect. Mirrors setVehicle's framing but without the
    // 800 ms view tween, so a canvas that was just revealed (panel expanded)
    // pops straight to the correct frame instead of animating from a stale
    // pose. Sets controls.target + flushes the god-camera so the pose is
    // applied even if the render loop is currently paused (collapsed panel).
    function reframeCurrentView() {
        if (!current || !current.root) return;
        cancelViewTween();
        const fit = fitParams();
        const view   = frameForView(currentViewName || 'threequarter',
                                    current, fit.fitFovDeg, fit.fitAspect);
        const dy = liveOffsetY();
        cam.pos.set(view.pos[0],    view.pos[1]    + dy, view.pos[2]);
        controls.target.set(view.target[0], view.target[1] + dy, view.target[2]);
        setLookAt(controls.target);
        controls.update();
        applyCamToThree();
        // Re-baseline the on-pad reference Y (excludes any in-flight offset)
        // so a later liftoff Δ-follow stays consistent.
        current.baseTargetY = controls.target.y - dy;
        current.baseCamY    = cam.pos.y - dy;
    }

    // ── Resize handling ────────────────────────────────────────────────────
    // Sized BEFORE the initial setVehicle so frameForView sees the correct
    // canvas aspect from the very first frame — otherwise the default
    // PerspectiveCamera aspect leads to a tall, low-margin fit and the rocket
    // spills out the sides.
    //
    // The canvas host (.lh-vehicle-canvas-host, inside .lp-collapse-body) can
    // mount display:none when its panel restores a persisted "collapsed"
    // state. While collapsed, clientWidth/clientHeight are 0. We must NOT
    // derive aspect from that (0/0 = NaN) nor setSize(0), and we must NOT
    // substitute an arbitrary fallback size — doing so bakes a wrong aspect
    // into setVehicle's framing that nothing ever corrects.
    //
    // CAMERA-FRAMING CONTRACT (the "fix it once and for all" rule):
    //   Auto-reframe on EVERY resize, for as long as the user hasn't grabbed
    //   the free-fly camera. Page layout — especially the documented Mac
    //   Firefox/Safari grid-track thrash — emits a *sequence* of resize
    //   boxes during load (intermediate width, aspect-ratio not yet applied,
    //   min-height-only, …) before settling. A one-shot "frame on the first
    //   valid box" latch frames against whichever transient box arrives
    //   first and is then stuck there forever — the recurring "camera
    //   defaults to the orange tower" bug. Reframing on every resize means
    //   the camera is correct the instant layout settles, no matter what it
    //   passed through. Once the user actually drags / wheels / WASDs the
    //   camera (userControlledCamera = true) we stop yanking it — they own
    //   it from then until the next vehicle swap or explicit recenter.
    // Last applied box. Tracked so we can skip a setSize when nothing changed
    // (see resize()) — that's what gives the Firefox/Safari feedback loop a
    // fixed point and lets it settle.
    let _lastW = 0, _lastH = 0;
    function resize() {
        const w = canvas.clientWidth;
        const h = canvas.clientHeight;
        if (!w || !h) return;                 // collapsed / not yet laid out
        // BREAK THE RESIZEOBSERVER FEEDBACK LOOP (the load-time "camera stares
        // at the orange tower" bug on Mac Firefox/Safari).
        //
        // renderer.setSize() writes the canvas's width/height ATTRIBUTES — its
        // intrinsic content size. Despite minmax(0,1fr) + contain:layout size
        // on the host, those engines leak that intrinsic size back into grid
        // track sizing, which resizes the host, which re-fires this observer,
        // which calls setSize again… an oscillation that never delivers a
        // clean "settled" box. The camera was then left framed against whatever
        // transient (wrong-aspect) box happened to be current when the browser
        // throttled the observer — hence the rocket vanishing off-frame.
        //
        // If the box hasn't actually changed, do nothing. No attribute write →
        // no intrinsic-size change → the loop has a fixed point and stops. On
        // Chromium (where the size is stable anyway) this is just a cheap skip.
        if (w === _lastW && h === _lastH) return;
        _lastW = w; _lastH = h;
        // pixelRatio is locked to 1 (see WebGLRenderer init), so the drawing
        // buffer always equals the CSS box and can't overflow the grid track.
        renderer.setSize(w, h, false);
        post.setSize(w, h);
        camera.aspect = w / h;
        camera.updateProjectionMatrix();
        applyViewOffset();
        applyAutoPick();                       // no-op once the user has chosen
        if (!userControlledCamera) reframeCurrentView();
    }
    // Coalesce a burst of observer callbacks into a single measurement on the
    // next animation frame, by which point layout for this frame has settled.
    // We always act on the LATEST box, so an intermediate reflow box can never
    // be the one the camera ends up framed against — the other half of the
    // feedback-loop fix above.
    let _resizeRaf = 0;
    function scheduleResize() {
        if (_resizeRaf) return;
        _resizeRaf = requestAnimationFrame(() => { _resizeRaf = 0; resize(); });
    }
    // Observe the host element, not just the canvas: the host is what
    // gains/loses its layout box when the collapse panel toggles
    // display:none ⇄ block, so observing it guarantees the expand
    // notification (and the density aspect-ratio change) in every browser.
    const resizeHost = canvas.parentElement || canvas;
    resize();
    const ro = new ResizeObserver(scheduleResize);
    ro.observe(resizeHost);

    // Initial vehicle.
    setVehicle(opts.vehicle || 'shuttle', opts.variant);

    // ── Render loop (paused when off-screen) ───────────────────────────────
    let running = true;
    let rafId = 0;
    const clock = new THREE.Clock();
    const io = new IntersectionObserver(([entry]) => {
        running = entry.isIntersecting;
        if (running && !rafId) tick();
    }, { threshold: 0.05 });
    io.observe(canvas);

    function tick() {
        if (!running) { rafId = 0; return; }
        // Clamp: a backgrounded tab returns with a multi-second delta that
        // would otherwise teleport every smoke puff at once.
        const dt = Math.min(clock.getDelta(), 0.5);
        const t = clock.elapsedTime;
        controls._dt = dt;
        if (autoRotateOn && pointers.size === 0 && !activeTween && dt > 0) {
            userControlledCamera = true;            // a turned camera is not the preset frame
            orbitAroundTarget(-AUTO_ROTATE_RAD_S * dt / cam.lookSpeed, 0);
        }
        controls.update();
        stars.tick(t);

        // Liftoff state — advance clock, apply pose/sky/pad, drive plume throttle.
        let throttle = 1;
        let snap = null;
        if (missionActive) {
            const T0 = missionClock.T;
            missionClock.update(performance.now());
            snap = missionClock.snapshot();
            applyMissionState(snap);
            throttle = snap.throttle;
            // Emit on MISSION time (the clock runs on wall time), so a slow
            // frame emits the smoke that frame actually covered.
            emitSmokeFor(snap, Math.max(0, snap.T - T0));
        }
        stepSmoke(smokeSim, dt, { groundY: 0, drag: 0.55, wind: [1.6, -0.8], cooling: 0.32, maxDt: 1 / 20 });
        if (missionActive && missionClock.finished()) {
            // Auto-end + reset; UI listener resets its button.
            cancelLiftoff();
            throttle = 1;
            snap = null;
        }

        // Live altitude (km) feeds the plume shader so it widens / lengthens
        // as ambient pressure falls. liveOffsetY() is meters above pad.
        const altKm = liveOffsetY() / 1000;
        for (const p of current.plumes) tickPlume(p, t, throttle, altKm);
        tickBeacons(padState.beacons, t);

        // Engine light: on whenever the plume is drawn (static Plume toggle or
        // a burn), flickering, scaled by throttle. ~1/r² from the exit.
        const plumeOn = current.plumes.some(p => p.visible);
        const burn = plumeOn ? (missionActive ? throttle : 0.85) : 0;
        const flicker = 0.86 + 0.08 * Math.sin(t * 37.0) + 0.06 * Math.sin(t * 91.0 + 1.3);
        const D = current.fx?.D || 4;
        // Sat ~2.5 D below the exit — inside the plume, where the light comes
        // from — so the hull just above the bells is lit at grazing incidence
        // and does not blow out, while the deck 20–40 m away is lit at ~1–2×
        // the floodlight level (inverse-square from there).
        flameLight.intensity = burn * flicker * 900 * (D / 4) * (D / 4);
        if (burn > 0 && current.fx) {
            nozzleWorld(flameLight.position);
            flameLight.position.y = Math.max(1.5, flameLight.position.y - D * 2.5);
        }

        // Sky dome + stars ride with the camera (they are "at infinity").
        sky.follow(camera);
        stars.follow(camera);

        // Smoke: sort + upload for this camera, lit by the key and the flame.
        camera.updateMatrixWorld();
        _keyDir.copy(key.position).sub(key.target.position).normalize();
        smokeView.update(smokeSim, camera, {
            keyDir: _keyDir,
            keyColor: SMOKE_LIGHT.keyColor,
            ambTop: SMOKE_LIGHT.ambTop,
            ambBottom: SMOKE_LIGHT.ambBottom,
            steam: SMOKE_LIGHT.steam,
            flamePos: flameLight.position,
            flameColor: _flameCol,
            flameIntensity: burn * flicker * 3.0,
            flameRange: D * 3.2,
            fog: scene.fog,
        });

        // Bloom swells with the burn — the flame is the brightest thing on
        // the pad, and the glow should say so.
        post.setBloom(1 + 0.7 * burn);

        // Camera shake — applied just before render and undone right after,
        // so the offset shows in this frame but isn't fed back into
        // OrbitControls' damping next tick.
        const shake = missionActive ? shakeOffsetFor(missionClock.T) : null;
        if (shake) {
            camera.position.x += shake.x;
            camera.position.y += shake.y;
            camera.position.z += shake.z;
        }
        // Thrust-vector overlay — read live throttle + mission time.
        if (current.thrustOverlay && current.thrustOverlay.visible) {
            tickThrustOverlay(current.thrustOverlay, {
                throttle: missionActive ? throttle : (vectorsOn ? 0.05 : 0),
                T:        missionActive ? missionClock.T : 0,
            });
        }
        post.render();
        if (shake) {
            camera.position.x -= shake.x;
            camera.position.y -= shake.y;
            camera.position.z -= shake.z;
        }
        rafId = requestAnimationFrame(tick);
    }
    tick();

    // ── Public camera API ──────────────────────────────────────────────────

    // Single-tween view swap. Pos + target ride a 6-vec so cancellation is
    // one handle. The destination is a function of the live rocket Y so a
    // view-pick mid-flight lands on the moving rocket, not the empty pad.
    // opts.auto: true when the call comes from the screen rules / recenter,
    // false (default) when the USER picked the preset — which claims it.
    function setView(name, { auto = false } = {}) {
        if (!VIEW_PRESETS[name]) return;
        if (!auto) viewIsAuto = false;
        currentViewName = name;
        notifyView();
        // Picking a preset (or recenter) re-arms auto-framing: the user
        // explicitly asked for a canonical shot, so a later resize should
        // keep THAT preset framed rather than freeze the tween's end pose.
        userControlledCamera = false;
        cancelViewTween();

        const fit    = fitParams();
        const base   = frameForView(name, current, fit.fitFovDeg, fit.fitAspect);

        cameraFollowSuppressed = missionActive;

        const from = [
            cam.pos.x, cam.pos.y, cam.pos.z,
            controls.target.x, controls.target.y, controls.target.z,
        ];
        const toFn = () => {
            const dy = liveOffsetY();
            return [
                base.pos[0],    base.pos[1]    + dy, base.pos[2],
                base.target[0], base.target[1] + dy, base.target[2],
            ];
        };

        activeTween = tween(from, toFn, 800,
            v => {
                cam.pos.set(v[0], v[1], v[2]);
                controls.target.set(v[3], v[4], v[5]);
                setLookAt(controls.target);
            },
            () => {
                if (missionActive) {
                    current.lastAltitude = missionClock.snapshot().altitude;
                }
                cameraFollowSuppressed = false;
                activeTween = null;
            }
        );
    }

    // Toolbar zoom buttons. factor < 1 zooms in (toward the rocket), > 1 zooms
    // out. Radius-based + clamped, same as the wheel — never tunnels through
    // the vehicle. ~25% per click is a comfortable step.
    function setZoom(factor) {
        userControlledCamera = true;                 // deliberate user dolly
        dollyToTarget(factor < 1 ? 0.8 : 1.25);
    }

    function recenter() {
        setView(currentViewName || 'threequarter', { auto: viewIsAuto });
    }

    // Hand the preset and lens back to the screen rules and fly there.
    function resetView() {
        viewIsAuto = true;
        fovIsAuto = true;
        applyAutoPick();
        setView(currentViewName, { auto: true });
        notifyView();
    }

    // Host page → the toolbars' footprint over the frame (px). Re-fits the
    // current preset unless the user is flying the camera themselves.
    function setSafeInsets(ins = {}) {
        const next = { top: Math.max(0, Math.round(ins.top || 0)), bottom: Math.max(0, Math.round(ins.bottom || 0)) };
        if (next.top === safeInsetsState.top && next.bottom === safeInsetsState.bottom) return;
        safeInsetsState = next;
        applyViewOffset();
        if (!userControlledCamera && !missionActive) reframeCurrentView();
    }

    // FOV swap. No dolly compensation — in god-mode the user owns position
    // explicitly; FOV is purely a lens-swap.
    function setFOV(deg) {
        const next = THREE.MathUtils.clamp(deg, 18, 80);
        if (Math.abs(next - cameraFov) < 0.5) return;
        cameraFov = next;
        camera.fov = cameraFov;
        camera.updateProjectionMatrix();
    }
    function cycleFOV() {
        fovIsAuto = false;                          // the user claimed the lens
        const cycle = [28, 38, 52];
        // Next stop strictly above the current lens (the screen rules can set
        // 34° or 40°, which are not on the cycle), wrapping to the first.
        const next = cycle.find(v => v > cameraFov + 0.5) ?? cycle[0];
        setFOV(next);
        notifyView();
        return cameraFov;
    }

    function setPlume(on) {
        for (const p of current.plumes) p.visible = !!on;
    }
    function setPad(on) { if (padState.root) padState.root.visible = !!on; }

    // Slow turntable orbit around the current target (one turn in 50 s),
    // paused while a pointer is down or a preset tween is flying.
    function setAutoRotate(on) { autoRotateOn = !!on; }
    function setVectors(on) {
        vectorsOn = !!on;
        if (current.thrustOverlay) current.thrustOverlay.visible = vectorsOn;
    }

    return {
        dispose() {
            running = false;
            cancelAnimationFrame(rafId);
            if (_resizeRaf) cancelAnimationFrame(_resizeRaf);
            ro.disconnect();
            io.disconnect();
            controls.dispose();
            env.dispose();
            post.dispose();
            smokeView.dispose();
            sky.dispose();
            stars.dispose();
            terrain.dispose();
            renderer.dispose();
            scene.traverse(o => {
                if (o.geometry) o.geometry.dispose();
                if (o.material) {
                    const mats = Array.isArray(o.material) ? o.material : [o.material];
                    mats.forEach(m => m.dispose());
                }
            });
        },
        setView,
        resetView,
        setSafeInsets,
        // Degrees, the same sense as a drag: +az = drag right, +el = drag
        // down (the camera rises over the stack).
        orbit(dAzDeg = 0, dElDeg = 0) { orbitBy(dAzDeg, dElDeg); },
        pan(dxPx = 0, dyPx = 0) { userControlledCamera = true; panBy(dxPx, dyPx); },
        get view() { return { name: currentViewName, auto: viewIsAuto, fov: cameraFov, fovAuto: fovIsAuto, insets: { ...safeInsetsState } }; },
        get autoRotate() { return autoRotateOn; },
        setAutoRotate,
        setPlume,
        setPad,
        setVectors,
        setVehicle,
        setZoom,
        setFOV,
        cycleFOV,
        recenter,
        // Force a re-measure + reframe. The host page can call this after it
        // programmatically expands the vehicle panel (the collapse UI fires
        // no event) or after any layout change the ResizeObserver can't see.
        // Optional explicit w/h is an escape hatch for callers that already
        // know the target box.
        refresh() {
            // Explicit host request to re-fit — re-arm auto-framing so the
            // reframe actually happens even if the user had grabbed the cam.
            userControlledCamera = false;
            // Clear the last-applied box so resize()'s change-guard can't skip
            // this (the panel may have toggled display:none→block at the SAME
            // size, which is precisely when a forced re-fit is needed).
            _lastW = 0; _lastH = 0;
            resize();
        },
        resize(w, h) {
            if (w > 0 && h > 0) {
                renderer.setSize(w, h, false);
                post.setSize(w, h);
                camera.aspect = w / h;
                camera.updateProjectionMatrix();
                reframeCurrentView();
            } else {
                userControlledCamera = false;
                resize();
            }
        },
        liftoff,
        cancelLiftoff,
        get fov() { return cameraFov; },
        get isAscending() { return missionActive; },
        get missionT()    { return missionClock.T; },
        get currentInfo() { return current.info; },
        // Test hook: the live scene (read-only use — the browser gate inspects
        // pad materials after a launch).
        get scene() { return scene; },
        // Render diagnostics for the browser gate (tests/launch-planner-visuals.spec.js).
        get renderStats() {
            return {
                quality,
                post: post.enabled,
                smokeAlive: smokeSim.alive,
                smokeDrawn: smokeView.mesh.geometry.instanceCount,
                flameIntensity: flameLight.intensity,
                cameraY: camera.position.y,
                targetY: controls.target.y,
                cameraPos: cam.pos.toArray(),
                target: controls.target.toArray(),
                distance: cam.pos.distanceTo(controls.target),
                viewOffsetY: camera.view?.enabled ? camera.view.offsetY : 0,
            };
        },
        // Live thrust + g-force readout for the MET HUD. Returns:
        //   { throttle, thrust_mn, twr, g, mass_t }
        // Mass loss approximated as 35% over the clip (T-3 → T+50) so
        // T/W rises through ascent, mirroring real propellant burn-off.
        getLiveThrust() {
            const info = current.info;
            const t = info?.thrust;
            if (!t) return null;
            const throttle = missionActive
                ? missionClock.snapshot().throttle
                : 0;
            const T = missionActive ? missionClock.T : 0;
            const massFrac = Math.max(0.55, 1 - 0.35 * Math.max(0, Math.min(1, T / 50)));
            const massNow  = t.mass_t * massFrac;
            const liveKn   = t.liftoff_kn * throttle;
            const twr      = liveKn / (massNow * 9.80665);
            return {
                throttle,
                thrust_mn:  liveKn / 1000,
                thrust_max_mn: t.liftoff_mn,
                twr,
                g:          twr,                        // felt g-force ≈ TWR
                mass_t:     Math.round(massNow),
            };
        },
    };
}
