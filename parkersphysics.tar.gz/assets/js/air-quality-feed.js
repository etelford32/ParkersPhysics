/**
 * air-quality-feed.js — per-location Open-Meteo snapshot for the EarthView
 * verdict card: US AQI plus pollutant/aerosol fields (recent + forecast), UV
 * (now + today's peak), hourly temperature / precip-probability / cloud cover
 * / UV, and a 7-day daily outlook. Keyless, CORS-enabled, same upstream family
 * the page's global weather grid already uses.
 *
 * Why this module fetches weather at all (not just AQI/UV): the page's
 * existing WeatherFeed / WeatherForecastFeed singletons operate on a global
 * 72×36 (5°) grid for the globe shaders — ~350 mi cells, no per-location
 * hourly series, and no UV/AQI channels. The verdict card needs point
 * accuracy ("90° now"), and Open-Meteo returns all of it in ONE request per
 * location, so extending this feed costs zero extra round-trips vs. a pure
 * AQI fetch. It does NOT duplicate any fetch the page already performs.
 *
 * Events (window):
 *   'ev-air-update'  detail = state (see get state below). Fires on every
 *                    successful refresh AND on failure (status:'error',
 *                    previous data retained) so consumers can degrade chips
 *                    instead of blanking the card.
 *
 * Cache: 15 min per ~1 km location bucket. setLocation() to a new spot
 * bypasses the timer and refetches immediately.
 *
 * TEMPORAL PROVENANCE — read before rendering any of these numbers:
 *   - `aqi` is EPA NowCast, rebuilt here from the hourly component series via
 *     js/aqi-scale.js. NowCast is the REAL-TIME index AirNow publishes: a
 *     trailing weighted mean whose weight collapses toward the newest hour
 *     when concentrations move fast, so a smoke plume registers within an
 *     hour instead of being buried under eleven clean ones.
 *   - `aqiUpstream24h` is Open-Meteo's `us_aqi`, EPA's DAILY definition
 *     (24-h running mean for PM, 8 h for O₃/CO). It is correct for what it
 *     is and is retained deliberately — the two disagreeing is a signal, not
 *     a bug, and comparing them is the site's stated thesis.
 *   - `aqiMethod` says which one `aqi` currently holds. NowCast needs 2 of
 *     the 3 most recent hours; when it declines, the upstream composite
 *     carries the value and the method records that.
 *   - `pollutants` are still INSTANTANEOUS single-hour values. They are a
 *     different time base from either index and will not reconcile against
 *     the EPA table by hand; anything showing them together must say so.
 *   - `aqiValidAt` / `pollutantsValidAt` are the model hours actually used;
 *     `upstreamValidAt` is the hour us_aqi was published for. `aligned` says
 *     whether the headline and the pollutant grid share an hour.
 *   - `stale` is set once either is AQI_STALE_AFTER_MS behind. Values older
 *     than AQI_MAX_AGE_MS are dropped, not served as current.
 */

import { CAMS_PROVENANCE } from './air-quality-frame.js';
import { nowcastAqi } from './aqi-scale.js';

/**
 * App-facing pollutant field → the EPA sub-index it feeds. `us_aqi` from
 * upstream is a 24-h-mean composite; NowCast rebuilds the composite from
 * these hourly series instead. Dust and AOD have no EPA table and are
 * excluded on purpose — they are reported, never scored.
 */
const NOWCAST_FIELDS = Object.freeze({
    pm25: 'pm25',
    pm10: 'pm10',
    ozone: 'o3_8h',
    nitrogenDioxide: 'no2',
    sulphurDioxide: 'so2_1h',
    carbonMonoxide: 'co',
});

const FORECAST_URL = 'https://api.open-meteo.com/v1/forecast';
const AIR_URL = 'https://air-quality-api.open-meteo.com/v1/air-quality';
const REFRESH_MS = 15 * 60 * 1000;
const HOUR_MS = 3_600_000;

/**
 * Staleness bounds for the "newest usable past hour" fallbacks below.
 *
 * These used to be UNBOUNDED: if the current model hour was missing, the
 * search walked back through the whole `past_days=1` window and could return
 * a value up to ~30 h old, which the card then labelled "current model hour".
 * Nothing in the returned state said how old it was, so neither the UI nor a
 * consumer could tell.
 *
 * STALE_AFTER_MS is one CAMS native cycle (CAMS_PROVENANCE.nativeCadenceHours
 * = 3): past that, the value is still worth showing but must be disclosed as
 * aged. MAX_AGE_MS is the refusal point — beyond it the number is not "air
 * quality now" under any reading, so it is dropped rather than dressed up.
 */
export const AQI_STALE_AFTER_MS = 3 * HOUR_MS;
export const AQI_MAX_AGE_MS = 12 * HOUR_MS;

// The day-detail view (verdict card → tap a weekday) reads the extra hourly
// and daily fields below. They ride the SAME request — one more column each,
// no extra round-trip. Units are pinned in the URL (°F / mph / inch) so the
// card never has to guess what a number means.
const HOURLY_VARS = [
    'temperature_2m', 'precipitation_probability', 'cloud_cover', 'uv_index',
    'weather_code', 'apparent_temperature', 'relative_humidity_2m',
    'precipitation', 'wind_speed_10m', 'wind_gusts_10m',
].join(',');
const DAILY_VARS = [
    'temperature_2m_max', 'temperature_2m_min', 'weather_code', 'cloud_cover_mean',
    'precipitation_probability_max', 'apparent_temperature_max', 'apparent_temperature_min',
    'precipitation_sum', 'snowfall_sum', 'precipitation_hours', 'wind_speed_10m_max',
    'wind_gusts_10m_max', 'wind_direction_10m_dominant', 'uv_index_max', 'sunrise', 'sunset',
].join(',');
const AIR_HOURLY_VARS = [
    'us_aqi',
    'pm2_5',
    'pm10',
    'ozone',
    'nitrogen_dioxide',
    'sulphur_dioxide',
    'carbon_monoxide',
    'aerosol_optical_depth',
    'dust',
].join(',');

// Stable app-facing names. Keep upstream spelling and units at this boundary
// so consumers never need to understand Open-Meteo's field grammar.
const POLLUTANT_FIELDS = Object.freeze({
    pm25: 'pm2_5',
    pm10: 'pm10',
    ozone: 'ozone',
    nitrogenDioxide: 'nitrogen_dioxide',
    sulphurDioxide: 'sulphur_dioxide',
    carbonMonoxide: 'carbon_monoxide',
    aerosolOpticalDepth: 'aerosol_optical_depth',
    dust: 'dust',
});

// Backward-compatible name used by the verdict card. The numeric map layer
// imports the same object, so point and grid consumers cannot drift on whether
// CAMS is modeled or ground-observed data.
export const AIR_QUALITY_SOURCE = CAMS_PROVENANCE;

/** ~1 km location bucket — same-neighbourhood moves don't refetch. */
const locKey = (lat, lon) => `${lat.toFixed(2)},${lon.toFixed(2)}`;

export class AirQualityFeed {
    constructor() {
        this._timer = null;
        this._loc = null;            // {lat, lon}
        this._fetchedKey = null;
        this._fetchedAt = 0;
        this._inflight = null;
        this._state = {
            status: 'idle',          // idle | loading | live | error
            aqi: null,
            aqiHourly: [],           // [{time(ms), aqi}] — compatibility view for chip graph
            pollutants: emptyPollutants(),
            pollutionHourly: [],     // 24 h recent + 72 h forecast; AQI + pollutant fields
            pollutionUnits: {},      // app-facing field name → upstream unit
            airSource: AIR_QUALITY_SOURCE,
            aqiMethod: null,         // 'nowcast' | 'upstream-24h'
            aqiUpstream24h: null,    // Open-Meteo's 24-h-mean composite
            aqiNowcast: null,        // our EPA NowCast composite
            aqiDominant: null,       // pollutant driving the NowCast
            aqiSubIndices: {},       // per-pollutant NowCast sub-indices
            aqiMethods: {},          // per-pollutant window actually used
            aqiNotes: [],            // pollutants skipped, and why
            aqiValidAt: null,        // ms — the model hour the AQI came from
            upstreamValidAt: null,   // ms — the hour us_aqi was published for
            aqiAgeMs: null,          // ms behind now
            pollutantsValidAt: null, // ms — may differ from aqiValidAt
            pollutantsAgeMs: null,
            stale: false,            // either exceeds AQI_STALE_AFTER_MS
            aligned: null,           // AQI and pollutants share an hour?
            uvNow: null,
            uvPeak: null,
            uvPeakHour: null,        // ms
            hourly: [],              // [{time(ms), tempF, precipProb, cloudPct, uv, code,
                                     //   feelsF, rhPct, precipIn, windMph, gustMph}]
            daily: [],               // [{date(ms), hiF, loF, code, cloudPct, precipProbMax,
                                     //   feelsHiF, feelsLoF, precipIn, snowIn, precipHours,
                                     //   windMaxMph, gustMaxMph, windDirDeg, uvMax,
                                     //   sunrise(ms), sunset(ms)}]
            tz: null,                // IANA tz resolved by Open-Meteo (timezone=auto)
            fetchedAt: null,
        };
    }

    get state() { return this._state; }

    /** Begin polling for a location. Safe to call again with a new loc. */
    start(loc) {
        this.setLocation(loc);
        clearInterval(this._timer);
        this._timer = setInterval(() => this._refresh(), REFRESH_MS);
        return this;
    }

    stop() {
        clearInterval(this._timer);
        this._timer = null;
    }

    /** Point the feed at a (possibly new) location; refetches when it moved. */
    setLocation(loc) {
        if (!loc || !Number.isFinite(loc.lat) || !Number.isFinite(loc.lon)) return;
        this._loc = { lat: +loc.lat, lon: +loc.lon };
        this._refresh();
    }

    async _refresh() {
        const loc = this._loc;
        if (!loc) return;
        const key = locKey(loc.lat, loc.lon);
        const fresh = key === this._fetchedKey && Date.now() - this._fetchedAt < REFRESH_MS;
        if (fresh || this._inflight) return;

        this._state.status = this._state.status === 'idle' ? 'loading' : this._state.status;
        this._inflight = this._fetch(loc, key)
            .catch(err => {
                // Keep the previous snapshot; a degraded chip beats a blank card.
                console.warn('[AirQualityFeed] refresh failed:', err?.message || err);
                this._state = { ...this._state, status: 'error' };
                this._dispatch();
            })
            .finally(() => { this._inflight = null; });
        await this._inflight;
    }

    async _fetch(loc, key) {
        const common = `latitude=${loc.lat.toFixed(4)}&longitude=${loc.lon.toFixed(4)}&timezone=auto&timeformat=unixtime`;
        const wxUrl = `${FORECAST_URL}?${common}&hourly=${HOURLY_VARS}&daily=${DAILY_VARS}`
            + `&temperature_unit=fahrenheit&wind_speed_unit=mph&precipitation_unit=inch&forecast_days=8`;
        // `past_days=1` supplies a small aligned comparison window without a
        // second archive request. These are CAMS model fields, not station
        // observations; airSource preserves that distinction for every
        // downstream consumer and future training export.
        const aqUrl = `${AIR_URL}?${common}&hourly=${AIR_HOURLY_VARS}`
            + `&past_days=1&forecast_days=3`;

        // Both fetches in parallel; either may fail independently.
        const [wxRes, aqRes] = await Promise.allSettled([
            fetch(wxUrl, { signal: AbortSignal.timeout(12_000) }).then(r => r.ok ? r.json() : Promise.reject(new Error(`wx HTTP ${r.status}`))),
            fetch(aqUrl, { signal: AbortSignal.timeout(12_000) }).then(r => r.ok ? r.json() : Promise.reject(new Error(`aq HTTP ${r.status}`))),
        ]);
        if (wxRes.status === 'rejected' && aqRes.status === 'rejected') {
            throw wxRes.reason;
        }

        const next = { ...this._state };
        const nowMs = Date.now();

        if (wxRes.status === 'fulfilled') {
            const wx = wxRes.value;
            next.tz = wx.timezone || next.tz;

            const h = wx.hourly || {};
            const times = h.time || [];
            next.hourly = times.map((t, i) => ({
                time: t * 1000,
                tempF: numOrNull(h.temperature_2m?.[i]),
                precipProb: numOrNull(h.precipitation_probability?.[i]),
                cloudPct: numOrNull(h.cloud_cover?.[i]),
                uv: numOrNull(h.uv_index?.[i]),
                code: numOrNull(h.weather_code?.[i]),
                feelsF: numOrNull(h.apparent_temperature?.[i]),
                rhPct: numOrNull(h.relative_humidity_2m?.[i]),
                precipIn: numOrNull(h.precipitation?.[i]),
                windMph: numOrNull(h.wind_speed_10m?.[i]),
                gustMph: numOrNull(h.wind_gusts_10m?.[i]),
            }));

            const d = wx.daily || {};
            next.daily = (d.time || []).map((t, i) => ({
                date: t * 1000,
                hiF: numOrNull(d.temperature_2m_max?.[i]),
                loF: numOrNull(d.temperature_2m_min?.[i]),
                code: numOrNull(d.weather_code?.[i]),
                cloudPct: numOrNull(d.cloud_cover_mean?.[i]),
                precipProbMax: numOrNull(d.precipitation_probability_max?.[i]),
                feelsHiF: numOrNull(d.apparent_temperature_max?.[i]),
                feelsLoF: numOrNull(d.apparent_temperature_min?.[i]),
                precipIn: numOrNull(d.precipitation_sum?.[i]),
                snowIn: numOrNull(d.snowfall_sum?.[i]),
                precipHours: numOrNull(d.precipitation_hours?.[i]),
                windMaxMph: numOrNull(d.wind_speed_10m_max?.[i]),
                gustMaxMph: numOrNull(d.wind_gusts_10m_max?.[i]),
                windDirDeg: numOrNull(d.wind_direction_10m_dominant?.[i]),
                uvMax: numOrNull(d.uv_index_max?.[i]),
                // unixtime seconds → ms (timeformat=unixtime applies here too)
                sunrise: numOrNull(d.sunrise?.[i]) != null ? d.sunrise[i] * 1000 : null,
                sunset: numOrNull(d.sunset?.[i]) != null ? d.sunset[i] * 1000 : null,
            }));

            // UV now + today's peak. "Today" = the first daily bucket's local
            // day; daily[0].date is local midnight thanks to timezone=auto.
            const dayStart = next.daily[0]?.date ?? nowMs - 12 * HOUR_MS;
            const dayEnd = dayStart + 24 * HOUR_MS;
            let uvNow = null, uvPeak = null, uvPeakHour = null;
            for (const row of next.hourly) {
                if (row.uv == null) continue;
                if (row.time <= nowMs && nowMs - row.time < HOUR_MS) uvNow = row.uv;
                if (row.time >= dayStart && row.time < dayEnd && (uvPeak == null || row.uv > uvPeak)) {
                    uvPeak = row.uv;
                    uvPeakHour = row.time;
                }
            }
            next.uvNow = uvNow;
            next.uvPeak = uvPeak;
            next.uvPeakHour = uvPeakHour;
        }

        if (aqRes.status === 'fulfilled') {
            const normalized = normalizeAirQuality(aqRes.value, nowMs);
            next.aqi = normalized.aqi;
            next.aqiHourly = normalized.aqiHourly;
            next.pollutants = normalized.pollutants;
            next.pollutionHourly = normalized.pollutionHourly;
            next.pollutionUnits = normalized.pollutionUnits;
            next.airSource = AIR_QUALITY_SOURCE;
            next.aqiMethod = normalized.aqiMethod;
            next.aqiUpstream24h = normalized.aqiUpstream24h;
            next.aqiNowcast = normalized.aqiNowcast;
            next.aqiDominant = normalized.aqiDominant;
            next.aqiSubIndices = normalized.aqiSubIndices;
            next.aqiMethods = normalized.aqiMethods;
            next.aqiNotes = normalized.aqiNotes;
            next.aqiValidAt = normalized.aqiValidAt;
            next.upstreamValidAt = normalized.upstreamValidAt;
            next.aqiAgeMs = normalized.aqiAgeMs;
            next.pollutantsValidAt = normalized.pollutantsValidAt;
            next.pollutantsAgeMs = normalized.pollutantsAgeMs;
            next.stale = normalized.stale;
            next.aligned = normalized.aligned;
        }

        next.status = 'live';
        next.fetchedAt = nowMs;
        this._state = next;
        this._fetchedKey = key;
        this._fetchedAt = nowMs;
        this._dispatch();
    }

    _dispatch() {
        try {
            window.dispatchEvent(new CustomEvent('ev-air-update', { detail: this._state }));
        } catch { /* consumers are optional */ }
    }
}

/**
 * Normalize one Open-Meteo/CAMS response into the feed's stable schema.
 * Exported for a small contract test; it is deliberately pure so later
 * AirNow/OpenAQ station adapters can be tested against the same field names.
 */
export function normalizeAirQuality(payload = {}, nowMs = Date.now()) {
    const aq = payload.hourly || {};
    const times = Array.isArray(aq.time) ? aq.time : [];
    const units = payload.hourly_units || {};

    // Current model hour; if the upstream run lags, use the newest available
    // hour at or before now. Never substitute a future forecast for "now",
    // and never reach further back than AQI_MAX_AGE_MS — see the constant.
    const usable = (i) => {
        const t = times[i] * 1000;
        return t <= nowMs && nowMs - t <= AQI_MAX_AGE_MS;
    };
    let currentIdx = -1;
    for (let i = 0; i < times.length; i++) {
        const t = times[i] * 1000;
        if (t <= nowMs && nowMs - t < HOUR_MS && hasAirValue(aq, i)) {
            currentIdx = i;
            break;
        }
    }
    if (currentIdx < 0) {
        for (let i = times.length - 1; i >= 0; i--) {
            if (usable(i) && hasAirValue(aq, i)) {
                currentIdx = i;
                break;
            }
        }
    }

    // Preserve the feed's pre-pollution behavior when the composite AQI is
    // published later than the component concentrations: the chip may use
    // the newest past AQI while the pollutant grid stays on one aligned
    // current model hour. Provenance remains modeled for both.
    //
    // That split is deliberate, but it means the AQI and the pollutant grid
    // rendered beside it can be from DIFFERENT hours. Both valid times ride
    // the result now, plus `aligned`, so a consumer showing them together can
    // say so instead of implying one consistent snapshot.
    let aqiIdx = currentIdx >= 0 && Number.isFinite(aq.us_aqi?.[currentIdx])
        ? currentIdx : -1;
    if (aqiIdx < 0) {
        for (let i = times.length - 1; i >= 0; i--) {
            if (usable(i) && Number.isFinite(aq.us_aqi?.[i])) {
                aqiIdx = i;
                break;
            }
        }
    }

    const rowAt = (i) => {
        const row = { time: times[i] * 1000, aqi: numOrNull(aq.us_aqi?.[i]) };
        for (const [appName, upstreamName] of Object.entries(POLLUTANT_FIELDS)) {
            row[appName] = numOrNull(aq[upstreamName]?.[i]);
        }
        return row;
    };
    const pollutionHourly = times
        .map((_, i) => rowAt(i))
        .filter(row => row.aqi != null || Object.keys(POLLUTANT_FIELDS).some(k => row[k] != null));
    const current = currentIdx >= 0 ? rowAt(currentIdx) : null;
    const pollutants = emptyPollutants();
    for (const appName of Object.keys(POLLUTANT_FIELDS)) {
        pollutants[appName] = current?.[appName] ?? null;
    }
    const pollutionUnits = {};
    for (const [appName, upstreamName] of Object.entries(POLLUTANT_FIELDS)) {
        pollutionUnits[appName] = units[upstreamName] || defaultUnit(appName);
    }

    // NowCast — the real-time composite, rebuilt from the hourly component
    // series. Upstream's us_aqi is EPA's DAILY definition (24-h running mean
    // for PM); NowCast is the REAL-TIME one AirNow publishes, and it is what
    // a user comparing against their phone actually sees. Both are kept: the
    // upstream value rides as aqiUpstream24h so the two can be compared,
    // which is the site's whole "show where the model and reality differ"
    // thesis rather than a silent swap.
    const nowcastSeries = {};
    for (const [field, pollutant] of Object.entries(NOWCAST_FIELDS)) {
        const rows = pollutionHourly
            .filter(row => row[field] != null)
            .map(row => ({ time: row.time, value: row[field] }));
        if (rows.length) nowcastSeries[pollutant] = rows;
    }
    const nowcast = nowcastAqi(nowcastSeries, { nowMs, unit: 'µg/m³' });

    const upstreamValidAt = aqiIdx >= 0 ? times[aqiIdx] * 1000 : null;
    const pollutantsValidAt = currentIdx >= 0 ? times[currentIdx] * 1000 : null;
    // NowCast is anchored on the trailing window ending at the current model
    // hour, so its valid time is the pollutants' hour — not the (possibly
    // older) hour the upstream composite happened to be published for.
    const aqiValidAt = nowcast.aqi != null ? pollutantsValidAt : upstreamValidAt;
    const ageOf = (t) => (t == null ? null : Math.max(0, nowMs - t));
    const aqiAgeMs = ageOf(aqiValidAt);
    const pollutantsAgeMs = ageOf(pollutantsValidAt);

    const upstream24h = aqiIdx >= 0 ? numOrNull(aq.us_aqi?.[aqiIdx]) : null;

    return {
        // The headline number is NowCast when it is computable, and the
        // upstream 24-h composite otherwise. `aqiMethod` says which, always.
        aqi: nowcast.aqi ?? upstream24h,
        aqiMethod: nowcast.aqi != null ? 'nowcast' : (upstream24h != null ? 'upstream-24h' : null),
        aqiUpstream24h: upstream24h,
        aqiNowcast: nowcast.aqi,
        aqiDominant: nowcast.dominant,
        aqiSubIndices: nowcast.subIndices,
        aqiMethods: nowcast.methods,
        aqiNotes: nowcast.notes,
        aqiHourly: pollutionHourly
            .filter(row => row.aqi != null)
            .map(row => ({ time: row.time, aqi: row.aqi })),
        pollutants,
        pollutionHourly,
        pollutionUnits,
        // Temporal provenance. Without these the card could render a value
        // hours old under a "current model hour" label with nothing to
        // contradict it — see AQI_STALE_AFTER_MS.
        aqiValidAt,
        aqiAgeMs,
        upstreamValidAt,
        pollutantsValidAt,
        pollutantsAgeMs,
        stale: [aqiAgeMs, pollutantsAgeMs]
            .some(age => age != null && age >= AQI_STALE_AFTER_MS),
        // With NowCast the headline and the pollutant grid share the current
        // hour by construction, so they are aligned whenever both exist.
        aligned: nowcast.aqi != null
            ? (pollutantsValidAt != null ? true : null)
            : (aqiIdx >= 0 && currentIdx >= 0 ? aqiIdx === currentIdx : null),
    };
}

function hasAirValue(aq, i) {
    if (Number.isFinite(aq.us_aqi?.[i])) return true;
    return Object.values(POLLUTANT_FIELDS).some(name => Number.isFinite(aq[name]?.[i]));
}

function emptyPollutants() {
    return Object.fromEntries(Object.keys(POLLUTANT_FIELDS).map(name => [name, null]));
}

function defaultUnit(name) {
    return name === 'aerosolOpticalDepth' ? '' : 'µg/m³';
}

function numOrNull(v) {
    return Number.isFinite(v) ? v : null;
}

export default AirQualityFeed;
