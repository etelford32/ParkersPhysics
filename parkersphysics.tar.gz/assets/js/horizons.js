/**
 * horizons.js — Real-time planetary ephemeris for the Celestial Simulator
 *
 * Provides precise positions for all 8 planets + Moon at the current instant.
 *
 * PRIMARY   NASA JPL Horizons Web API (state vectors, ECLIPJ2000 frame)
 *           https://ssd.jpl.nasa.gov/horizons/manual.html
 *           Earth heliocentric   (CENTER='500@10',  COMMAND='399')
 *           Moon  geocentric     (CENTER='500@399', COMMAND='301')
 *           Outer planets helio  (CENTER='500@10',  COMMAND='5xx/6xx/7xx/8xx')
 *           Mars surface sky     (CENTER='coord@499', observer AZ/EL)
 *           Response units: AU for heliocentric, km for geocentric.
 *
 * FALLBACK  On-device Meeus algorithms (Astronomical Algorithms, 2nd ed.)
 *           Earth    Ch.25 — accurate to ~0.01° for 1950–2050
 *           Moon     Ch.47 — accurate to ~1° (16-term longitude series)
 *           Inner planets — simplified Kepler + full 3D orbital rotation
 *           Outer planets — VSOP87D truncated series (~0.05–0.1° accuracy)
 *           All planet positions include ecliptic latitude from inclination.
 *           Always works offline; no network latency.
 *
 * OWNERSHIP
 * ─────────────────────────────────────────────────────────────────
 *  This file owns planet body IDs 199 (Mercury) through 899 (Neptune) and
 *  Moon (301).  extended-feeds.js / HorizonsFeed must NOT poll these IDs —
 *  it handles spacecraft (-234 STEREO-A, etc.) only via 'horizons-update'.
 *
 * OUTPUT (ephemeris-ready CustomEvent on window)
 * ─────────────────────────────────────────────────────────────────
 *  detail.mercury  { lon_rad, lat_rad, dist_AU, x_AU, y_AU, z_AU }  heliocentric ecliptic
 *  detail.venus    { lon_rad, lat_rad, dist_AU, x_AU, y_AU, z_AU }
 *  detail.earth    { lon_rad, lat_rad, dist_AU, x_AU, y_AU, z_AU }
 *  detail.moon     { lon_rad, lat_rad, dist_km, dist_AU }            geocentric
 *  detail.mars     { lon_rad, lat_rad, dist_AU, x_AU, y_AU, z_AU }
 *  detail.jupiter  { lon_rad, lat_rad, dist_AU, x_AU, y_AU, z_AU }
 *  detail.saturn   { lon_rad, lat_rad, dist_AU, x_AU, y_AU, z_AU }
 *  detail.uranus   { lon_rad, lat_rad, dist_AU, x_AU, y_AU, z_AU }
 *  detail.neptune  { lon_rad, lat_rad, dist_AU, x_AU, y_AU, z_AU }
 *  detail.jd       number — Julian Day of fetch
 *  detail.source   'horizons' | 'meeus' | 'mixed'
 *  detail.timestamp  Date
 *
 * USAGE
 * ─────────────────────────────────────────────────────────────────
 *  import { EphemerisService } from './js/horizons.js';
 *
 *  const svc = new EphemerisService();
 *  svc.startLive(60);   // fires 'ephemeris-ready' every 60 s
 *
 *  window.addEventListener('ephemeris-ready', ev => {
 *      const { mercury, venus, earth, moon, mars,
 *              jupiter, saturn, uranus, neptune, source } = ev.detail;
 *      // earth.x_AU, earth.y_AU, earth.z_AU  → ECLIPJ2000 Cartesian (AU)
 *  });
 */

import { vsop87Earth } from './earth-orbit.js';
import { jupiterVSOP, saturnVSOP, uranusVSOP, neptuneVSOP } from './outer-planets.js';

// ── Julian Day helpers ────────────────────────────────────────────────────────

/** Julian Day Number from current UTC instant. */
export function jdNow() {
    return Date.now() / 86400000 + 2440587.5;
}

/** Julian Day Number from a Date object. */
export function jdFromDate(d) {
    return d.getTime() / 86400000 + 2440587.5;
}

/** Calendar date from Julian Day Number (UTC). */
export function dateFromJD(jd) {
    return new Date((jd - 2440587.5) * 86400000);
}

// ── Meeus on-device algorithms ────────────────────────────────────────────────

const D2R = Math.PI / 180;
const R2D = 180 / Math.PI;

/**
 * Earth's heliocentric ecliptic position via VSOP87D truncated series.
 *
 * Replaces the Meeus Ch.25 three-term equation of center.
 * Accuracy: < 1″ heliocentric longitude, < 0.000001 AU radius (1900–2100).
 *
 * @param {number} jd  Julian Day Number (default: now)
 * @returns {{ lon: number, lon_rad: number, lat_rad: number, dist_AU: number,
 *             x_AU: number, y_AU: number, z_AU: number }}
 */
export function earthHeliocentric(jd = jdNow()) {
    const v = vsop87Earth(jd);
    const lon = ((v.L_rad * R2D) % 360 + 360) % 360;
    return {
        lon,
        lon_rad:  v.L_rad,
        lat_rad:  v.B_rad,
        dist_AU:  v.R_AU,
        x_AU:     v.x_AU,
        y_AU:     v.y_AU,
        z_AU:     v.z_AU,
    };
}

/**
 * Moon's geocentric ecliptic longitude, latitude, and distance.
 *
 * Source: Meeus, "Astronomical Algorithms" 2nd ed., Chapter 47 (top terms).
 * Accuracy: ~1° longitude, ~0.1° latitude, ~100 km distance.
 *
 * @param {number} jd  Julian Day Number (default: now)
 * @returns {{ lon: number, lon_rad: number, lat: number, lat_rad: number,
 *             dist_km: number, dist_AU: number }}
 */
export function moonGeocentric(jd = jdNow()) {
    const T = (jd - 2451545.0) / 36525.0;

    // ── Fundamental arguments (degrees) ──────────────────────────────────
    const Lp_deg = 218.3164477 + 481267.88123421 * T;
    const D_deg  = 297.8501921 + 445267.1114034  * T;
    const M_deg  = 357.5291092 +  35999.0502909  * T;
    const Mp_deg = 134.9633964 + 477198.8675055  * T;
    const F_deg  =  93.2720950 + 483202.0175233  * T;

    const Lr  = (Lp_deg % 360) * D2R;
    const Dr  = (D_deg  % 360) * D2R;
    const Mr  = (M_deg  % 360) * D2R;
    const Mpr = (Mp_deg % 360) * D2R;
    const Fr  = (F_deg  % 360) * D2R;

    // ── Longitude perturbations (units: 10⁻⁶ °) — 16 dominant terms ─────
    const dL =
          6288774 * Math.sin(Mpr)
        + 1274027 * Math.sin(2*Dr - Mpr)
        +  658314 * Math.sin(2*Dr)
        +  213618 * Math.sin(2*Mpr)
        -  185116 * Math.sin(Mr)
        -  114332 * Math.sin(2*Fr)
        +   58793 * Math.sin(2*Dr - 2*Mpr)
        +   57066 * Math.sin(2*Dr - Mr - Mpr)
        +   53322 * Math.sin(2*Dr + Mpr)
        +   45758 * Math.sin(2*Dr - Mr)
        -   40923 * Math.sin(Mr  - Mpr)
        -   34720 * Math.sin(Dr)
        -   30383 * Math.sin(Mr  + Mpr)
        +   15327 * Math.sin(2*Dr - 2*Fr)
        -   12528 * Math.sin(Mpr + 2*Fr)
        +   10980 * Math.sin(Mpr - 2*Fr);

    const lon = ((Lp_deg + dL / 1e6) % 360 + 360) % 360;

    // ── Latitude perturbations (units: 10⁻⁶ °) — 8 dominant terms ───────
    const dB =
          5128122 * Math.sin(Fr)
        +  280602 * Math.sin(Mpr + Fr)
        +  277693 * Math.sin(Mpr - Fr)
        +  173237 * Math.sin(2*Dr - Fr)
        +   55413 * Math.sin(2*Dr - Mpr + Fr)
        +   46271 * Math.sin(2*Dr - Mpr - Fr)
        +   32573 * Math.sin(2*Dr + Fr)
        +   17198 * Math.sin(2*Mpr + Fr);

    const lat = dB / 1e6;

    // ── Distance from Earth center (km) — 10 dominant terms ──────────────
    const dR =
        -20905355 * Math.cos(Mpr)
        - 3699111 * Math.cos(2*Dr - Mpr)
        - 2955968 * Math.cos(2*Dr)
        -  569925 * Math.cos(2*Mpr)
        +   48888 * Math.cos(Mr)
        -    3149 * Math.cos(2*Fr)
        +  246158 * Math.cos(2*Dr - 2*Mpr)
        -  152138 * Math.cos(2*Dr - Mr - Mpr)
        -  170733 * Math.cos(2*Dr + Mpr)
        -  204586 * Math.cos(2*Dr - Mr);

    const dist_km = 385000.56 + dR / 1000;

    return {
        lon,      lon_rad: lon     * D2R,
        lat,      lat_rad: lat     * D2R,
        dist_km,  dist_AU: dist_km / 149597870.7,
    };
}

/**
 * Generic heliocentric 3D position from simplified Keplerian elements.
 *
 * Computes the full ecliptic XYZ position including orbital inclination
 * via the standard orbital-plane → ecliptic rotation:
 *   x = r[cosΩ·cos(ω+ν) − sinΩ·sin(ω+ν)·cosi]
 *   y = r[sinΩ·cos(ω+ν) + cosΩ·sin(ω+ν)·cosi]
 *   z = r[sin(ω+ν)·sini]
 *
 * Equation of center: 3-term series, accurate to ~0.01° for e < 0.1,
 * ~0.3° for Mercury (e ≈ 0.206).
 *
 * Source: Meeus, "Astronomical Algorithms" 2nd ed., Table 31.a (J2000 epoch).
 *
 * @param {number} jd
 * @param {object} el  Orbital elements at J2000 with optional secular rates
 *   L0:       Mean longitude at J2000 (degrees)
 *   Ldot:     Rate of mean longitude (degrees / Julian century)
 *   a:        Semi-major axis (AU)
 *   e:        Eccentricity at J2000
 *   omega:    Longitude of perihelion ω̄ = Ω + ω (degrees) at J2000
 *   i:        Inclination to ecliptic (degrees) at J2000
 *   node:     Longitude of ascending node Ω (degrees) at J2000
 *   --- optional secular rates (per Julian century) ---
 *   adot:     Semi-major axis rate (AU/cy) — usually ~0
 *   edot:     Eccentricity rate (/cy)
 *   omegadot: Perihelion longitude rate (°/cy)
 *   idot:     Inclination rate (°/cy)
 *   nodedot:  Node longitude rate (°/cy)
 *
 * Secular rates from Standish (1992) "Keplerian Elements for Approximate
 * Positions of the Major Planets" (JPL Solar System Dynamics).
 * Extends accuracy from ±50 years to ±3000 years for outer planets.
 *
 * @returns {{ lon_rad, lat_rad, dist_AU, x_AU, y_AU, z_AU }}
 */
function planetHeliocentric(jd, el) {
    const T = (jd - 2451545.0) / 36525.0;

    // Apply secular corrections if provided
    const a     = el.a     + (el.adot     ?? 0) * T;
    const e     = el.e     + (el.edot     ?? 0) * T;
    const omega = el.omega + (el.omegadot ?? 0) * T;
    const inc   = el.i     + (el.idot     ?? 0) * T;
    const node  = el.node  + (el.nodedot  ?? 0) * T;

    // Mean longitude and anomaly
    const L   = ((el.L0 + el.Ldot * T) % 360 + 360) % 360;
    const M   = ((L - omega) % 360 + 360) % 360;
    const Mr  = M * D2R;
    // Equation of center (3-term, good to ~0.01° for e < 0.1; ~0.3° for Mercury)
    const nu_minus_M = (2 * e - e*e*e / 4) * Math.sin(Mr)
                     + (5/4)  * e*e         * Math.sin(2 * Mr)
                     + (13/12) * e*e*e      * Math.sin(3 * Mr);

    const nu      = Mr + nu_minus_M;                               // true anomaly (rad)
    const dist_AU = (a * (1 - e * e)) / (1 + e * Math.cos(nu));

    // Orbital-plane → heliocentric ecliptic XYZ
    // argument of perihelion ω (lowercase) = ω̄ − Ω
    const nodeR  = node  * D2R;
    const iR     = inc   * D2R;
    const argPer = (omega - node) * D2R;   // ω in radians
    const u      = argPer + nu;                    // argument of latitude

    const cosO = Math.cos(nodeR), sinO = Math.sin(nodeR);
    const cosU = Math.cos(u),     sinU = Math.sin(u);
    const cosI = Math.cos(iR),    sinI = Math.sin(iR);

    const x_AU = dist_AU * (cosO * cosU - sinO * sinU * cosI);
    const y_AU = dist_AU * (sinO * cosU + cosO * sinU * cosI);
    const z_AU = dist_AU * (sinU * sinI);

    const lon_rad = Math.atan2(y_AU, x_AU);
    const lat_rad = Math.asin(Math.max(-1, Math.min(1, z_AU / dist_AU)));
    const lon     = ((lon_rad * R2D) % 360 + 360) % 360;

    return { lon, lon_rad, lat_rad, dist_AU, x_AU, y_AU, z_AU };
}

// ── Orbital elements at J2000.0  (Meeus Table 31.a) ─────────────────────────
// L0:    mean longitude (°)      Ldot:  rate (°/Julian century)
// a:     semi-major axis (AU)    e:     eccentricity
// omega: longitude of perihelion (°) = Ω + ω
// i:     inclination to ecliptic (°)
// node:  longitude of ascending node Ω (°)

// Orbital elements at J2000.0 with secular correction rates (per Julian century).
// Base elements: Meeus Table 31.a.
// Secular rates: Standish (1992) "Keplerian Elements for Approximate Positions
// of the Major Planets" + E.M. Standish & J.G. Williams (JPL).
// These rates extend accuracy from ±50 yr to ±3000 yr for outer planets.
//
// DATA QUALITY NOTE: The 3-term equation of center used here gives ~0.3°
// accuracy for Mercury (e≈0.206) and ~0.01° for Venus (e≈0.007).  For
// sub-arcminute accuracy, a full Kepler equation solver would be needed.
// The secular rates are first-order (linear); over millennia, higher-order
// perturbation terms (mutual gravitational interactions) become important.

const MERCURY_EL = {
    L0: 252.250906, Ldot: 149472.6746358, a: 0.38709831, e: 0.20563175,
    omega: 77.456119,  i: 7.004986, node: 48.330893,
    adot: 0, edot: 0.00002123, omegadot: 0.16047, idot: -0.00594, nodedot: -0.12534,
};
// Earth/Moon barycenter — Standish (1992) Table 1, valid ±3000 yr.
// Position is computed from VSOP87D in earthHeliocentric(); these elements
// are used only by planetElementsAt() for the orbital-element panel and the
// long-horizon apsidal-precession plot.
const EARTH_EL = {
    L0: 100.46457166, Ldot: 35999.37244981, a: 1.00000261, e: 0.01671123,
    omega: 102.93768193, i: -0.00001531, node: 0.0,
    adot: 0.00000562, edot: -0.00004392, omegadot: 0.32327364, idot: -0.01294668, nodedot: 0.0,
};
const VENUS_EL = {
    L0: 181.979801, Ldot: 58517.8156760, a: 0.72332982, e: 0.00677323,
    omega: 131.563703, i: 3.394662, node: 76.679920,
    adot: 0, edot: -0.00004938, omegadot: 0.00268, idot: -0.00078, nodedot: -0.27769,
};
const MARS_EL = {
    L0: 355.433275, Ldot: 19140.2993313, a: 1.52366231, e: 0.09341233,
    omega: 336.060234, i: 1.849726, node: 49.558093,
    adot: 0, edot: 0.00007882, omegadot: 0.44441, idot: -0.00813, nodedot: -0.29257,
};
const JUPITER_EL = {
    L0: 34.351519, Ldot: 3034.9056606, a: 5.20260319, e: 0.04849793,
    omega: 14.331309, i: 1.303270, node: 100.464441,
    adot: -0.00012880, edot: 0.00018026, omegadot: 0.21252, idot: -0.00198, nodedot: 0.13665,
};
const SATURN_EL = {
    L0: 50.077444, Ldot: 1222.1138488, a: 9.55491122, e: 0.05550825,
    omega: 93.056787, i: 2.488879, node: 113.665527,
    adot: -0.00003065, edot: -0.00032044, omegadot: 0.54196, idot: 0.00175, nodedot: -0.24688,
};
const URANUS_EL = {
    L0: 314.055005, Ldot: 428.4669983, a: 19.2184461, e: 0.04629590,
    omega: 173.005291, i: 0.773197, node: 74.005957,
    adot: -0.00020455, edot: -0.00015503, omegadot: 0.09266, idot: -0.00255, nodedot: 0.04240,
};
const NEPTUNE_EL = {
    L0: 304.348665, Ldot: 218.4862002, a: 30.1103869, e: 0.00898809,
    omega: 48.120275, i: 1.769953, node: 131.784057,
    adot: 0.00006447, edot: 0.00000818, omegadot: 0.01009, idot: -0.00255, nodedot: -0.00598,
};

/**
 * Public planet element table — keyed by lowercase body name.
 *
 * Each entry holds the J2000 Keplerian elements plus secular rates per
 * Julian century. Sources:
 *   Mercury–Mars      Meeus Table 31.a + Standish (1992) rates
 *   Earth             Standish (1992) Table 1
 *   Jupiter–Neptune   Meeus Table 31.a + Standish (1992) rates
 *
 * Earth's *position* still comes from the VSOP87D series in
 * earthHeliocentric(); these mean elements drive the orbital-element panel
 * and the long-horizon apsidal-precession diagnostic.
 */
export const PLANET_ELEMENTS = {
    mercury: MERCURY_EL,
    venus:   VENUS_EL,
    earth:   EARTH_EL,
    mars:    MARS_EL,
    jupiter: JUPITER_EL,
    saturn:  SATURN_EL,
    uranus:  URANUS_EL,
    neptune: NEPTUNE_EL,
};

/**
 * Osculating-style mean Keplerian elements at an arbitrary epoch.
 *
 * Applies the linear secular rates to the J2000 base elements:
 *   a(T)  = a0  + adot · T
 *   e(T)  = e0  + edot · T   etc., where T = (jd − 2451545) / 36525.
 *
 * Returns degrees (not radians) for the angular elements so they can be
 * shown directly in a UI table. M is the mean anomaly = L − ω̄ wrapped
 * into [0,360).
 *
 * Validity: ±3 kyr full accuracy; degrades smoothly out to ±10 kyr where
 * higher-order secular and resonant terms (Milankovitch cycles, Jupiter–
 * Saturn great inequality) become non-negligible.
 *
 * @param {string} key  Lowercase body name ('mercury' .. 'neptune')
 * @param {number} jd   Julian Day Number
 * @returns {{ a:number, e:number, i:number, node:number, omegaBar:number,
 *             M:number, L:number, T:number }}
 */
export function planetElementsAt(key, jd = jdNow()) {
    const el = PLANET_ELEMENTS[key];
    if (!el) throw new Error(`planetElementsAt: unknown body "${key}"`);
    const T = (jd - 2451545.0) / 36525.0;
    const a    = el.a    + (el.adot     ?? 0) * T;
    const e    = el.e    + (el.edot     ?? 0) * T;
    const inc  = el.i    + (el.idot     ?? 0) * T;
    const node = el.node + (el.nodedot  ?? 0) * T;
    const wbar = el.omega+ (el.omegadot ?? 0) * T;
    const L    = ((el.L0 + el.Ldot * T) % 360 + 360) % 360;
    const M    = ((L - wbar) % 360 + 360) % 360;
    return { a, e, i: inc, node, omegaBar: wbar, M, L, T };
}

/**
 * Mercury's heliocentric ecliptic position (full 3D).
 * Accuracy: ~0.5° for 1950–2050.
 */
export function mercuryHeliocentric(jd = jdNow()) {
    return planetHeliocentric(jd, MERCURY_EL);
}

/**
 * Venus's heliocentric ecliptic position (full 3D).
 * Accuracy: ~0.1° for 1950–2050.
 */
export function venusHeliocentric(jd = jdNow()) {
    return planetHeliocentric(jd, VENUS_EL);
}

/**
 * Mars's heliocentric ecliptic position (full 3D).
 * Accuracy: ~0.3° for 1950–2050.
 */
export function marsHeliocentric(jd = jdNow()) {
    return planetHeliocentric(jd, MARS_EL);
}

/**
 * Jupiter's heliocentric ecliptic position — VSOP87D truncated series.
 * Accuracy: ~0.05° for 1800–2200.
 */
export function jupiterHeliocentric(jd = jdNow()) {
    return jupiterVSOP(jd);
}

/**
 * Saturn's heliocentric ecliptic position — VSOP87D truncated series.
 * Includes the "great inequality" term (±0.81° error without it).
 * Accuracy: ~0.05° for 1800–2200.
 */
export function saturnHeliocentric(jd = jdNow()) {
    return saturnVSOP(jd);
}

/**
 * Uranus's heliocentric ecliptic position — VSOP87D truncated series.
 * Accuracy: ~0.1° for 1800–2200.
 */
export function uranusHeliocentric(jd = jdNow()) {
    return uranusVSOP(jd);
}

/**
 * Neptune's heliocentric ecliptic position — VSOP87D truncated series.
 * Accuracy: ~0.1° for 1800–2200.
 */
export function neptuneHeliocentric(jd = jdNow()) {
    return neptuneVSOP(jd);
}

// ── NASA JPL Horizons REST API ────────────────────────────────────────────────
// Use a same-origin proxy (/api/horizons) so the browser avoids CORS.
// Falls back to direct JPL if the proxy is unavailable (caught upstream).
const HORIZONS_URL = '/api/horizons';

function _horizonsParams(command, center, jd = null) {
    // If a JD is provided, compute start/stop dates from it.
    // Otherwise use current time (real-time mode).
    const d     = jd != null ? dateFromJD(jd) : new Date();
    const start = d.toISOString().slice(0, 10);
    const stop  = new Date(d.getTime() + 86400e3).toISOString().slice(0, 10);
    return new URLSearchParams({
        format:     'json',
        COMMAND:    command,
        EPHEM_TYPE: 'VECTORS',
        CENTER:     center,
        START_TIME: start,
        STOP_TIME:  stop,
        STEP_SIZE:  '1d',
        VEC_TABLE:  '2',
        VEC_LABELS: 'YES',
        OBJ_DATA:   'NO',
        REF_FRAME:  'ECLIPJ2000',
        CAL_FORMAT: 'BOTH',
    });
}

function _parseVec(text) {
    const soe = text.indexOf('$$SOE');
    const eoe = text.indexOf('$$EOE');
    if (soe < 0 || eoe < 0) throw new Error('Missing $$SOE/$$EOE markers');
    const block = text.slice(soe + 5, eoe);
    const xm = block.match(/X\s*=\s*([-+]?[\d.E+\-]+)/i);
    const ym = block.match(/Y\s*=\s*([-+]?[\d.E+\-]+)/i);
    const zm = block.match(/Z\s*=\s*([-+]?[\d.E+\-]+)/i);
    if (!xm || !ym || !zm) throw new Error('Cannot parse X/Y/Z from block');
    return { x: parseFloat(xm[1]), y: parseFloat(ym[1]), z: parseFloat(zm[1]) };
}

async function _fetchVec(command, center, jd = null) {
    const params = _horizonsParams(command, center, jd);
    const result = await _fetchHorizonsResult(params);
    return _parseVec(result);
}

async function _fetchHorizonsResult(params) {
    const url    = `${HORIZONS_URL}?${params}`;
    const resp   = await fetch(url, { cache: 'no-cache' });
    if (!resp.ok) {
        // Log the upstream error body for debugging
        let body = '';
        try { body = await resp.text(); } catch (_) {}
        const detail = body.slice(0, 200);
        throw new Error(`Horizons HTTP ${resp.status}: ${detail}`);
    }
    const json = await resp.json();
    if (json.error) throw new Error(`Horizons API: ${json.error}`);
    if (typeof json.result !== 'string') throw new Error('Horizons: no result string');
    return json.result;
}

/** Convert an ECLIPJ2000 X/Y/Z vector (in AU) to heliocentric ecliptic coords. */
function _vecToHelioEcliptic(v) {
    const r = Math.sqrt(v.x**2 + v.y**2 + v.z**2);
    return {
        lon_rad:  Math.atan2(v.y, v.x),
        lat_rad:  Math.asin(Math.max(-1, Math.min(1, v.z / r))),
        dist_AU:  r,
        x_AU: v.x, y_AU: v.y, z_AU: v.z,
        source: 'horizons',
    };
}

// ── Mars topocentric sky ─────────────────────────────────────────────────────

/** Bodies shown in the Real-Time Mars sky layer. Small-body commands retain
 * Horizons' required semicolon so `1;` and `4;` select numbered asteroids,
 * not a major-body ID or an ambiguous name search. */
export const MARS_SKY_BODIES = Object.freeze([
    Object.freeze({ key: 'sun',   name: 'Sun',   command: '10' }),
    Object.freeze({ key: 'earth', name: 'Earth', command: '399' }),
    Object.freeze({ key: 'moon',  name: 'Moon',  command: '301' }),
    Object.freeze({ key: 'ceres', name: 'Ceres', command: '1;' }),
    Object.freeze({ key: 'vesta', name: 'Vesta', command: '4;' }),
]);

const MARS_EQUATORIAL_RADIUS_KM = 3396.19;
const MARS_POLAR_RADIUS_KM = 3376.2;

/** Horizons' user-defined Mars sites use geodetic latitude, while NASA's
 * MMGIS rover waypoints are planetocentric. Convert on the IAU_MARS reference
 * ellipsoid before building SITE_COORD. */
export function marsPlanetocentricToGeodetic(latDeg) {
    if (!Number.isFinite(latDeg) || Math.abs(latDeg) > 90) throw new RangeError('Mars latitude must be finite and within ±90°');
    if (Math.abs(latDeg) === 90) return latDeg;
    const radians = Math.PI / 180;
    return Math.atan(
        Math.tan(latDeg * radians)
        * MARS_EQUATORIAL_RADIUS_KM ** 2 / MARS_POLAR_RADIUS_KM ** 2,
    ) / radians;
}

function marsSkySampleWindow(date) {
    const jd = jdFromDate(date);
    const startJd = Math.floor(jd * 24) / 24;
    return { startJd, stopJd: startJd + 1 / 24 };
}

function parseHorizonsCalendarUtc(value) {
    const match = value.trim().match(/^(\d{4})-([A-Za-z]{3})-(\d{2})\s+(\d{2}):(\d{2}):(\d{2}(?:\.\d+)?)$/);
    if (!match) throw new Error(`Horizons: unsupported observer timestamp ${value}`);
    const month = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
        .indexOf(match[2][0].toUpperCase() + match[2].slice(1).toLowerCase());
    if (month < 0) throw new Error(`Horizons: unsupported observer month ${match[2]}`);
    const seconds = Number(match[6]);
    const wholeSeconds = Math.floor(seconds);
    const milliseconds = Math.round((seconds - wholeSeconds) * 1000);
    return new Date(Date.UTC(
        Number(match[1]), month, Number(match[3]), Number(match[4]), Number(match[5]),
        wholeSeconds, milliseconds,
    ));
}

/** Parse quantity 4 + 20 from a Horizons CSV observer table. Parsing from the
 * right keeps the two single-character presence/RTS columns from affecting
 * field positions when a body rises, sets, or is observed in daylight. */
export function parseHorizonsObserverTable(text) {
    const start = text.indexOf('$$SOE');
    const stop = text.indexOf('$$EOE');
    if (start < 0 || stop < 0 || stop <= start) throw new Error('Horizons: missing observer table markers');
    const rows = text.slice(start + 5, stop).split('\n').map(line => line.trim()).filter(Boolean);
    if (!rows.length) throw new Error('Horizons: observer table is empty');
    return rows.map(line => {
        const fields = line.split(',').map(field => field.trim());
        while (fields.at(-1) === '') fields.pop();
        if (fields.length < 5) throw new Error(`Horizons: malformed observer row ${line}`);
        const [azimuthDeg, elevationDeg, rangeAu, rangeRateKmS] = fields.slice(-4).map(Number);
        if (![azimuthDeg, elevationDeg, rangeAu, rangeRateKmS].every(Number.isFinite)) {
            throw new Error(`Horizons: non-numeric observer row ${line}`);
        }
        const observed = parseHorizonsCalendarUtc(fields[0]);
        return Object.freeze({
            observed_at: observed.toISOString(),
            jd: jdFromDate(observed),
            azimuth_deg: azimuthDeg,
            elevation_deg: elevationDeg,
            range_au: rangeAu,
            range_rate_km_s: rangeRateKmS,
        });
    });
}

function interpolateAngleDegrees(a, b, amount) {
    const delta = ((b - a + 540) % 360) - 180;
    const result = ((a + delta * amount) % 360 + 360) % 360;
    return result > 359.9999999 ? 0 : result;
}

/** Interpolate between the hourly Horizons samples. This keeps Mars' fast sky
 * rotation smooth while allowing the shared one-hour proxy cache to absorb
 * repeated page loads instead of issuing five new JPL queries every minute. */
export function interpolateHorizonsObserverSamples(samples, date = new Date()) {
    if (!Array.isArray(samples) || !samples.length) return null;
    if (samples.length === 1) return { ...samples[0], above_horizon: samples[0].elevation_deg >= 0 };
    const jd = jdFromDate(date);
    let left = samples[0];
    let right = samples.at(-1);
    for (let index = 0; index < samples.length - 1; index += 1) {
        if (jd >= samples[index].jd && jd <= samples[index + 1].jd) {
            left = samples[index];
            right = samples[index + 1];
            break;
        }
    }
    const span = Math.max(Number.EPSILON, right.jd - left.jd);
    const amount = Math.max(0, Math.min(1, (jd - left.jd) / span));
    const lerp = (a, b) => a + (b - a) * amount;
    const elevationDeg = lerp(left.elevation_deg, right.elevation_deg);
    return {
        observed_at: date.toISOString(),
        sample_start_at: left.observed_at,
        sample_stop_at: right.observed_at,
        jd,
        azimuth_deg: interpolateAngleDegrees(left.azimuth_deg, right.azimuth_deg, amount),
        elevation_deg: elevationDeg,
        range_au: lerp(left.range_au, right.range_au),
        range_rate_km_s: lerp(left.range_rate_km_s, right.range_rate_km_s),
        above_horizon: elevationDeg >= 0,
    };
}

function marsObserverParams(command, { startJd, stopJd, latDeg, lonDeg, elevationM }) {
    return new URLSearchParams({
        format: 'json',
        COMMAND: `'${command}'`,
        OBJ_DATA: "'NO'",
        MAKE_EPHEM: "'YES'",
        EPHEM_TYPE: "'OBSERVER'",
        CENTER: "'coord@499'",
        COORD_TYPE: "'GEODETIC'",
        // Parkers Physics stores east-positive longitude. Horizons' IAU_MARS
        // topocentric input is west-positive, so the sign must be reversed.
        SITE_COORD: `'${-lonDeg},${latDeg},${elevationM / 1000}'`,
        TLIST: `'${startJd.toFixed(8)},${stopJd.toFixed(8)}'`,
        QUANTITIES: "'4,20'",
        CSV_FORMAT: "'YES'",
        ANG_FORMAT: "'DEG'",
        APPARENT: "'AIRLESS'",
        EXTRA_PREC: "'YES'",
    });
}

/** Load apparent airless azimuth/elevation as seen from a Mars surface site.
 * Each body is independent: a failed asteroid lookup does not discard the Sun
 * or Earth. No synthetic position is returned when Horizons is unavailable. */
export async function fetchMarsSkyEphemeris({
    date = new Date(),
    latDeg,
    lonDeg,
    elevationM = 0,
    siteName = 'Mars surface observer',
    bodies = MARS_SKY_BODIES,
} = {}) {
    if (![latDeg, lonDeg, elevationM].every(Number.isFinite)) {
        throw new TypeError('Mars sky observer requires finite latDeg, lonDeg, and elevationM');
    }
    const { startJd, stopJd } = marsSkySampleWindow(date);
    const geodeticLatDeg = marsPlanetocentricToGeodetic(latDeg);
    const fetchBody = async body => ({
        body,
        samples: parseHorizonsObserverTable(await _fetchHorizonsResult(marsObserverParams(body.command, {
            startJd, stopJd, latDeg: geodeticLatDeg, lonDeg, elevationM,
        }))),
    });
    const results = await Promise.allSettled(bodies.map(fetchBody));
    // Horizons sometimes sheds part of a concurrent burst while resolving
    // uncached small-body SPKs. Retry only failed bodies, sequentially, so a
    // transient Ceres/Vesta timeout does not leave a permanently partial sky.
    for (let index = 0; index < results.length; index += 1) {
        if (results[index].status === 'fulfilled') continue;
        try {
            results[index] = { status: 'fulfilled', value: await fetchBody(bodies[index]) };
        } catch (error) {
            results[index] = { status: 'rejected', reason: error };
        }
    }
    const resolvedBodies = {};
    const errors = {};
    results.forEach((result, index) => {
        const body = bodies[index];
        if (result.status === 'fulfilled') {
            resolvedBodies[body.key] = Object.freeze({ ...body, samples: Object.freeze(result.value.samples) });
        } else {
            errors[body.key] = result.reason?.message || String(result.reason);
        }
    });
    const count = Object.keys(resolvedBodies).length;
    return {
        source: 'JPL Horizons',
        status: count === bodies.length ? 'live' : count ? 'partial' : 'offline',
        generated_at: new Date().toISOString(),
        sample_start_at: dateFromJD(startJd).toISOString(),
        sample_stop_at: dateFromJD(stopJd).toISOString(),
        observer: Object.freeze({
            body: 'Mars',
            site: siteName,
            lat_deg: latDeg,
            horizons_geodetic_lat_deg: geodeticLatDeg,
            lon_deg: lonDeg,
            elevation_m: elevationM,
            coordinate_reference: 'MMGIS planetocentric/east-positive in client; converted to IAU_MARS geodetic/west-positive for Horizons',
        }),
        bodies: Object.freeze(resolvedBodies),
        errors: Object.freeze(errors),
    };
}

// ── EphemerisService ──────────────────────────────────────────────────────────

export class EphemerisService {
    constructor() {
        this.source    = 'pending';
        this.data      = null;
        this._loaded   = false;
        this._timer    = null;
    }

    /**
     * Asynchronously load current ephemeris for all 8 planets + Moon.
     *
     * Strategy:
     *  • Earth + Moon      — JPL Horizons primary, Meeus fallback
     *  • Outer planets     — JPL Horizons attempted in parallel (Promise.allSettled);
     *                        Meeus used for any that fail or timeout
     *  • Mercury/Venus/Mars — Meeus algorithms (sub-degree accuracy, sufficient for
     *                         real-time heliospheric visualization)
     *
     * Fires 'ephemeris-ready' on window when complete.
     */
    /**
     * Load ephemeris for all 8 planets + Moon at a given Julian Day.
     * @param {number} [jd]  Julian Day to compute for (default: now).
     *                        Enables time-travel: pass any JD and Horizons
     *                        will query that epoch, with Meeus fallback.
     */
    async load(jd = null) {
        if (jd == null) jd = jdNow();
        let earth, moon, jupiter, saturn, uranus, neptune;
        let horizonsSucceeded = false;

        // ── Attempt Horizons for Earth + Moon ─────────────────────────────
        try {
            console.log('[Horizons] Fetching Earth + Moon vectors…');
            const [ev, mv] = await Promise.all([
                _fetchVec('399', '500@10', jd),   // Earth, heliocentric, AU
                _fetchVec('301', '500@399', jd),   // Moon,  geocentric,   km
            ]);

            earth = _vecToHelioEcliptic(ev);

            const km2AU = 1 / 149597870.7;
            const mx = mv.x * km2AU, my = mv.y * km2AU, mz = mv.z * km2AU;
            const mR = Math.sqrt(mx**2 + my**2 + mz**2);
            moon = {
                lon_rad: Math.atan2(my, mx),
                lat_rad: Math.asin(Math.max(-1, Math.min(1, mz / mR))),
                dist_km: Math.sqrt(mv.x**2 + mv.y**2 + mv.z**2),
                dist_AU: mR,
                source: 'horizons',
            };

            horizonsSucceeded = true;
            console.log(
                `[Horizons] Earth lon=${(earth.lon_rad * R2D).toFixed(2)}°`,
                `r=${earth.dist_AU.toFixed(5)} AU | Moon r=${moon.dist_km.toFixed(0)} km`,
            );

        } catch (err) {
            console.warn('[Horizons] Earth/Moon unavailable — using Meeus fallback:', err.message);
        }

        // ── Attempt Horizons for outer planets (non-blocking) ────────────
        // Each fetch is independent; Meeus is used if any fail.
        const outerIds = [
            { name: 'jupiter', cmd: '599' },
            { name: 'saturn',  cmd: '699' },
            { name: 'uranus',  cmd: '799' },
            { name: 'neptune', cmd: '899' },
        ];
        const outerResults = await Promise.allSettled(
            outerIds.map(({ cmd }) => _fetchVec(cmd, "'500@10'", jd))
        );

        const outerHorizons = {};
        outerIds.forEach(({ name }, idx) => {
            const result = outerResults[idx];
            if (result.status === 'fulfilled') {
                outerHorizons[name] = _vecToHelioEcliptic(result.value);
                console.log(`[Horizons] ${name} r=${outerHorizons[name].dist_AU.toFixed(3)} AU`);
            } else {
                console.warn(`[Horizons] ${name} failed — using Meeus:`, result.reason?.message);
            }
        });

        // ── Meeus fallback for Earth + Moon ───────────────────────────────
        if (!earth) {
            const e = earthHeliocentric(jd);
            earth = { ...e, source: 'meeus' };
        }
        if (!moon) {
            const m = moonGeocentric(jd);
            moon = {
                lon_rad: m.lon_rad, lat_rad: m.lat_rad,
                dist_km: m.dist_km, dist_AU: m.dist_AU,
                source: 'meeus',
            };
        }

        // ── Inner planets — Meeus algorithms ─────────────────────────────
        const mercury = { ...mercuryHeliocentric(jd), source: 'meeus' };
        const venus   = { ...venusHeliocentric(jd),   source: 'meeus' };
        const mars    = { ...marsHeliocentric(jd),    source: 'meeus' };

        // ── Outer planets — Horizons or Meeus ────────────────────────────
        jupiter = outerHorizons.jupiter ?? { ...jupiterHeliocentric(jd), source: 'meeus' };
        saturn  = outerHorizons.saturn  ?? { ...saturnHeliocentric(jd),  source: 'meeus' };
        uranus  = outerHorizons.uranus  ?? { ...uranusHeliocentric(jd),  source: 'meeus' };
        neptune = outerHorizons.neptune ?? { ...neptuneHeliocentric(jd), source: 'meeus' };

        const anyOuter = Object.values(outerHorizons).length > 0;
        const source = horizonsSucceeded
            ? (anyOuter ? 'horizons' : 'mixed')
            : 'meeus';

        console.log(
            `[Ephemeris] ${source} |`,
            `Jup=${(jupiter.lon_rad * R2D).toFixed(1)}°`,
            `Sat=${(saturn.lon_rad  * R2D).toFixed(1)}°`,
            `Ura=${(uranus.lon_rad  * R2D).toFixed(1)}°`,
            `Nep=${(neptune.lon_rad * R2D).toFixed(1)}°`,
        );

        this.source  = source;
        this._loaded = true;
        this.data    = {
            jd, source, timestamp: new Date(),
            mercury, venus, earth, moon, mars,
            jupiter, saturn, uranus, neptune,
        };

        window.dispatchEvent(new CustomEvent('ephemeris-ready', { detail: this.data }));
        return this.data;
    }

    /** Re-fetch (e.g. on page re-focus or manual refresh). */
    refresh() { return this.load(); }

    /**
     * Start live refresh every `intervalSec` seconds (default 60).
     * Stops any existing timer first.
     */
    startLive(intervalSec = 60) {
        this.stopLive();
        this.load();  // immediate first fetch
        this._timer = setInterval(() => this.load(), intervalSec * 1000);
        return this;
    }

    stopLive() {
        if (this._timer) { clearInterval(this._timer); this._timer = null; }
    }
}

export default EphemerisService;
