/**
 * E2E tests for authentication and subscription flows.
 *
 * Tests cover:
 *  1. Landing page → signup CTA works
 *  2. Signup form validation (empty fields, bad email, short password)
 *  3. Signup form submits with valid data
 *  4. Signin form validation + submit
 *  5. Password reset flow
 *  6. Pricing page → checkout redirect for signed-in users
 *  7. Dashboard loads for authenticated users
 *  8. Dashboard subscription card shows correct state
 *  9. Alert preferences save correctly
 * 10. Onboarding tour appears for new users
 *
 * Run:  npx playwright test tests/auth-flows.spec.js
 * Debug: npx playwright test --headed --debug tests/auth-flows.spec.js
 */

import { test, expect } from '@playwright/test';

// ── Test data ────────────────────────────────────────────────────────────────
const TEST_EMAIL    = `test-${Date.now()}@playwright.test`;
const TEST_PASSWORD = 'TestPass123!';
const TEST_FIRST    = 'Test';
const TEST_LAST     = 'User';

// ── 1. Landing Page ─────────────────────────────────────────────────────────

test.describe('Landing Page', () => {
    test('loads and shows hero CTA', async ({ page }) => {
        await page.goto('/');
        await expect(page).toHaveTitle(/Parkers Physics/);
        // Hero CTA should be visible
        const cta = page.locator('a:has-text("Get Started")').first();
        await expect(cta).toBeVisible();
    });

    test('CTA links to signup', async ({ page }) => {
        await page.goto('/');
        const cta = page.locator('a:has-text("Get Started")').first();
        const href = await cta.getAttribute('href');
        expect(href).toContain('signup');
    });

    test('pricing teaser is visible', async ({ page }) => {
        await page.goto('/');
        const pricing = page.locator('text=Start free').first();
        await expect(pricing).toBeVisible();
    });
});

// ── 2. Signup Form Validation ───────────────────────────────────────────────

test.describe('Signup Form Validation', () => {
    test.beforeEach(async ({ page }) => {
        await page.goto('/signup.html?plan=free');
    });

    test('shows error for empty fields', async ({ page }) => {
        await page.click('#btn-submit');
        // Should show validation errors
        const firstNameErr = page.locator('#err-first');
        await expect(firstNameErr).toBeVisible();
    });

    test('shows error for invalid email', async ({ page }) => {
        await page.fill('#first-name', TEST_FIRST);
        await page.fill('#last-name', TEST_LAST);
        await page.fill('#email', 'not-an-email');
        await page.fill('#password', TEST_PASSWORD);
        await page.check('#terms');
        await page.click('#btn-submit');
        const emailErr = page.locator('#err-email');
        await expect(emailErr).toBeVisible();
    });

    test('shows error for short password', async ({ page }) => {
        await page.fill('#first-name', TEST_FIRST);
        await page.fill('#last-name', TEST_LAST);
        await page.fill('#email', TEST_EMAIL);
        await page.fill('#password', 'short');
        await page.check('#terms');
        await page.click('#btn-submit');
        const pwErr = page.locator('#err-pw');
        await expect(pwErr).toBeVisible();
    });

    test('shows error when terms unchecked', async ({ page }) => {
        await page.fill('#first-name', TEST_FIRST);
        await page.fill('#last-name', TEST_LAST);
        await page.fill('#email', TEST_EMAIL);
        await page.fill('#password', TEST_PASSWORD);
        // Don't check terms
        await page.click('#btn-submit');
        const termsErr = page.locator('#err-terms');
        await expect(termsErr).toBeVisible();
    });

    test('terms and privacy links work', async ({ page }) => {
        const termsLink = page.locator('a:has-text("Terms of Service")');
        await expect(termsLink).toHaveAttribute('href', 'eula.html');
        const privacyLink = page.locator('a:has-text("Privacy Policy")');
        await expect(privacyLink).toHaveAttribute('href', 'privacy.html');
    });

    test('persona chips render; operator personas reveal the fleet fields', async ({ page }) => {
        // Public test (js/public-test.js): no plan pills — the DB trigger
        // sets the plan. One persona question routes the welcome path.
        await expect(page.locator('#persona-chips input[name="persona"]')).toHaveCount(6);
        await expect(page.locator('#operator-fields')).toBeHidden();
        await page.click('#persona-teacher');
        await expect(page.locator('#operator-fields')).toBeHidden();
        await page.click('#persona-operator');
        await expect(page.locator('#operator-fields')).toBeVisible();
        await expect(page.locator('#plan-pills')).toHaveCount(0);
    });

    test('persona is required', async ({ page }) => {
        await page.fill('#first-name', TEST_FIRST);
        await page.fill('#last-name', TEST_LAST);
        await page.fill('#email', TEST_EMAIL);
        await page.fill('#password', TEST_PASSWORD);
        await page.check('#terms');
        await page.click('#btn-submit');
        await expect(page.locator('#err-persona')).toBeVisible();
        await expect(page.locator('#btn-submit')).toBeEnabled();
    });

    test('password strength indicator works', async ({ page }) => {
        const bar = page.locator('#pw-bar');
        await page.fill('#password', 'ab');
        // Short = red/narrow
        const width1 = await bar.evaluate(el => el.style.width);
        expect(parseInt(width1)).toBeLessThan(50);

        await page.fill('#password', 'StrongP@ss123');
        const width2 = await bar.evaluate(el => el.style.width);
        expect(parseInt(width2)).toBeGreaterThan(60);
    });

    test('no OAuth buttons present', async ({ page }) => {
        const oauthBtn = page.locator('button:has-text("Google")');
        await expect(oauthBtn).toHaveCount(0);
    });
});

// ── 3. Signup Submit ────────────────────────────────────────────────────────

test.describe('Signup Submit', () => {
    test('submits valid form and shows success or confirmation', async ({ page }) => {
        await page.goto('/signup.html?plan=free');
        await page.fill('#first-name', TEST_FIRST);
        await page.fill('#last-name', TEST_LAST);
        await page.fill('#email', TEST_EMAIL);
        await page.fill('#password', TEST_PASSWORD);
        await page.click('#persona-enthusiast');
        await page.check('#terms');
        await page.click('#btn-submit');

        // Button should show loading state
        await expect(page.locator('#btn-submit')).toHaveText(/Creating account/);

        // Should eventually show success view (either confirmation or redirect)
        await expect(page.locator('#success-view')).toBeVisible({ timeout: 10_000 });
    });
});

// ── 4. Signin Form ──────────────────────────────────────────────────────────

test.describe('Signin Form', () => {
    test.beforeEach(async ({ page }) => {
        await page.goto('/signin.html');
    });

    test('page loads with form', async ({ page }) => {
        await expect(page.locator('#email')).toBeVisible();
        await expect(page.locator('#password')).toBeVisible();
        await expect(page.locator('#btn-submit')).toBeVisible();
    });

    test('no OAuth buttons present', async ({ page }) => {
        const oauthBtn = page.locator('button:has-text("Google")');
        await expect(oauthBtn).toHaveCount(0);
    });

    test('forgot password shows reset view', async ({ page }) => {
        await page.click('#forgot-btn');
        const resetView = page.locator('#reset-view');
        await expect(resetView).toBeVisible();
    });

    test('back button returns to signin', async ({ page }) => {
        await page.click('#forgot-btn');
        await page.click('#back-btn');
        const signInForm = page.locator('#signin-form');
        await expect(signInForm).toBeVisible();
    });

    test('shows error for invalid credentials', async ({ page }) => {
        await page.fill('#email', 'nonexistent@test.com');
        await page.fill('#password', 'wrongpassword');
        await page.click('#btn-submit');
        // Should show error (may take a moment for Supabase to respond)
        const errorEl = page.locator('.form-error.visible, .error-msg.visible, [class*="error"]').first();
        await expect(errorEl).toBeVisible({ timeout: 10_000 });
    });
});

// ── 5. Reset Password Page ──────────────────────────────────────────────────

test.describe('Reset Password Page', () => {
    test('loads and shows form or expired message', async ({ page }) => {
        await page.goto('/reset-password.html');
        // Should show either the form (if valid token in URL) or the expired view
        const formView = page.locator('#reset-form-view');
        const errorView = page.locator('#error-view');
        // One of these should be visible
        await expect(formView.or(errorView)).toBeVisible({ timeout: 5_000 });
    });
});

// ── 6. Pricing Page ─────────────────────────────────────────────────────────

test.describe('Pricing Page', () => {
    test('shows the two plan cards', async ({ page }) => {
        await page.goto('/pricing.html');
        const cards = page.locator('.price-card');
        await expect(cards).toHaveCount(2);
        await expect(page.locator('#card-intro .tier-name')).toHaveText('Intro');
        await expect(page.locator('#card-advanced .tier-name')).toHaveText('Advanced');
    });

    test('public-test banner + tester CTAs link to signup', async ({ page }) => {
        await page.goto('/pricing.html');
        await expect(page.locator('#test-banner')).toBeVisible();
        await expect(page.locator('[data-pricing-cta="banner"]')).toHaveAttribute('href', /signup\.html/);
        await expect(page.locator('[data-pricing-cta="intro"]')).toHaveAttribute('href', /signup.*tier=intro/);
        await expect(page.locator('[data-pricing-cta="advanced"]')).toHaveAttribute('href', /signup.*tier=advanced/);
        await expect(page.locator('[data-pricing-cta="pilot"]')).toHaveAttribute('href', 'request-access.html');
    });

    test('no checkout buttons while the public test runs', async ({ page }) => {
        await page.goto('/pricing.html');
        await expect(page.locator('[data-checkout]')).toHaveCount(0);
        // Post-test prices are shown struck through, not charged.
        await expect(page.locator('s[data-price="intro"]')).toHaveText('$10/mo');
        await expect(page.locator('s[data-price="advanced"]')).toHaveText('$100/mo');
    });

    test('FAQ accordion toggles', async ({ page }) => {
        await page.goto('/pricing.html');
        const firstQ = page.locator('.faq-q').first();
        await firstQ.click();
        const firstItem = page.locator('.faq-item').first();
        await expect(firstItem).toHaveClass(/open/);
    });

    test('canceled checkout shows banner', async ({ page }) => {
        await page.goto('/pricing.html?checkout=canceled');
        const banner = page.locator('text=Checkout canceled');
        await expect(banner).toBeVisible({ timeout: 3_000 });
    });
});

// ── 7. Dashboard ────────────────────────────────────────────────────────────
//
// Notes after the canonical auth/dashboard refactor:
//   • Unauthenticated visit to /dashboard.html now REDIRECTS to
//     /signin?next=/dashboard.html (no more in-page modal as the
//     primary gate). The in-page #auth-gate stays in the markup as a
//     fallback for the case where the module script fails to load,
//     so the test below asserts the redirect.
//   • Subscription, Alert Preferences, and Saved Locations cards have
//     moved to /settings.html. The dashboard now carries a single
//     "Open Settings" link strip in their place.

test.describe('Dashboard', () => {
    test('unauthenticated visit redirects to /signin?next=/dashboard.html', async ({ page }) => {
        await page.goto('/');
        await page.evaluate(() => {
            localStorage.removeItem('pp_auth');
            sessionStorage.removeItem('pp_auth');
        });
        await page.goto('/dashboard.html');
        await page.waitForURL(/\/signin\.html\?next=/, { timeout: 10_000 });
        const url = new URL(page.url());
        expect(url.searchParams.get('next')).toContain('dashboard.html');
    });

    test('settings-link strip points to /settings.html', async ({ page }) => {
        await page.goto('/dashboard.html');
        await page.evaluate(() => {
            localStorage.setItem('pp_auth', JSON.stringify({
                signedIn: true, email: 'test@test.com', name: 'Test',
                plan: 'free', role: 'user', provider: 'mock',
            }));
        });
        await page.reload();
        const card = page.locator('#settings-link-card');
        await expect(card).toBeVisible({ timeout: 10_000 });
        await expect(card.locator('a[href="settings.html"]')).toBeVisible();
    });

    test('impact score card exists for paid user', async ({ page }) => {
        await page.goto('/dashboard.html');
        await page.evaluate(() => {
            localStorage.setItem('pp_auth', JSON.stringify({
                signedIn: true, email: 'test@test.com', name: 'Test',
                plan: 'basic', role: 'user', provider: 'mock',
            }));
        });
        await page.reload();
        await expect(page.locator('#impact-card')).toBeAttached({ timeout: 10_000 });
    });

    test('alert history card exists for paid user', async ({ page }) => {
        await page.goto('/dashboard.html');
        await page.evaluate(() => {
            localStorage.setItem('pp_auth', JSON.stringify({
                signedIn: true, email: 'test@test.com', name: 'Test',
                plan: 'basic', role: 'user', provider: 'mock',
            }));
        });
        await page.reload();
        await expect(page.locator('#alert-history-card')).toBeAttached({ timeout: 10_000 });
    });

    test('tour retake button exists', async ({ page }) => {
        await page.goto('/dashboard.html');
        await page.evaluate(() => {
            localStorage.setItem('pp_auth', JSON.stringify({
                signedIn: true, email: 'test@test.com', name: 'Test',
                plan: 'free', role: 'user', provider: 'mock',
            }));
        });
        await page.reload();
        await expect(page.locator('#retake-tour')).toBeAttached({ timeout: 10_000 });
    });
});

// ── 8. Onboarding Tour ──────────────────────────────────────────────────────

test.describe('Onboarding Tour', () => {
    test('tour modal can be triggered', async ({ page }) => {
        await page.goto('/dashboard.html');
        // Clear tour completion flag
        await page.evaluate(() => localStorage.removeItem('ppx_tour_completed'));

        // Inject a mock auth state so dashboard renders
        await page.evaluate(() => {
            localStorage.setItem('pp_auth', JSON.stringify({
                signedIn: true, email: 'test@test.com', name: 'Test',
                plan: 'free', role: 'user', provider: 'mock',
            }));
        });
        await page.reload();

        // Tour should auto-start after 1.5s delay
        const modal = page.locator('.tour-modal');
        await expect(modal).toBeVisible({ timeout: 5_000 });

        // Should show welcome step
        await expect(page.locator('.tour-title')).toContainText('Welcome');
    });

    test('tour can be skipped', async ({ page }) => {
        await page.goto('/dashboard.html');
        await page.evaluate(() => {
            localStorage.removeItem('ppx_tour_completed');
            localStorage.setItem('pp_auth', JSON.stringify({
                signedIn: true, email: 'test@test.com', name: 'Test',
                plan: 'free', role: 'user', provider: 'mock',
            }));
        });
        await page.reload();

        const modal = page.locator('.tour-modal');
        await expect(modal).toBeVisible({ timeout: 5_000 });

        // Click skip
        await page.click('#tour-skip');

        // Modal should disappear
        await expect(modal).not.toBeVisible({ timeout: 2_000 });
    });

    test('tour does not reappear after completion', async ({ page }) => {
        await page.goto('/dashboard.html');
        await page.evaluate(() => {
            localStorage.setItem('ppx_tour_completed', '1');
            localStorage.setItem('pp_auth', JSON.stringify({
                signedIn: true, email: 'test@test.com', name: 'Test',
                plan: 'free', role: 'user', provider: 'mock',
            }));
        });
        await page.reload();

        // Wait past the auto-start delay
        await page.waitForTimeout(2500);

        // Tour should NOT appear
        const modal = page.locator('.tour-modal');
        await expect(modal).not.toBeVisible();
    });
});

// ── 9. Edge Function Health ─────────────────────────────────────────────────

test.describe('API Edge Functions', () => {
    test('stripe checkout rejects GET', async ({ request }) => {
        const res = await request.get('/api/stripe/checkout');
        expect(res.status()).toBe(405);
    });

    test('stripe checkout rejects unauthorized POST', async ({ request }) => {
        const res = await request.post('/api/stripe/checkout', {
            data: { plan: 'basic' },
        });
        // Should be 401 (unauthorized) or 501 (not configured in test)
        expect([401, 501]).toContain(res.status());
    });

    test('stripe portal rejects GET', async ({ request }) => {
        const res = await request.get('/api/stripe/portal');
        expect(res.status()).toBe(405);
    });

    test('stripe webhook rejects GET', async ({ request }) => {
        const res = await request.get('/api/stripe/webhook');
        expect(res.status()).toBe(405);
    });

    test('alert email rejects GET', async ({ request }) => {
        const res = await request.get('/api/alerts/email');
        expect(res.status()).toBe(405);
    });

    test('alert email rejects unauthorized POST', async ({ request }) => {
        const res = await request.post('/api/alerts/email', {
            data: { title: 'test', body: 'test' },
        });
        expect([401, 501]).toContain(res.status());
    });
});

// ── 10. Tier expansion (Educator / Institution / Enterprise) ───────────────

test.describe('Tier expansion', () => {
    // 2026-10: the six-tier page collapsed to Intro + Advanced. Seats and
    // site licences moved to a "Talk to us" line; the stored plan ids are
    // unchanged (js/public-test.js planFamily folds them).
    test('pricing page routes seats and licences to Talk to us', async ({ page }) => {
        await page.goto('/pricing.html');
        await expect(page.locator('.tier-name')).toHaveText(['Intro', 'Advanced']);
        await expect(page.locator('[data-pricing-cta="talk"]')).toHaveAttribute('href', 'contact-enterprise.html');
    });

    test('signup page links seats / licences to contact-enterprise', async ({ page }) => {
        await page.goto('/signup.html');
        await expect(page.locator('#tester-badge')).toBeVisible();
        await expect(page.locator('a[href="contact-enterprise.html"]')).toBeVisible();
    });

    test('legacy ?plan=educator links still land on a working form', async ({ page }) => {
        await page.goto('/signup.html?plan=educator');
        await expect(page.locator('#signup-form')).toBeVisible();
        await expect(page.locator('#persona-chips input')).toHaveCount(6);
    });

    test('stripe checkout rejects enterprise plan', async ({ request }) => {
        const res = await request.post('/api/stripe/checkout', {
            data:    { plan: 'enterprise' },
            headers: { Authorization: 'Bearer fake-token' },
        });
        // 401 (unauthorized — JWT rejected first) OR 400 (contact_required) OR 501 (not configured)
        // The test runs with no Stripe / Supabase config in CI.
        expect([400, 401, 501]).toContain(res.status());
    });

    test('stripe checkout accepts trial promo code in body schema', async ({ request }) => {
        // The endpoint should at least parse the body; without a real JWT
        // it'll 401 (unauthorized) before applying the trial. We're just
        // verifying the schema didn't reject because of the new field.
        const res = await request.post('/api/stripe/checkout', {
            data:    { plan: 'basic', trial: 'tour-30day' },
            headers: { Authorization: 'Bearer fake-token' },
        });
        expect([400, 401, 501]).toContain(res.status());
    });

    test('?plan=basic&trial=tour-30day URL preserves trial param on signup', async ({ page }) => {
        await page.goto('/signup.html?plan=basic&trial=tour-30day');
        // The trial param stays in the URL so the post-test checkout call
        // can forward it server-side.
        await expect(page.locator('#signup-form')).toBeVisible();
        const url = page.url();
        expect(url).toMatch(/trial=tour-30day/);
    });

    test('contact-enterprise endpoint rejects missing email', async ({ request }) => {
        const res = await request.post('/api/contact/enterprise', {
            data: { name: 'Test User' },
        });
        // 400 (invalid_email) OR 403 (origin_blocked from test runner) OR 501 (not configured)
        expect([400, 403, 501]).toContain(res.status());
    });

    test('contact-enterprise page renders form', async ({ page }) => {
        await page.goto('/contact-enterprise.html');
        await expect(page.locator('#contact-form')).toBeVisible();
        await expect(page.locator('input[name="email"]')).toBeVisible();
        await expect(page.locator('input[name="use_case"][value="anomaly_correlation"]')).toBeAttached();
    });
});

// ── 7. Educator wedge: landing page + class-invite endpoint ─────────────────

test.describe('Educator Wedge', () => {
    test('for-educators page renders hero + CTA', async ({ page }) => {
        await page.goto('/for-educators.html');
        await expect(page.locator('h1')).toContainText(/NASA|class|simulations/i);
        const cta = page.locator('a.btn-primary[href*="signup"]').first();
        await expect(cta).toBeVisible();
        await expect(cta).toHaveAttribute('href', /plan=educator/);
    });

    test('/educators pretty URL works', async ({ page }) => {
        const res = await page.goto('/educators');
        // Vercel rewrite serves /for-educators.html under both URLs.
        // In dev (no Vercel rewrites), this may 404 — accept either the rewrite or the source.
        if (res && res.ok()) {
            await expect(page.locator('h1')).toBeVisible();
        }
    });

    test('class invite endpoint rejects unauthorized POST', async ({ request }) => {
        const res = await request.post('/api/class/invite', {
            data: { email: 'student@example.com' },
        });
        // 401 (no auth) or 501 (not configured in CI) — never 200.
        expect([401, 403, 501]).toContain(res.status());
    });

    test('class roster endpoint rejects unauthorized GET', async ({ request }) => {
        const res = await request.get('/api/class/roster');
        expect([401, 403, 501]).toContain(res.status());
    });

    test('class invite endpoint rejects invalid origin', async ({ request }) => {
        const res = await request.post('/api/class/invite', {
            data:    { email: 'student@example.com' },
            headers: {
                Authorization: 'Bearer fake-token',
                Origin:        'https://evil.example.com',
            },
        });
        // 403 (forbidden_origin) or 401 (auth) or 501 (not configured).
        expect([401, 403, 501]).toContain(res.status());
    });
});
