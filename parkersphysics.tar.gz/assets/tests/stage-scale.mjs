#!/usr/bin/env node
/**
 * stage-scale.mjs — contract gate for the Stage's disclosed spatial
 * compression (js/stage/scale.js). The map may be dishonest about
 * distance ONLY in the documented, removable way: monotone, continuous,
 * Earth pinned exactly, invertible, and blending to the true-linear map
 * at mix=1.
 *
 *   node tests/stage-scale.mjs
 */

import assert from 'node:assert/strict';
import { stageRadius, stageRadiusInv, stageRadiusInvMix, stagePoint, rulerTicks,
         R1, R2, A, B, EARTH_S, BODY, EARTH_LOCAL_RE, reToUnits,
         FLOW, flowLapse, AURORA, RE_KM }
    from '../js/stage/scale.js';

let n = 0;
const test = (name, fn) => { fn(); n++; console.log(`  ✓ ${name}`); };

test('Earth lands at EXACTLY EARTH_S stage units at every mix', () => {
    for (const mix of [0, 0.25, 0.5, 1]) {
        assert.ok(Math.abs(stageRadius(1, mix) - EARTH_S) < 1e-12, `mix ${mix}`);
    }
});

test('C0 continuity at both breakpoints', () => {
    for (const r of [R1, R2]) {
        const below = stageRadius(r - 1e-9), above = stageRadius(r + 1e-9);
        assert.ok(Math.abs(above - below) < 1e-6, `breakpoint ${r}`);
    }
});

test('strictly monotone for compressed, blended, and true maps', () => {
    for (const mix of [0, 0.5, 1]) {
        let prev = -1;
        for (let i = 0; i <= 500; i++) {
            const s = stageRadius(1.2 * i / 500, mix);
            assert.ok(s > prev - 1e-15, `mix ${mix} at i=${i}`);
            prev = s;
        }
    }
});

test('the compression is the documented shape: launch zone roomy, mid squeezed', () => {
    const slope = (r) => (stageRadius(r + 1e-6) - stageRadius(r - 1e-6)) / 2e-6;
    assert.ok(slope(0.05) > 3, 'near-Sun zone gets MORE room than linear');
    assert.ok(slope(0.85) < 3, 'mid corridor is compressed below linear');
    assert.ok(slope(0.95) > 3, 'near-Earth zone gets more room than linear');
    assert.ok(Math.abs(A * R1 + B * Math.log(R2 / R1) + A * (1 - R2) - EARTH_S) < 1e-12,
        'B is solved so the pieces sum to EARTH_S exactly');
});

test('closed-form inverse round-trips through all three zones', () => {
    for (const r of [0.02, R1, 0.3, 0.62, R2, 0.95, 1.0, 1.1]) {
        assert.ok(Math.abs(stageRadiusInv(stageRadius(r)) - r) < 1e-9, `r=${r}`);
    }
});

test('stagePoint compresses radially — direction preserved', () => {
    const p = stagePoint([0.3, 0.4, 0.1]);
    const r = Math.hypot(0.3, 0.4, 0.1);
    assert.ok(Math.abs(Math.hypot(...p) - stageRadius(r)) < 1e-12);
    const dot = (p[0] * 0.3 + p[1] * 0.4 + p[2] * 0.1) / (Math.hypot(...p) * r);
    assert.ok(Math.abs(dot - 1) < 1e-12, 'colinear with the input');
    assert.deepEqual(stagePoint([0, 0, 0]), [0, 0, 0]);
});

test('ruler ticks label true AU at current stage positions', () => {
    const t0 = rulerTicks(0), t1 = rulerTicks(1);
    assert.equal(t0.length, 5);
    assert.ok(t0.every((t, i) => i === 0 || t.s > t0[i - 1].s), 'ticks monotone');
    assert.ok(Math.abs(t0.at(-1).s - EARTH_S) < 1e-12, '1 AU tick at Earth (compressed)');
    assert.ok(Math.abs(t1.at(-1).s - EARTH_S) < 1e-12, '1 AU tick at Earth (true)');
    // At true scale ticks are proportional; compressed they are not.
    assert.ok(Math.abs(t1[0].s - EARTH_S * 0.1) < 1e-12);
    assert.ok(Math.abs(t0[0].s - EARTH_S * 0.1) > 0.01, 'compression is visible on the ruler');
});

test('disclosed exaggerations are finite and stated', () => {
    assert.ok(BODY.sunExaggeration > 1 && Number.isFinite(BODY.sunExaggeration));
    assert.ok(BODY.earthExaggeration > 1 && Number.isFinite(BODY.earthExaggeration));
    // The quiet magnetopause nose (~10 R_E) must clear the drawn Earth.
    assert.ok(reToUnits(10) > BODY.earthRadiusUnits, 'nose outside the drawn Earth');
    assert.ok(EARTH_LOCAL_RE > 0);
});

test('S5a flow time-lapse: declared, useful magnitude, removable', () => {
    // One 450 km/s transit at the default lapse lands in the tens-of-
    // seconds-to-minutes window (the "dynamic" requirement) — pinned as
    // a RANGE so tuning stays possible without rewriting the doctrine.
    assert.ok(FLOW.TIME_LAPSE >= 600 && FLOW.TIME_LAPSE <= 20000);
    const transitS = (1.496e8 / 450) / FLOW.TIME_LAPSE;
    assert.ok(transitS > 20 && transitS < 600, `on-screen transit ${transitS}s`);
    // Removability IS the honesty: true scale blends to real time.
    assert.equal(flowLapse(0), FLOW.TIME_LAPSE);
    assert.equal(flowLapse(1), 1);
    assert.ok(flowLapse(0.5) < FLOW.TIME_LAPSE && flowLapse(0.5) > 1);
    assert.equal(flowLapse(2), 1);                    // clamped
    assert.equal(flowLapse(-1), FLOW.TIME_LAPSE);     // clamped
});

test('S5c curtains: vertical exaggeration declared and self-consistent', () => {
    // The stated factor must be exactly what the drawn height implies —
    // a drifted constant would make the disclosure line lie.
    assert.ok(Math.abs(AURORA.EXAG - (AURORA.DRAWN_RE * RE_KM) / AURORA.TOP_KM) < 1e-9);
    assert.ok(AURORA.EXAG > 5 && AURORA.EXAG < 20, `EXAG ${AURORA.EXAG}`);
    // Real ceiling: the 630 nm red border, order 300 km.
    assert.ok(AURORA.TOP_KM >= 150 && AURORA.TOP_KM <= 500);
    // Drawn height stays a fraction of the drawn Earth — curtains must
    // never read as a second magnetosphere shell.
    assert.ok(AURORA.DRAWN_RE > 0.1 && AURORA.DRAWN_RE <= 1);
});

test('S5d picking: stageRadiusInvMix inverts the blend at every mix', () => {
    for (const mix of [0, 0.25, 0.5, 0.99, 1]) {
        for (const r of [0.07, 0.1, 0.3, 0.62, 0.9, 1.0, 1.12]) {
            const back = stageRadiusInvMix(stageRadius(r, mix), mix);
            assert.ok(Math.abs(back - r) < 1e-6, `mix ${mix} r ${r} → ${back}`);
        }
    }
    // mix=0 agrees with the closed form; degenerate input stays sane.
    assert.equal(stageRadiusInvMix(stageRadius(0.5, 0), 0), stageRadiusInv(stageRadius(0.5, 0)));
    assert.equal(stageRadiusInvMix(0, 0.7), 0);
});

console.log(`stage-scale: ALL PASS (${n} tests)`);
