/**
 * upper-atmosphere-smoke.spec.js — boot smoke test
 * ═══════════════════════════════════════════════════════════════════════════
 * Verifies that upper-atmosphere.html loads without console errors, the
 * engine self-tests all pass, and the three canvas surfaces render at
 * least one frame. Mirrors the style of earth-smoke.spec.js but leans
 * on the exposed `window.__ua` handle rather than a debug overlay.
 *
 * The console-error gates run HERMETIC (tests/fixtures/upper-atmosphere-feeds.mjs:
 * NOAA, CelesTrak and the Earth textures served from fixtures), so they judge
 * the page and not the network — they used to fail wherever NOAA/CelesTrak/
 * unpkg are unreachable on ~50 "Failed to load resource" lines. A separate
 * gate boots with EVERY feed dead and requires no uncaught exception: the
 * degraded path is a promise too.
 */

import { test, expect } from '@playwright/test';
import { routeUpperAtmosphereFeeds } from './fixtures/upper-atmosphere-feeds.mjs';

const URL = '/upper-atmosphere.html';
const BOOT_TIMEOUT_MS = 15_000;

function attachConsoleRecorder(page) {
    const errors = [];
    page.on('console', (msg) => {
        if (msg.type() === 'error') {
            errors.push({ text: msg.text(), location: msg.location() });
        }
    });
    page.on('pageerror', (err) => {
        errors.push({ text: err.message, stack: err.stack });
    });
    return errors;
}

test.describe('upper-atmosphere.html smoke', () => {

    test('boots without console errors', async ({ page }) => {
        await routeUpperAtmosphereFeeds(page);
        const errors = attachConsoleRecorder(page);
        await page.goto(URL);
        await page.waitForFunction(() => !!window.__ua, { timeout: BOOT_TIMEOUT_MS });
        // Let the 3D scene + two canvas plots render a few frames.
        await page.waitForTimeout(1500);

        if (errors.length) console.error('Console errors:', errors);
        expect(errors, 'No console errors during boot (feeds served from fixtures)').toHaveLength(0);
    });

    test('NEGATIVE CONTROL: the hermetic boot gate still sees a broken page', async ({ page }) => {
        // The fixtures must silence the NETWORK, never the page: break one of
        // the page's own modules and the same recorder has to see it.
        await routeUpperAtmosphereFeeds(page);
        await page.route('**/js/upper-atmosphere-sat-suites-panel.js', (r) => r.fulfill({ status: 404, body: '' }));
        const errors = attachConsoleRecorder(page);
        await page.goto(URL);
        await page.waitForFunction(() => !!window.__ua, { timeout: BOOT_TIMEOUT_MS });
        await page.waitForTimeout(1500);
        expect(errors.length, 'a 404 on a page module is reported').toBeGreaterThan(0);
    });

    test('boots with EVERY feed down and throws nothing', async ({ page }) => {
        await routeUpperAtmosphereFeeds(page, { down: true });
        const thrown = [];
        page.on('pageerror', (err) => thrown.push(err.message));
        await page.goto(URL);
        await page.waitForFunction(() => !!window.__ua?.engine && !!window.__ua?.globe, { timeout: BOOT_TIMEOUT_MS });
        await page.waitForTimeout(2500);   // let every failed fetch settle
        // The model still answers from the client surrogate.
        const rho = await page.evaluate(() => window.__ua.engine.density({ altitudeKm: 400, f107Sfu: 150, ap: 15 }).rho);
        expect(Number.isFinite(rho) && rho > 0, 'density model works offline').toBe(true);
        expect(thrown, 'no uncaught exception with the feeds down').toEqual([]);
    });

    test('engine self-test passes', async ({ page }) => {
        await page.goto(URL);
        await page.waitForFunction(() => !!window.__ua, { timeout: BOOT_TIMEOUT_MS });
        const results = await page.evaluate(() => window.__ua.engine.selfTest());
        const failures = results.filter(r => !r.pass);
        expect(failures, `all self-tests pass (failures: ${failures.map(f => f.msg).join('; ')})`).toHaveLength(0);
    });

    test('sliders update state and redraw plots', async ({ page }) => {
        await page.goto(URL);
        await page.waitForFunction(() => !!window.__ua, { timeout: BOOT_TIMEOUT_MS });
        await page.waitForTimeout(600);

        // Move the altitude slider and verify the state propagates.
        await page.fill('#ua-alt', '700');
        await page.dispatchEvent('#ua-alt', 'input');
        await page.waitForTimeout(200);
        const altText = await page.textContent('#ua-alt-val');
        expect(altText, 'altitude label updates').toContain('700');

        // The UI should have recomputed a fresh profile.
        const profileLen = await page.evaluate(() => window.__ua.ui.profile.samples.length);
        expect(profileLen, 'profile was sampled').toBeGreaterThan(50);
    });

    test('storm preset row is populated and clickable', async ({ page }) => {
        await page.goto(URL);
        await page.waitForFunction(() => !!window.__ua, { timeout: BOOT_TIMEOUT_MS });

        const chips = await page.locator('#ua-presets .ua-chip').count();
        expect(chips, 'at least 3 storm presets rendered').toBeGreaterThanOrEqual(3);

        // Click the "Gannon" preset and check that state flipped.
        await page.locator('#ua-presets .ua-chip', { hasText: /Gannon/i }).click();
        await page.waitForTimeout(250);
        const f107 = await page.evaluate(() => window.__ua.ui.state.f107);
        expect(f107, 'Gannon preset pushes F10.7 ~195').toBeGreaterThan(150);
    });

    test('zone drag + turbulence dashboard renders a row per zone', async ({ page }) => {
        await page.goto(URL);
        await page.waitForFunction(() => !!window.__ua, { timeout: BOOT_TIMEOUT_MS });
        // The dashboard paints once on start(); give it a tick to settle.
        await page.waitForTimeout(600);

        // One row per atmospheric zone (the canonical 5-layer schema).
        const rows = page.locator('#ua-zone-dashboard .ua-zd-row');
        await expect(rows, 'a dashboard row per atmospheric zone').toHaveCount(5);

        // The first row's live readouts should be populated (the compute
        // path ran without throwing): ρ as an exponential, a regime badge,
        // and a turbulence state badge.
        const rho = await page.textContent('#ua-zone-dashboard .ua-zd-row:first-child [data-f="rho"]');
        expect(rho, 'density readout is an exponential number').toMatch(/e[+-]?\d/i);
        const regime = await page.textContent('#ua-zone-dashboard .ua-zd-row:first-child [data-f="regime"]');
        expect(regime?.trim(), 'flow-regime badge is populated').not.toBe('–');
        const badge = await page.textContent('#ua-zone-dashboard .ua-zd-row:first-child [data-f="tibadge"]');
        expect(['calm', 'unsettled', 'turbulent', 'severe'], 'turbulence state badge is a known class')
            .toContain(badge?.trim());
    });

    test('density + turbulence overlay toggles do not throw', async ({ page }) => {
        await routeUpperAtmosphereFeeds(page);
        const errors = attachConsoleRecorder(page);
        await page.goto(URL);
        await page.waitForFunction(() => !!window.__ua, { timeout: BOOT_TIMEOUT_MS });
        await page.waitForTimeout(400);

        // ── Density sub-shells (Controls tab — visible by default) ──────
        await page.check('#ua-subshell-toggle');
        await page.waitForTimeout(150);
        expect(await page.evaluate(() => window.__ua.globe.getDensitySubShellsVisible()),
            'sub-shells turned on').toBe(true);
        // Rebuild at each step granularity — exercises the dispose/rebuild path.
        for (const step of ['25', '100', '50']) {
            await page.selectOption('#ua-subshell-step', step);
            await page.waitForTimeout(120);
        }
        await page.uncheck('#ua-subshell-toggle');
        expect(await page.evaluate(() => window.__ua.globe.getDensitySubShellsVisible()),
            'sub-shells turned off').toBe(false);

        // ── Isodensity surfaces ─────────────────────────────────────────
        for (const sel of ['1e-12', 'all', '1e-11', 'off']) {
            await page.selectOption('#ua-iso-select', sel);
            await page.waitForTimeout(120);
        }
        // After cycling back to 'off', no surface should be selected.
        expect(await page.evaluate(() => window.__ua.globe.getIsodensitySelection()),
            'isodensity selection cleared').toBe('off');

        // ── Turbulence wave field (lives in the Analysis tab) ───────────
        await page.locator('#ua-aside-tabs .ua-tab-btn[data-ua-tab="analysis"]').click();
        await page.waitForTimeout(150);
        await page.check('#ua-zone-dashboard .ua-zd-wave');
        await page.waitForTimeout(300);   // let the ripple animate a few frames
        expect(await page.evaluate(() => window.__ua.globe.getWaveFieldVisible()),
            'wave field turned on').toBe(true);
        await page.uncheck('#ua-zone-dashboard .ua-zd-wave');
        expect(await page.evaluate(() => window.__ua.globe.getWaveFieldVisible()),
            'wave field turned off').toBe(false);

        // Changing the reference ballistic coefficient must not throw.
        await page.fill('#ua-zone-dashboard .ua-zd-bc', '0.05');
        await page.dispatchEvent('#ua-zone-dashboard .ua-zd-bc', 'change');
        await page.waitForTimeout(150);

        if (errors.length) console.error('Console errors:', errors);
        expect(errors, 'no console errors while toggling density/turbulence overlays')
            .toHaveLength(0);
    });
});
